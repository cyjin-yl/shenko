// Editable generated React DOM source. Profile: react-dom-source-v1.
// Inline owner lowering and emitted shared checked-data/Context helpers v1; no Proto-UI Runtime/Core/Adapter dependencies.
// Source graph SHA-256: d96e8c6034df472d348a6be97a150505405bd933c075230e31bf5b8d9b527009
import * as __puiReact from 'react';








import { createContextScope as __puiCreateContextScope, acceptsContextValue as __puiAccepts } from "./.proto-ui/context/scope-v1";
import type { ContextScope as __puiContextScope } from "./.proto-ui/context/scope-v1";
import { ContextTransport as __puiContextTransport } from './.proto-ui/context/react-v1';
import { createNativeStyle as __puiCreateNativeStyle, templateStyleTokens as __puiTemplateStyleTokens, type NativeStyle as __puiNativeStyle, type NativeStyleHandle as __puiNativeStyleHandle, type NativeRuleHandle as __puiNativeRuleHandle } from './.proto-ui/style/native-v1';








export type GeneratedProps = {
  "label"?: string | null;
  "tone"?: string | null;
};
export type GeneratedExposes = {

};
export type GeneratedComponentProps = GeneratedProps & Omit<__puiReact.HTMLAttributes<HTMLElement>, keyof GeneratedProps | 'dangerouslySetInnerHTML' | never> & {
  children?: __puiReact.ReactNode;
  /** The physical element is a target affordance, never a portable Proto expose. */
  hostRef?: __puiReact.Ref<HTMLElement>;
  hostProps?: Omit<__puiReact.AllHTMLAttributes<HTMLElement> & __puiReact.AnchorHTMLAttributes<HTMLElement>, 'children' | 'dangerouslySetInnerHTML'>;
  instanceAssociations?: Readonly<{ controlLabel?: object | null }>;

  [event: `on${string}`]: unknown;
};
export interface GeneratedHandle {
  update(): void;
  getElement(): HTMLElement | null;
  getExposes(): GeneratedExposes;
  invokeInCallbackScope<T>(callback: () => T): T;
}
type __puiResolvedProps = Readonly<{ "label": string; "tone": string }>;
type __puiStateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | { type: 'disconnect'; reason: 'unmount' };
type __puiExternalState<T> = {
  get(): T;
  subscribe(callback: (event: __puiStateEvent<T>) => void): () => void;
  unsubscribe(off: () => void): void;
  readonly spec: Readonly<__puiStateSpec>;
};
type __puiState<T> = { get(): T; setDefault(value: T): void; set(value: T, reason?: unknown): void };
type __puiStateSpec = { kind: 'bool' | 'enum' | 'string' | 'number.discrete' | 'number.range'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean };
type __puiDataSchema = string | { kind: string; fields?: readonly { name: string; type: __puiDataSchema; optional?: boolean }[]; element?: __puiDataSchema; members?: readonly __puiDataSchema[]; value?: unknown };
type __puiPropSpec = { type: __puiDataSchema; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; options?: readonly string[]; range?: { min?: number; max?: number }; validator?: (value: never) => boolean };
type __puiRun = {
  update(): void;
  feedback: { style: Pick<__puiNativeStyle, 'patch' | 'suppress' | 'clearPatch'> };
  props: { get(): __puiResolvedProps; getRaw(): Readonly<Record<string, unknown>>; isProvided(key: string): boolean };
  context: {
    read<T>(key: object): T;
    tryRead<T>(key: object): T | null;
    tryReadAncestor<T>(key: object): T | null;
    update<T>(key: object, next: T | ((prev: T) => T)): void;
    tryUpdate<T>(key: object, next: T | ((prev: T) => T)): boolean;
  };
  expose: { emit(key: string, payload?: unknown, options?: Record<string, unknown>): void };
  lifecycle: { setPresent(present: boolean): void };
};
type __puiFrame = { revision: number; epoch: number; kind: 'mount' | 'update' | 'detach'; node: __puiReact.ReactNode };
type __puiOwner = {
  handle: GeneratedHandle;
  scope: __puiContextScope;
  getHostProjection(): { tag: string; properties: Readonly<Record<string, string | number | boolean | null>>; portalTarget: HTMLElement | null };
  bindRoot(root: HTMLElement | null): void;
  connect(): void;
  start(): void;
  applyProps(props: GeneratedComponentProps): void;
  accept(frame: __puiFrame): boolean;
  disconnect(): void;

};

const __puiSlots = new WeakSet<object>();
const __puiPortablePropNames = new Set<string>(["label","tone"]);
const __puiOutwardEventNames = new Set<string>([]);
function __puiHostProperties(props: GeneratedComponentProps): Record<string, unknown> {
  const result: Record<string, unknown> = { ...props.hostProps };
  for (const [key, value] of Object.entries(props)) {
    if (__puiPortablePropNames.has(key) || __puiOutwardEventNames.has(key)
      || ['children', 'hostRef', 'hostProps', 'instanceAssociations', 'key', 'ref', 'dangerouslySetInnerHTML'].includes(key)) continue;
    result[key] = value;
  }
  // Explicit native host fields cannot create a second subscriber to an outward
  // Proto signal, replace the slot tree, or steal the compiler's physical ref.
  for (const key of [...__puiOutwardEventNames, 'children', 'ref', 'key', 'dangerouslySetInnerHTML']) delete result[key];
  return result;
}
function __puiAssignHostRef(ref: __puiReact.Ref<HTMLElement> | undefined, element: HTMLElement | null): void {
  if (typeof ref === 'function') ref(element);
  else if (ref) (ref as __puiReact.MutableRefObject<HTMLElement | null>).current = element;
}
function __puiBindSlots(node: __puiReact.ReactNode, slot: __puiReact.ReactNode): __puiReact.ReactNode {
  if (Array.isArray(node)) {
    let result: __puiReact.ReactNode[] | null = null;
    for (let index = 0; index < node.length; index++) {
      const child = __puiBindSlots(node[index], slot);
      if (child !== node[index]) { result ??= node.slice(); result[index] = child; }
    }
    return result ?? node;
  }
  if (!__puiReact.isValidElement(node)) return node;
  const element = node as __puiReact.ReactElement<{ children?: __puiReact.ReactNode }>;
  if (__puiSlots.has(element)) return __puiReact.createElement(__puiReact.Fragment, { key: element.key }, slot);
  const previous = element.props.children, next = __puiBindSlots(previous, slot);
  return previous === next ? node : __puiReact.cloneElement(element, undefined, next);
}
function __puiRootProperties(properties: Readonly<Record<string, unknown>>, initial = false): Record<string, unknown> {
  const result: Record<string, unknown> = { ...properties };
  // Only server/initial hydration markup projects the canonical value through
  // defaultValue. A live native TextControl owns editing and its reset default;
  // its commit hook restores those fields after React's host reconciliation.
  if (Object.hasOwn(result, 'value')) { result.defaultValue = initial ? result.value : undefined; delete result.value; }
  if (typeof result.style === 'string') {
    const style: Record<string, string> = {};
    for (const declaration of result.style.split(';')) {
      const colon = declaration.indexOf(':');
      if (colon < 1) continue;
      const name = declaration.slice(0, colon).trim();
      style[name.startsWith('--') ? name : name.replace(/-([a-z])/g, (_match, letter: string) => letter.toUpperCase())] = declaration.slice(colon + 1).trim();
    }
    result.style = style;
  }
  return result;
}
function __puiHasRootContent(node: __puiReact.ReactNode): boolean {
  if (node === null || node === undefined || typeof node === 'boolean' || node === '') return false;
  if (Array.isArray(node)) return node.some(__puiHasRootContent);
  if (__puiReact.isValidElement(node) && node.type === __puiReact.Fragment)
    return __puiHasRootContent((node.props as { children?: __puiReact.ReactNode }).children);
  return true;
}
function __puiRenderRoot(tag: string, attributes: Record<string, unknown>, children: __puiReact.ReactNode): __puiReact.ReactElement {
  if (['input', 'textarea', 'img', 'area', 'base', 'br', 'col', 'embed', 'hr', 'link', 'meta', 'param', 'source', 'track', 'wbr'].includes(tag)) {
    if (__puiHasRootContent(children)) throw new TypeError('[Template] this physical control Root cannot contain semantic children.');
    return __puiReact.createElement(tag, attributes);
  }
  return __puiReact.createElement(tag, attributes, children);
}

function __puiResolveProps(
  specs: Readonly<Record<string, __puiPropSpec>>,
  defaults: readonly Readonly<Record<string, unknown>>[],
  previousValid: Record<string, unknown>,
  raw: Readonly<Record<string, unknown>>,
  strict: boolean
): __puiResolvedProps {
  const next: Record<string, unknown> = Object.create(null);
  for (const key of Object.keys(specs)) {
    const spec = specs[key];
    const provided = Object.hasOwn(raw, key);
    const value = raw[key];
    const empty = value === null || value === undefined;
    const valid = (candidate: unknown) => {
      if (!__puiAccepts(spec.type, candidate) || spec.range && !(typeof candidate === 'number'
        && candidate >= (spec.range.min ?? -Infinity) && candidate <= (spec.range.max ?? Infinity))) return false;
      // The checked schema establishes the validator's declared argument domain.
      // A throwing validator rejects this candidate, as in ordinary Props.
      try { return spec.validator ? !!spec.validator(candidate as never) : true; }
      catch { return false; }
    };
    if (provided && !empty && valid(value)) {
      next[key] = value;
      previousValid[key] = value;
      continue;
    }
    if (provided && empty && spec.empty === 'accept') { next[key] = null; continue; }
    const nonEmpty = strict && spec.empty === 'error';
    let found = false;
    const take = (candidate: unknown) => {
      if (candidate === undefined || nonEmpty && candidate === null) return false;
      if (candidate !== null && !valid(candidate)) return false;
      next[key] = candidate;
      found = true;
      return true;
    };
    if (provided && Object.hasOwn(previousValid, key)) take(previousValid[key]);
    if (!found) for (const layer of defaults) if (Object.hasOwn(layer, key) && take(layer[key])) break;
    if (!found && Object.hasOwn(spec, 'default')) take(spec.default);
    if (!found) {
      if (nonEmpty) throw new Error('[Props] missing, empty or invalid prop without non-empty fallback: ' + key);
      next[key] = null;
    }
    if (provided && next[key] !== null) previousValid[key] = next[key];
  }
  return Object.freeze(next) as __puiResolvedProps;
}

function __puiCompleteSteps(steps: readonly (() => void)[]): void {
  let failure: { error: unknown } | undefined;
  for (const step of steps) { try { step(); } catch (error) { failure ??= { error }; } }
  if (failure) throw failure.error;
}

function __puiCreateOwner(initial: GeneratedComponentProps, publish: (frame: __puiFrame) => void, getParent: () => __puiContextScope | null, publishHost: () => void): __puiOwner {
  let phase: 'setup' | 'callback' | 'render' | 'idle' = 'setup';
  let lifetime: 'alive' | 'disposing' | 'disposed' = 'alive';
  let connected = true;
  let cleanupVersion = 0;
  let desiredPresent = true;
  let mounted = false;
  let epoch = 0;
  let revision = 0;
  let acceptedRevision = 0;
  let latest: __puiFrame | null = null;
  let dirty = false;
  let updateQueued = false;
  let scheduled = false;
  let hostScheduled = false;
  let callbackDepth = 0;
  let slotUsed = false;
  let elementSequence = 0;
  let hostProps = initial;
  let root: HTMLElement | null = null;
  let rootGeneration = 0;
  let rootBinding: 'retiring' | 'binding' | null = null;
  let pendingRoot: { value: HTMLElement | null } | undefined;
  function consumePendingRoot(): { value: HTMLElement | null } | undefined {
    const request = pendingRoot; pendingRoot = undefined; return request;
  }

  let raw: Readonly<Record<string, unknown>> = Object.freeze({});
  let resolved: __puiResolvedProps;
  let hydrated = false;
  let propsWindow: { raw: Readonly<Record<string, unknown>>; resolved: __puiResolvedProps } | null = null;
  const specs: Record<string, __puiPropSpec> = Object.create(null);
  const defaults: Readonly<Record<string, unknown>>[] = [];
  const previousValid: Record<string, unknown> = Object.create(null);
  const stateNames = new Set<string>();
  // Reserve before setup; only successful setup publishes a reusable opaque result.

  const stateSubscribers = new Set<Set<(event: __puiStateEvent<unknown>) => void>>();
  const pendingStateEvents: (() => void)[] = [];
  const authorStateWatchCleanups: (() => void)[] = [];
  let emittingState = false;
  type __puiResolvedWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __puiRun, next: __puiResolvedProps, prev: __puiResolvedProps, info: Readonly<Record<string, unknown>>) => void };
  type __puiRawWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __puiRun, next: Readonly<Record<string, unknown>>, prev: Readonly<Record<string, unknown>>, info: Readonly<Record<string, unknown>>) => void };
  const watchers: __puiResolvedWatcher[] = [];
  const rawWatchers: __puiRawWatcher[] = [], rawAllWatchers: __puiRawWatcher[] = [];
  const exposes: Record<string, unknown> = Object.create(null);
  const methodSchemas: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {

  };
  const eventSchemas: Record<string, __puiDataSchema> = {

  };
  const propSchemas: Record<string, __puiDataSchema> = {
    "label": "string",
    "tone": "string",
  };
  const callbacks = {
    created: [] as ((run: __puiRun) => void)[], mounted: [] as ((run: __puiRun) => void)[],
    updated: [] as ((run: __puiRun) => void)[], unmounted: [] as ((run: __puiRun) => void)[],
    beforeDispose: [] as ((run: __puiRun) => void)[],
  };
  function ensureAlive() {
    if (lifetime === 'disposed' || !connected && phase !== 'callback')
      throw new Error('Generated handle is invalid after terminal disposal.');
  }
  function ensurePhase(expected: typeof phase) {
    ensureAlive();
    if (phase !== expected) throw new Error('Illegal generated operation phase: ' + phase + '; expected ' + expected);
  }
  function ensureExternal() {
    if (!connected || lifetime !== 'alive') throw new Error('Generated handle is invalid after terminal disposal begins.');
  }
  function invoke<T>(callback: () => T): T {
    ensureAlive();
    if (phase === 'render' || phase === 'setup') throw new Error('Cannot enter callback scope from ' + phase);
    const previous = phase;
    phase = 'callback';
    ++callbackDepth;
    try { return callback(); }
    finally { phase = previous; --callbackDepth; if (!callbackDepth) schedule(); }
  }
  

  
  const context = __puiCreateContextScope({
    getParent, isAlive: () => lifetime !== 'disposed', invoke,
    validate: (key: object, value: unknown): boolean => false,
  });
  function projectStyle(tokens: readonly string[]) {
    if (!root) return;
    if (tokens.length) root.setAttribute('data-pui-style', tokens.join(' '));
    else root.removeAttribute('data-pui-style');
  }
  const __puiStyle = __puiCreateNativeStyle({
    ensureSetup: () => ensurePhase('setup'),
    ensureRuntime: () => ensurePhase('callback'),
    isAlive: () => lifetime !== 'disposed',
    project: tokens => { projectStyle(tokens);  },
    
  });
  function dispatch(list: readonly ((run: __puiRun) => void)[]) {
    invoke(() => { for (const callback of list) callback(__puiRunHandle); });
  }
  function detachView() {
    const wasMounted = mounted; mounted = false;
    __puiCompleteSteps([
      () => __puiStyle.unmount(),
      () => { if (wasMounted) dispatch(callbacks.unmounted); },
    ]);
  }
  function schedule() {
    if (scheduled || callbackDepth || !connected || lifetime !== 'alive') return;
    if (!updateQueued && desiredPresent === mounted && !(!desiredPresent && root) && !(latest && latest.revision > acceptedRevision)) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      if (!connected || lifetime !== 'alive') return;
      if (latest && latest.revision > acceptedRevision) return;
      if (!desiredPresent) {
        if (mounted || root) deliver('detach');
        else { dirty = dirty || updateQueued; updateQueued = false; }
      } else if (!mounted) deliver('mount');
      else if (updateQueued) deliver('update');
    });
  }
  function deliver(kind: __puiFrame['kind']) {
    updateQueued = false;
    let node: __puiReact.ReactNode = null;
    if (kind === 'mount') ++epoch;
    if (kind !== 'detach') {
      slotUsed = false;
      elementSequence = 0;
      phase = 'render';
      try { node = normalize(render(__puiRenderer));  }
      finally { phase = 'idle'; }
      dirty = false;
    }
    latest = { revision: ++revision, epoch, kind, node };
    publish(latest);
  }
  function normalize(value: unknown): __puiReact.ReactNode {
    if (value === null) return null;
    if (Array.isArray(value)) return value.flatMap((item) => {
      const child = normalize(item);
      return child === null ? [] : [child];
    });
    if (typeof value === 'string' || typeof value === 'number' && Number.isFinite(value) || __puiReact.isValidElement(value)) return value;
    throw new Error('[Template] child must be null, text, a finite number or an authored element/slot.');
  }
  function __puiElement(tag: string, ...args: unknown[]) {
    ensurePhase('render');
    if (!tag || typeof tag !== 'string') throw new Error('[Template] native elements require a tag string.');
    let children: unknown = null;
    let props: Record<string, unknown> = {};
    if (args.length === 1) {
      const argument = args[0];
      if (argument !== null && typeof argument === 'object' && !Array.isArray(argument) && !__puiReact.isValidElement(argument)) {
        props = argument as Record<string, unknown>;
      } else children = argument;
    } else if (args.length === 2) {
      if (!args[0] || typeof args[0] !== 'object' || Array.isArray(args[0]))
        throw new Error('[Template] native template props must be a record.');
      props = args[0] as Record<string, unknown>;
      children = args[1];
    }
    if (Object.keys(props).some((key) => key !== 'style'))
      throw new Error('[Template] native template props support only style.');
    const tokens = Object.hasOwn(props, 'style') ? __puiTemplateStyleTokens(props.style as __puiNativeStyleHandle) : '';
    const normalized = normalize(children);
    return __puiReact.createElement(tag, { key: elementSequence++, ...(tokens ? { 'data-pui-style': tokens } : {}) }, ...(Array.isArray(normalized) ? normalized : [normalized]));
  }
  const __puiRenderer = {
    read: Object.freeze({
      props: Object.freeze({
        get() { ensurePhase('render'); return resolved; },
        getRaw() { ensurePhase('render'); return raw; },
        isProvided(key: string) { ensurePhase('render'); return Object.hasOwn(raw, key); },
      }),
      context: Object.freeze({
        read<T>(key: object): T { ensurePhase('render'); return context.read<T>(key); },
        tryRead<T>(key: object): T | null { ensurePhase('render'); return context.tryRead<T>(key); },
      }),
    }),
    el: __puiElement,


    slot: () => {
      ensurePhase('render');
      if (slotUsed) throw new Error('[Template] multiple anonymous slots are not supported.');
      slotUsed = true;
      const slot = __puiReact.createElement(__puiReact.Fragment, { key: elementSequence++ });
      __puiSlots.add(slot);
      return slot;
    },
  };
  function __puiCreateState<T extends boolean | string | number>(name: string, initialValue: T, spec: __puiStateSpec): __puiState<T> {
    ensurePhase('setup');
    if (typeof name !== 'string' || name.length === 0 || stateNames.has(name)) throw new Error('[State] illegal or duplicate state name: ' + name);
    spec = Object.freeze({ ...spec, ...(spec.options ? { options: Object.freeze([...spec.options]) } : {}) });
    const type = spec.kind === 'bool' ? 'boolean' : spec.kind === 'string' || spec.kind === 'enum' ? 'string' : 'number';
    if (spec.options?.some((option) => typeof option !== type || typeof option === 'number' && !Number.isFinite(option)))
      throw new Error('[State] invalid state options: ' + name);
    if (spec.kind === 'number.range' && (!Number.isFinite(spec.min) || !Number.isFinite(spec.max))
      || spec.min !== undefined && !Number.isFinite(spec.min) || spec.max !== undefined && !Number.isFinite(spec.max)
      || spec.min !== undefined && spec.max !== undefined && spec.min > spec.max
      || spec.step !== undefined && !Number.isFinite(spec.step))
      throw new Error('[State] invalid numeric domain: ' + name);
    function validate(next: T) {
      if (typeof next !== type || typeof next === 'number' && !Number.isFinite(next))
        throw new TypeError('[State] invalid state value: ' + name);
      if (spec.kind === 'enum' && !spec.options?.includes(next as string)) throw new Error('[State] enum value outside options: ' + name);
      if (spec.options?.length && (spec.kind === 'enum' || spec.kind === 'string' || spec.kind === 'number.discrete')) {
        if (!spec.options.includes(next as string | number)) throw new Error('[State] state value outside options: ' + name);
        return;
      }
      if (typeof next !== 'number') return;
      if (next < (spec.min ?? -Infinity) || next > (spec.max ?? Infinity))
        throw new Error('[State] state value outside range: ' + name);
      if (spec.kind === 'number.discrete' && spec.step !== undefined && spec.step > 0
        && !Number.isInteger((next - (spec.min ?? 0)) / spec.step))
        throw new Error('[State] state value violates step: ' + name);
    }
    let value = initialValue;
    // Core range clamping normalizes definition defaults only, never callback writes.
    if (spec.kind === 'number.range' && spec.clamp && typeof value === 'number' && Number.isFinite(value))
      value = Math.min(spec.max!, Math.max(spec.min!, value)) as T;
    validate(value);
    stateNames.add(name);
    const subscribers = new Set<(event: __puiStateEvent<T>) => void>();
    stateSubscribers.add(subscribers as Set<(event: __puiStateEvent<unknown>) => void>);
    const state = {
      get() { ensureAlive(); return value; },
      setDefault(next: T) { ensurePhase('setup'); validate(next); value = next; },
      set(next: T, reason?: unknown) {
        ensurePhase('callback');
        validate(next);
        if (Object.is(value, next)) return;
        const event: __puiStateEvent<T> = { type: 'next', prev: value, next, reason };
        value = next;
        __puiStyle.refresh();
        
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(pendingStateEvents, pendingStateEvents.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!emittingState) {
  emittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < pendingStateEvents.length) {
      try { pendingStateEvents[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { pendingStateEvents.length = 0; emittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
    };
    const external: __puiExternalState<T> = Object.freeze({
      get() { ensureExternal(); return state.get(); },
      subscribe(callback: (event: __puiStateEvent<T>) => void) {
        ensureExternal(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { subscribers.delete(registration); };
      },
      unsubscribe(off: () => void) { off(); },
      spec: Object.freeze(spec),
    });
    externalStates.set(state, external);
    

    return state;
  }
  const externalStates = new WeakMap<object, unknown>();
  const __puiRunHandle: __puiRun = {
    feedback: { style: __puiStyle },
    update() {
      ensurePhase('callback');
      if (lifetime !== 'alive') return;
      dirty = true;
      if (desiredPresent && mounted) updateQueued = true;
      schedule();
    },
    props: {
      get() { ensureAlive(); return propsWindow?.resolved ?? resolved; },
      getRaw() { ensureAlive(); return propsWindow?.raw ?? raw; },
      isProvided(key: string) { ensureAlive(); return Object.hasOwn(propsWindow?.raw ?? raw, key); },
    },
    context: Object.freeze({
      read<T>(key: object): T { ensurePhase('callback'); return context.read<T>(key); },
      tryRead<T>(key: object): T | null { ensurePhase('callback'); return context.tryRead<T>(key); },
      tryReadAncestor<T>(key: object): T | null { ensurePhase('callback'); return context.tryReadAncestor<T>(key); },
      update<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); context.update(key, next); },
      tryUpdate<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); return context.tryUpdate(key, next); },
    }),
    expose: { emit(key, payload, options) {
      ensurePhase('callback');
      const declaration = exposes[key] as { kind?: string; payload: __puiDataSchema } | undefined;
      if (declaration?.kind !== 'event') throw new Error('[Expose] event was not declared: ' + key);
      if (!__puiAccepts(declaration.payload, payload)) throw new TypeError('[Expose] invalid event payload: ' + key);
      const sink = (hostProps as Record<string, unknown>)['on' + key.charAt(0).toUpperCase() + key.slice(1)];
      if (typeof sink === 'function') { try { sink(payload, options); } catch { /* Host sink failures do not re-enter prototype execution. */ } }
    } },
    lifecycle: { setPresent(present) {
      ensurePhase('callback');
      if (lifetime !== 'alive') throw new Error('[Lifecycle] cannot update view presence after terminal disposal begins.');
      if (typeof present !== 'boolean') throw new Error('[Lifecycle] view presence must be boolean.');
      if (desiredPresent === present) return;
      desiredPresent = present;
      schedule();
    } },
  };
  function registerExpose(key: string, value: unknown) {
    ensurePhase('setup');
    if (!key || Object.hasOwn(exposes, key)) throw new Error('[Expose] empty or duplicate declaration: ' + key);
    exposes[key] = value;
  }
  const __puiDef = {
    feedback: { style: { use: __puiStyle.use, declareDecoration: __puiStyle.declareDecoration, to: __puiStyle.to } },
    context: Object.freeze({
      provide<T>(key: object, value: T) { ensurePhase('setup'); context.provide(key, value); },
      subscribe<T>(key: object, callback?: (run: __puiRun, next: T, prev: T) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'required', callback ? (next, prev) => callback(__puiRunHandle, next as T, prev as T) : undefined);
      },
      trySubscribe<T>(key: object, callback?: (run: __puiRun, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__puiRunHandle, next, prev) : undefined);
      },
      trySubscribeAncestor<T>(key: object, callback?: (run: __puiRun, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__puiRunHandle, next, prev) : undefined, 'ancestor');
      },
    }),
    props: {
      define(incoming: Record<string, Omit<__puiPropSpec, 'type'> & { type: __puiDataSchema | 'enum' | 'object' | 'any' }>) {
        ensurePhase('setup');
        const next = { ...specs };
        for (const [key, authored] of Object.entries(incoming)) {
          const schema = propSchemas[key];
          if (!schema) throw new Error('[Props] missing checked declaration: ' + key);
          const spec: __puiPropSpec = { ...authored, type: schema };
          const previous = specs[key];
          if (!previous) { next[key] = { ...spec }; continue; }
          if (previous.validator && previous.validator !== spec.validator)
            throw new Error('[Props] validator replacement or removal is disallowed: ' + key);
          const rank = (empty: __puiPropSpec['empty']) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
          if (JSON.stringify(previous.type) !== JSON.stringify(spec.type) || Object.hasOwn(spec, 'empty') && rank(spec.empty) > rank(previous.empty)
            || previous.range && spec.range && ((spec.range.min ?? -Infinity) > (previous.range.min ?? -Infinity)
              || (spec.range.max ?? Infinity) < (previous.range.max ?? Infinity)))
            throw new Error('[Props] conflicting or stricter prop definition: ' + key);
          next[key] = { ...previous, ...spec, empty: previous.empty ?? 'fallback', range: spec.range ?? previous.range };
          if (Object.hasOwn(previous, 'default')) next[key].default = previous.default;
        }
        Object.assign(specs, next);
        resolved = __puiResolveProps(specs, defaults, previousValid, raw, false);
      },
      setDefaults(partial: Record<string, unknown>) {
        ensurePhase('setup');
        for (const key of Object.keys(partial)) if (!Object.hasOwn(specs, key)) throw new Error('[Props] undeclared default key: ' + key);
        defaults.unshift({ ...partial });
        resolved = __puiResolveProps(specs, defaults, previousValid, raw, false);
      },
      watch(keys: readonly string[], callback: (run: __puiRun, next: __puiResolvedProps, prev: __puiResolvedProps, info: Readonly<Record<string, unknown>>) => void) {
        ensurePhase('setup');
        if (!keys.length || keys.some((key) => !Object.hasOwn(specs, key))) throw new Error('[Props] watchers require declared keys.');
        const watcher = { keys: [...keys], callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchAll(callback: __puiResolvedWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __puiResolvedWatcher = { keys: null, callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRaw(keys: readonly string[], callback: __puiRawWatcher['callback']) {
        ensurePhase('setup');
        if (!keys.length || keys.some(key => typeof key !== 'string' || !key.length)) throw new Error('[Props] raw watchers require nonempty keys.');
        const watcher: __puiRawWatcher = { keys: [...keys], callback, active: true };
        rawWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRawAll(callback: __puiRawWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __puiRawWatcher = { keys: null, callback, active: true };
        rawAllWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
    },
    state: {
      bool: (name: string, value: boolean) => __puiCreateState(name, value, { kind: 'bool' }),
      string: (name: string, value: string, spec: Omit<__puiStateSpec, 'kind'> = {}) => __puiCreateState(name, value, { kind: 'string', ...spec }),
      enum: (name: string, value: string, spec: { options: readonly string[] }) => __puiCreateState(name, value, { kind: 'enum', ...spec }),
      numberDiscrete: (name: string, value: number, spec: Omit<__puiStateSpec, 'kind'> = {}) => __puiCreateState(name, value, { kind: 'number.discrete', ...spec }),
      numberRange: (name: string, value: number, spec: Omit<__puiStateSpec, 'kind'>) => __puiCreateState(name, value, { kind: 'number.range', ...spec }),
    },
    expose: {
      value: registerExpose,
      state(key: string, state: object) {
        const external = externalStates.get(state);
        if (!external) throw new Error('[Expose] state must belong to this instance.');
        registerExpose(key, external);

      },
      event(key: string, _spec: { payload?: 'void' | 'any' | 'json'; options?: Readonly<Record<string, unknown>> } = {}) {
        if (!Object.hasOwn(eventSchemas, key)) throw new Error('[Expose] missing checked event schema: ' + key);
        registerExpose(key, Object.freeze({ kind: 'event', payload: eventSchemas[key] }));
      },
      method<A extends unknown[], R>(key: string, callback: (...args: A) => R, project?: (value: R) => R) {

        registerExpose(key, (...args: A): R => {
          ensureExternal();
          return invoke(() => {
          const schema = methodSchemas[key];
          if (!schema || !schema.args(args))
            throw new TypeError('[Expose] invalid method arguments: ' + key);
          const result = callback(...args);
          if (!schema.result(result)) throw new TypeError('[Expose] invalid method result: ' + key);
          return project ? project(result) : result;
          });
        });
      },
    },
    lifecycle: {
      onCreated(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.created.push(callback); },
      onMounted(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.mounted.push(callback); },
      onUpdated(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.updated.push(callback); },
      onUnmounted(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.unmounted.push(callback); },
      onBeforeDispose(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.beforeDispose.push(callback); },
    },
  };

  let render: (renderer: typeof __puiRenderer) => unknown;
  try {
    render = ((def: typeof __puiDef) => {
    // Source "transport-badge.proto.ts":19:5
    def.props.define({ ["label"]: { ["type"]: "string" }, ["tone"]: { ["type"]: "string" } });
    // Source "transport-badge.proto.ts":23:5
    def.props.setDefaults({ ["label"]: "", ["tone"]: "offline" });
    // Source "transport-badge.proto.ts":26:5
    def.props.watch(["label"], (run: __puiRun) => {
      // Source "transport-badge.proto.ts":26:41
      return run.update();
    });
    // Source "transport-badge.proto.ts":27:5
    def.feedback.style.use(({"kind":"tw","tokens":["shenko-status-chip"],"groups":["shenko-status-chip"]} as const));
    // Source "transport-badge.proto.ts":28:5
    __puiStyle.rule(() => (resolved["tone"] === "online"), [({"kind":"tw","tokens":["shenko-status-online"],"groups":["shenko-status-online"]} as const)]);
    // Source "transport-badge.proto.ts":32:5
    __puiStyle.rule(() => (resolved["tone"] === "connecting"), [({"kind":"tw","tokens":["shenko-status-connecting"],"groups":["shenko-status-connecting"]} as const)]);
    // Source "transport-badge.proto.ts":36:5
    __puiStyle.rule(() => (resolved["tone"] === "reconnecting"), [({"kind":"tw","tokens":["shenko-status-reconnecting"],"groups":["shenko-status-reconnecting"]} as const)]);
    // Source "transport-badge.proto.ts":40:5
    __puiStyle.rule(() => (resolved["tone"] === "local"), [({"kind":"tw","tokens":["shenko-status-local"],"groups":["shenko-status-local"]} as const)]);
    // Source "transport-badge.proto.ts":44:5
    return (r: typeof __puiRenderer) => {
      // Source "transport-badge.proto.ts":44:19
      return r.el("span", [r.el("i", { ["style"]: ({"kind":"tw","tokens":["shenko-status-dot"],"groups":["shenko-status-dot"]} as const) }), (r.read.props.get())["label"]]);
    };
  })(__puiDef) ?? (() => __puiRenderer.slot());
    if (typeof render !== 'function') throw new Error('[Prototype] setup must return a render function or void.');
  } catch (error) { try { disposeNow(false, false); } catch {} throw error; }
  phase = 'idle';
  function applyProps(nextHost: GeneratedComponentProps) {
    ensureAlive();
    hostProps = nextHost;
{ const __puiAssociations = nextHost.instanceAssociations;
    if (__puiAssociations !== undefined) {
      if (__puiAssociations === null || typeof __puiAssociations !== 'object' || Object.getPrototypeOf(__puiAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiAssociations, 'controlLabel') && Reflect.get(__puiAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
    const nextRaw: Record<string, unknown> = Object.create(null);
    for (const [key, value] of Object.entries(nextHost)) {
      if (key === 'children' || key === 'instanceAssociations' || key === 'hostRef' || key === 'hostProps' || !Object.hasOwn(specs, key) && (['class', 'className', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) || /^on[A-Z]/.test(key) && typeof value === 'function')) continue;
      nextRaw[key] = value;
    }
    if (hydrated && Object.keys(raw).length === Object.keys(nextRaw).length
      && Object.keys(nextRaw).every((key) => Object.hasOwn(raw, key) && Object.is(raw[key], nextRaw[key]))) return false;
    const previous = resolved;
    const previousRaw = raw;
    raw = Object.freeze(nextRaw);
    resolved = __puiResolveProps(specs, defaults, previousValid, raw, true);
    __puiStyle.refresh();
    if (!hydrated) { hydrated = true; return false; }
    const nextResolved = resolved, nextRawSnapshot = raw;
    invoke(() => {
      const previousWindow = propsWindow;
      propsWindow = { raw: nextRawSnapshot, resolved: nextResolved };
      try {
      if (rawAllWatchers.length || rawWatchers.length) {
        const changedRaw = [...new Set([...Object.keys(previousRaw), ...Object.keys(nextRawSnapshot)])].filter(key => !Object.is(previousRaw[key], nextRawSnapshot[key]));
        if (changedRaw.length) for (let groupIndex = 0; groupIndex < 2; ++groupIndex) for (const watcher of groupIndex === 0 ? rawAllWatchers : rawWatchers) {
          if (!watcher.active) continue;
          const changedKeysMatched = watcher.keys ? watcher.keys.filter(key => changedRaw.includes(key)) : changedRaw;
          if (!changedKeysMatched.length) continue;
          console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
          watcher.callback(__puiRunHandle, nextRawSnapshot, previousRaw, { changedKeysAll: changedRaw, changedKeysMatched });
        }
      }
      const changedKeysAll = Object.keys(specs).filter((key) => !Object.is(previous[key as keyof GeneratedProps], nextResolved[key as keyof GeneratedProps]));
      for (const watcher of watchers) {
        if (!watcher.active) continue;
        const changedKeysMatched = watcher.keys ? watcher.keys.filter((key) => changedKeysAll.includes(key)) : changedKeysAll;
        if (changedKeysMatched.length) watcher.callback(__puiRunHandle, nextResolved, previous, { changedKeysAll, changedKeysMatched });
      }
      } finally { propsWindow = previousWindow; }
    });
    return true;
  }
  const handle: GeneratedHandle = Object.freeze({
    update() { ensureExternal(); invoke(() => __puiRunHandle.update()); },
    getElement() { return lifetime === 'alive' && connected ? root : null; },
    getExposes() { ensureExternal(); return { ...exposes } as GeneratedExposes; },
    invokeInCallbackScope<T>(callback: () => T): T { ensureExternal(); return invoke(callback); },
  });
  function disposeNow(exhaustive = false, authored = true) {
    if (lifetime !== 'alive') return;
    lifetime = 'disposing'; connected = false; ++cleanupVersion; ++rootGeneration; phase = 'callback';
    __puiCompleteSteps([
      ...authorStateWatchCleanups.splice(0),
      () => detachView(),
      () => {
        if (!authored) return;
        if (exhaustive) __puiCompleteSteps(callbacks.beforeDispose.map(callback => () => invoke(() => callback(__puiRunHandle))));
        else dispatch(callbacks.beforeDispose);
      },
      () => root?.removeAttribute('data-pui-style'),
      () => __puiStyle.dispose(),
      () => context.dispose(),
      () => {
        root = null; lifetime = 'disposed'; phase = 'idle';
        for (const subscribers of stateSubscribers) subscribers.clear();
        pendingStateEvents.length = 0; watchers.length = 0; rawWatchers.length = 0; rawAllWatchers.length = 0;
        for (const list of Object.values(callbacks)) list.length = 0;
        for (const key of Object.keys(exposes)) delete exposes[key];
      },
    ]);
  }
  return {
    handle,
    scope: context,
    getHostProjection() { return { tag: "div", properties: {}, portalTarget: null }; },

    bindRoot(nextRoot) {
      if (lifetime !== 'alive') return;
      if (rootBinding) {
        if (rootBinding === 'binding' && root === nextRoot && !pendingRoot) return;
        pendingRoot = { value: nextRoot }; ++rootGeneration;
        return;
      }
      if (root === nextRoot) return;
      let next = nextRoot;
      let failure: { error: unknown } | undefined;
      try {
        for (;;) {
          // Cleanup owns the previous Root and all of its reached resources.
          // Reentrant requests coalesce until that complete transaction returns.
          rootBinding = 'retiring'; ++rootGeneration;
          const previousRoot = root;
          try { __puiCompleteSteps([
            () => previousRoot?.removeAttribute('data-pui-style'),
          ]); } catch (error) { failure ??= { error }; }
          if (lifetime !== 'alive') break;
          const replacement = consumePendingRoot();
          if (replacement) next = replacement.value;
          root = next; rootBinding = 'binding';
          const generation = ++rootGeneration;
          const current = () => generation === rootGeneration && lifetime === 'alive';
          try { __puiCompleteSteps([
            () => { if (current() && mounted) projectStyle(__puiStyle.tokens()); },
          ]); } catch (error) { failure ??= { error }; }
          const queued = consumePendingRoot();
          if (lifetime !== 'alive' || !queued) break;
          next = queued.value;
        }
      } finally { rootBinding = null; pendingRoot = undefined; }
      if (failure) throw failure.error;
    },
    connect() { connected = true; ++cleanupVersion; },
    start() {
      try {
        applyProps(initial); dispatch(callbacks.created);
        schedule();
      }
      catch (error) { try { disposeNow(true); } catch {} throw error; }
    },
    applyProps,
    accept(frame: __puiFrame) {
      if (!connected || lifetime !== 'alive' || frame.revision <= acceptedRevision || frame !== latest) return false;
      acceptedRevision = frame.revision;
      if (frame.kind === 'detach') {
        try { detachView(); } finally { schedule(); }
      } else if (!desiredPresent) {
        // Physical materialization is not a published mount. Remove the obsolete
        // Root without manufacturing mounted/unmounted for a never-mounted epoch.
        schedule();
        return false;
      } else if (frame.kind === 'mount') {
        mounted = true;

        // The published mount may predate an explicit update intent. Only
        // after its acknowledgement may that dirty intent enter update flow.
        if (dirty) updateQueued = true;
        __puiStyle.mount();
        
        dispatch(callbacks.mounted);
      } else if (mounted && frame.epoch === epoch) {   dispatch(callbacks.updated); }
      schedule();
      return true;
    },
    disconnect() {
      connected = false;
      const version = ++cleanupVersion;
      queueMicrotask(() => {
        if (connected || cleanupVersion !== version || lifetime !== 'alive') return;
        disposeNow();
      });
    },
  };
}


export const CompiledTransportBadge = __puiReact.forwardRef<GeneratedHandle, GeneratedComponentProps>(function CompiledTransportBadge(props, ref) {
  const ownerRef = __puiReact.useRef<__puiOwner | null>(null);
  const parentScope = __puiReact.useContext(__puiContextTransport);
  const parentRef = __puiReact.useRef<__puiContextScope | null>(null);
  const [frame, setFrame] = __puiReact.useState<__puiFrame | null>(null);
  const [, publishHost] = __puiReact.useReducer((version: number) => version + 1, 0);
  const rootRef = __puiReact.useRef<HTMLElement | null>(null);

  const pendingHostRef = __puiReact.useRef(props.hostRef);
  pendingHostRef.current = props.hostRef;
  const boundHostRef = __puiReact.useRef<__puiReact.Ref<HTMLElement> | undefined>(undefined);
  const bindRoot = __puiReact.useCallback((root: HTMLElement | null) => {
    if (boundHostRef.current !== pendingHostRef.current) __puiAssignHostRef(boundHostRef.current, null);
    boundHostRef.current = pendingHostRef.current;
    rootRef.current = root;
    ownerRef.current?.bindRoot(root);
    __puiAssignHostRef(boundHostRef.current, root);
  }, []);
  __puiReact.useLayoutEffect(() => {
    if (boundHostRef.current === props.hostRef) return;
    __puiAssignHostRef(boundHostRef.current, null);
    boundHostRef.current = props.hostRef;
    __puiAssignHostRef(boundHostRef.current, rootRef.current);
  }, [props.hostRef]);
  // All irreversible work begins after an accepted shell commit, never during React render.
  __puiReact.useLayoutEffect(() => {
    parentRef.current = parentScope;
    let owner = ownerRef.current;
    if (!owner) {
      owner = __puiCreateOwner(props, setFrame, () => parentRef.current, publishHost);
      ownerRef.current = owner;
      owner.start();

    } else owner.connect();
  }, []);
  __puiReact.useLayoutEffect(() => { parentRef.current = parentScope; }, [parentScope]);
  // Suspense can disconnect layout effects without unmounting the owner shell.
  // Passive cleanup identifies shell unmount; same-turn StrictMode replay cancels disposal.
  __puiReact.useEffect(() => {
    const owner = ownerRef.current;
    if (!owner) return;
    owner.connect();
    return () => { owner.disconnect(); };
  }, []);
  __puiReact.useLayoutEffect(() => { const owner = ownerRef.current; owner?.applyProps(props); }, [props]);
  __puiReact.useLayoutEffect(() => { if (frame) ownerRef.current!.accept(frame); }, [frame]);

  __puiReact.useImperativeHandle(ref, () => ownerRef.current!.handle, []);
  const template = __puiReact.useMemo(() => __puiBindSlots(frame?.node, props.children), [frame?.node, props.children]);
  const host = ownerRef.current?.getHostProjection();
  const rootView = frame && frame.kind !== 'detach'
    ? __puiRenderRoot(host!.tag, { ...__puiHostProperties(props), ...__puiRootProperties(host!.properties), 'data-pui-root': '', ref: bindRoot }, template) : null;
  const view = rootView;
  return __puiReact.createElement(__puiContextTransport.Provider, { value: ownerRef.current?.scope ?? null }, view);

});
CompiledTransportBadge.displayName = "shenko-transport-status";


//# sourceMappingURL=Component.tsx.map
