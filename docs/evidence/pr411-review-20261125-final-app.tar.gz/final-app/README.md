# Final PR #411 application verification
The canonical R3 runtime input is Shenko cb425ba8d4521c7f6cf2b9812d126298cbeed765 and Proto-UI 6ca8f262a074ed19cb24b35d5cc199b5b0e23e08.
The upstream public closure built 42 selected packages. The consumer check, all 69 Node tests, and normal build passed with source stability and 12 static artifacts.
All 16 browser cases passed on that generated production bundle: Files 2, IM 2, Inspector 4, Tree 4, reading 4. The phone Tree and tablet IM screenshots were also visually inspected.
Node 24.22.1; pnpm 10.32.1; Playwright 1.58.2; Chromium 145.0.7632.6. Browser observers ran under the existing non-root host user. Files/IM/Inspector/Tree kept the sandbox enabled; the unchanged reading observer retained its launch options.
The R2 metadata correction and payload-comparison receipt are retained separately under canonical/web-r2. That earlier source used bdc564c0 and is not relabelled as R3.
The first application run and original failed attempts remain in the separate immutable pr411-review-20261125-app.tar.gz archive. Full upstream compiler and later targeted compatibility evidence are separate archives with their own exact source bindings.
This archive does not establish live backend/model behavior, physical touch/assistive-technology coverage, full upstream compiler health, or deployment.
