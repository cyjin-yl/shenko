import fcntl, json, os, pathlib, sys, time
root = pathlib.Path(sys.argv[1])
fcntl.fcntl(sys.stdin.fileno(), fcntl.F_SETPIPE_SZ, 4096)
(root / 'server.pid').write_text(str(os.getpid()))
for line in sys.stdin:
    message = json.loads(line)
    if message.get('id') is None:
        continue
    if message.get('method') == 'initialize':
        result = {'protocolVersion':'2025-11-25','capabilities':{'tools':{}},'serverInfo':{'name':'blocked-transport-fixture','version':'1'}}
        print(json.dumps({'jsonrpc':'2.0','id':message['id'],'result':result}), flush=True)
        # The child remains alive but no longer consumes its 4 KiB input pipe.
        # Its own finite lifetime also bounds cleanup of the unfixed client.
        time.sleep(4)
        break
    print(json.dumps({'jsonrpc':'2.0','id':message['id'],'error':{'code':-32601,'message':'unknown method'}}), flush=True)
