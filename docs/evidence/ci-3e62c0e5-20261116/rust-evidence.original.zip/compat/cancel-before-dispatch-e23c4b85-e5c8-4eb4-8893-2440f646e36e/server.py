import json, os, pathlib, sqlite3, sys, time
root = pathlib.Path(sys.argv[1])
(root / 'server.pid').write_text(str(os.getpid()))
for line in sys.stdin:
    message = json.loads(line)
    method, ident = message.get('method'), message.get('id')
    if ident is None:
        continue
    if method == 'initialize':
        (root / 'initialize.started').write_text('ready')
        deadline = time.monotonic() + 10
        while (root / 'hold-initialize').exists() and not (root / 'release-initialize').exists():
            if time.monotonic() > deadline: sys.exit(2)
            time.sleep(0.01)
        result = {'protocolVersion':'2025-11-25','capabilities':{'tools':{}},'serverInfo':{'name':'native-effect-fixture','version':'1'}}
    elif method == 'tools/call':
        params = message['params']
        task = params['arguments'].get('task_id')
        db = sqlite3.connect('file:' + str(root / 'shenko.db') + '?mode=ro', uri=True)
        if task is None:
            rows = db.execute("SELECT data FROM operations WHERE json_extract(data,'$.operation_name')='compat.mcp.request' AND json_extract(data,'$.state')='in_flight'").fetchall()
            assert len(rows) == 1, 'subject fixture requires one armed request'
            row = rows[0]
        else:
            row = db.execute("SELECT data FROM operations WHERE json_extract(data,'$.task_id')=?", [task]).fetchone()
        assert row is not None, 'effect attempted before T1'
        operation = json.loads(row[0])
        task = operation['task_id']
        attempt = json.loads(db.execute('SELECT data FROM attempts WHERE operation_id=?', [operation['operation_id']]).fetchone()[0])
        assert attempt['dispatch_stage'] == 'armed', attempt
        db.close()
        with (root / 'effects.jsonl').open('a') as out:
            out.write(json.dumps({'task_id':task,'operation_id':operation['operation_id'],'attempt_id':attempt['attempt_id'],'name':params['name']}) + '\n')
            out.flush(); os.fsync(out.fileno())
        if params['name'] == 'drop_after_effect':
            os._exit(0)
        if params['name'] == 'hold':
            time.sleep(60)
        if params['name'] == 'large_observation':
            result = {'content':[{'type':'text','text':'x' * 1360000}],'isError':False}
        else:
            failed = params['name'] == 'reported_error'
            result = {'content':[{'type':'text','text':'effect recorded'}],'isError':failed}
    elif method == 'tools/list':
        result = {'tools':[]}
    else:
        print(json.dumps({'jsonrpc':'2.0','id':ident,'error':{'code':-32601,'message':'unknown method'}}), flush=True)
        continue
    print(json.dumps({'jsonrpc':'2.0','id':ident,'result':result}), flush=True)
