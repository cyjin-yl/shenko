import json, os, pathlib, sys, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
root = pathlib.Path(sys.argv[1])
posts = []
gets = []
class H(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(*a): pass
    def authed(self): return self.headers.get('X-Fixture-Auth')=='secret-token-value'
    def unauth(self):
        self.send_response(401); self.send_header('WWW-Authenticate','Bearer realm="fixture"'); self.send_header('Content-Length','0'); self.end_headers()
    def empty(self,status):
        self.send_response(status); self.send_header('Content-Length','0'); self.end_headers()
    def sse(self,payload):
        body=('data: '+json.dumps(payload)+'\r\n\r\n').encode()
        self.send_response(200); self.send_header('Content-Type','text/event-stream'); self.send_header('Mcp-Session-Id','fixture-session-1'); self.send_header('Content-Length',str(len(body))); self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        gets.append('get\n')
        if not self.authed(): return self.unauth()
        self.send_response(200); self.send_header('Content-Type','text/event-stream'); self.send_header('Transfer-Encoding','chunked'); self.end_headers()
        self.wfile.write(b'5\r\n: hi\n\r\n'); self.wfile.flush()
        while True:
            time.sleep(30)
            try: self.wfile.write(b'5\r\n: hi\n\r\n'); self.wfile.flush()
            except OSError: return
    def do_DELETE(self): self.empty(200)
    def do_POST(self):
        if not self.authed(): return self.unauth()
        wire=self.rfile.read(int(self.headers.get('Content-Length','0')) or b'0')
        message=json.loads(wire or b'{}')
        if message.get('method')=='tools/call':
            assert (root/('final-'+str(message['id'])+'.json')).read_bytes()==wire, 'request reached server before exact SDK bytes/ID were synced'
        posts.append({'method':message.get('method'),'id':message.get('id'),'name':message.get('params',{}).get('name')})
        method,ident=message.get('method'),message.get('id')
        if method=='initialize':
            self.sse({'jsonrpc':'2.0','id':ident,'result':{'protocolVersion':'2025-11-25','capabilities':{'tools':{}},'serverInfo':{'name':'http-fixture','version':'1'}}})
        elif ident is None:
            self.empty(202)
        elif method=='tools/call':
            name=message['params']['name']
            if name=='large_json':
                body=json.dumps({'jsonrpc':'2.0','id':ident,'result':{'content':[{'type':'text','text':'x'*200000}],'isError':False}}).encode()
                self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
            elif name=='large_sse':
                body=('data: '+json.dumps({'jsonrpc':'2.0','id':ident,'result':{'big':'x'*(17*1024*1024)}})+'\r\n\r\n').encode()
                self.send_response(200); self.send_header('Content-Type','text/event-stream'); self.send_header('Content-Length',str(len(body))); self.end_headers()
                try: self.wfile.write(body)
                except OSError: pass
            else:
                self.sse({'jsonrpc':'2.0','id':ident,'result':{'content':[{'type':'text','text':'echo:'+name}],'isError':False}})
        else:
            self.sse({'jsonrpc':'2.0','id':ident,'error':{'code':-32601,'message':'unknown method'}})
class Server(ThreadingHTTPServer):
    ready=False
    def service_actions(self):
        if not self.ready:
            self.ready=True
            print(self.server_address[1],flush=True)
server=Server(('127.0.0.1',0),H)
(root/'server.bound').write_text(str(server.server_address[1]))
(root/'server.pid').write_text(str(os.getpid()))
def stop_on_eof():
    sys.stdin.buffer.read()
    server.shutdown()
threading.Thread(target=stop_on_eof,daemon=True).start()
try:
    server.serve_forever()
finally:
    server.server_close()
    (root/'posts.jsonl').write_text(''.join(json.dumps(post)+'\n' for post in posts))
    (root/'server.gets.log').write_text(''.join(gets))
