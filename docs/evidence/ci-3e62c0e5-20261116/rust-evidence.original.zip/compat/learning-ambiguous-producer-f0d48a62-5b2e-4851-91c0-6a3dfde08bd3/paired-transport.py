import json, pathlib, runpy, sys
root = pathlib.Path(__file__).parent
original_in, original_out = sys.stdin, sys.stdout
held_ids, replies = set(), []

class PairedInput:
    def __iter__(self):
        for line in original_in:
            if json.loads(line).get('method') != 'tools/call':
                yield line
                continue
            (root / 'first-wire').write_bytes(b'arrived')
            other = original_in.readline()
            if not other or json.loads(other).get('method') != 'tools/call':
                raise RuntimeError('paired transport requires two actual calls')
            held_ids.update((json.loads(line)['id'], json.loads(other)['id']))
            yield line
            yield other

class PairedOutput:
    def __init__(self):
        self.buffer = ''
    def write(self, text):
        self.buffer += text
        while '\n' in self.buffer:
            line, self.buffer = self.buffer.split('\n', 1)
            if json.loads(line).get('id') in held_ids:
                replies.append(line)
                if len(replies) == 2:
                    original_out.write('\n'.join(replies) + '\n')
                    original_out.flush()
            else:
                original_out.write(line + '\n')
        return len(text)
    def flush(self):
        original_out.flush()

sys.stdin, sys.stdout = PairedInput(), PairedOutput()
runpy.run_path(str(root / 'original-ledger.py'), run_name='__main__')
