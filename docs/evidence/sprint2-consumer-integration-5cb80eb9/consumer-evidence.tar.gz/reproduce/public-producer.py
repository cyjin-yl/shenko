from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import traceback

UPSTREAM = Path('/workspace/scratch/b2027510c911/s2-compiler')
EXPECTED = '5cb80eb937f20982dd7dc8cbc93a90e91d665c31'
OUTPUT = Path('/workspace/scratch/b2027510c911/shenko-s2-workflow/producer-01')
OUTPUT.mkdir(exist_ok=False)
ENTRIES = ['@proto.ui/adapter-react', '@proto.ui/prototypes-shadcn', '@proto.ui/cli']
ENV = dict(os.environ, NODE_OPTIONS='--max-old-space-size=1024')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

report = {'kind': 'shenko-source-public-producer-v1', 'startedAt': now(),
          'upstreamCandidate': EXPECTED, 'upstreamSource': str(UPSTREAM),
          'entries': ENTRIES, 'steps': [], 'passed': False,
          'driverSha256': sha(Path(__file__)), 'nodeOptions': ENV['NODE_OPTIONS']}

def save():
    (OUTPUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')

def step(name, argv, timeout=600):
    stdout = OUTPUT / (name + '.stdout.log')
    stderr = OUTPUT / (name + '.stderr.log')
    entry = {'name': name, 'argv': argv, 'cwd': str(UPSTREAM), 'startedAt': now(),
             'wrapperTimeoutSeconds': timeout, 'stdout': str(stdout), 'stderr': str(stderr)}
    report['steps'].append(entry)
    save()
    started = time.monotonic()
    with stdout.open('x') as out, stderr.open('x') as err:
        child = subprocess.Popen(argv, cwd=UPSTREAM, env=ENV, stdin=subprocess.DEVNULL,
                                 stdout=out, stderr=err, start_new_session=True)
        entry['pid'] = child.pid
        save()
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            entry['timedOut'] = True
            code = child.returncode
    entry.update(exitCode=code, finishedAt=now(), durationSeconds=time.monotonic() - started,
                 stdoutSha256=sha(stdout), stderrSha256=sha(stderr))
    save()
    print(json.dumps({'step': name, 'exit': code}), flush=True)
    if code or entry.get('timedOut'):
        raise RuntimeError('Step failed: ' + name)
    return stdout.read_text()

try:
    assert step('upstream-head', ['git', 'rev-parse', 'HEAD']).strip() == EXPECTED
    assert step('upstream-clean-before', ['git', 'status', '--porcelain', '--untracked-files=no']).strip() == ''
    report['lockSha256'] = sha(UPSTREAM / 'pnpm-lock.yaml')
    report['producerSha256'] = sha(UPSTREAM / 'scripts/build/public-packages.mjs')
    report['node'] = step('node-version', ['node', '--version']).strip()
    report['pnpm'] = step('pnpm-version', ['corepack', 'pnpm@10.32.1', '--version']).strip()
    args = ['node', 'scripts/build/public-packages.mjs']
    for entry in ENTRIES:
        args.extend(['--package', entry])
    plan = json.loads(step('public-plan', [*args, '--plan', '--json']))
    assert len(plan['packages']) == len(set(plan['packages'])) == plan['selectedCount']
    assert set(ENTRIES).issubset(plan['packages']) and '@proto.ui/compiler' not in plan['packages']
    report['plan'] = plan
    step('variant-order', ['node', '--import', 'tsx', 'scripts/styles/generate-lowered-variant-order.ts'])
    public = json.loads(step('public-build', [*args, '--json']))
    (OUTPUT / 'public-build.json').write_text(json.dumps(public, indent=2) + '\n')
    actual = [item['name'] for item in public['results']]
    assert public['selectedCount'] == len(actual) == len(set(actual)) == plan['selectedCount']
    assert actual == plan['packages']
    report['publicReceiptSha256'] = sha(OUTPUT / 'public-build.json')
    assert step('upstream-clean-after', ['git', 'status', '--porcelain', '--untracked-files=no']).strip() == ''
    assert step('upstream-head-after', ['git', 'rev-parse', 'HEAD']).strip() == EXPECTED
    assert sha(UPSTREAM / 'pnpm-lock.yaml') == report['lockSha256']
    report['passed'] = True
except BaseException:
    report['failure'] = traceback.format_exc()
    print(report['failure'], flush=True)
finally:
    report['finishedAt'] = now()
    save()
    print(json.dumps({'passed': report['passed'], 'receipt': str(OUTPUT / 'receipt.json')}), flush=True)
sys.exit(0 if report['passed'] else 1)
