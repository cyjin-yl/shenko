from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import traceback

APPLICATION = Path('/workspace/scratch/b2027510c911/Shenko')
UPSTREAM = Path('/workspace/scratch/b2027510c911/s2-compiler')
WEB = APPLICATION / 'crates/shenko-ui/web'
STATIC = APPLICATION / 'crates/shenko-ui/src/static'
EXPECTED = '5cb80eb937f20982dd7dc8cbc93a90e91d665c31'
PUBLIC = Path('/workspace/scratch/b2027510c911/shenko-s2-workflow/producer-01')
OUTPUT = Path(sys.argv[1])
OUTPUT.mkdir(exist_ok=False)
ENV = dict(os.environ, NODE_OPTIONS='--max-old-space-size=1024',
           PROTO_UI_SOURCE=str(UPSTREAM), PROTO_UI_BUILD_RECEIPT=str(PUBLIC / 'public-build.json'))

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    files = [path for directory in ['src', 'tests'] for path in (WEB / directory).rglob('*') if path.is_file()]
    files += [WEB / name for name in ['build.mjs', 'compiler.mjs', 'upstream-pin.json',
                                      'package.json', 'pnpm-lock.yaml', 'tsconfig.json']]
    return {str(path.relative_to(APPLICATION)): sha(path) for path in sorted(files)}

def extra_inputs():
    files = [path for directory in ['prototypes', 'scripts'] for path in (WEB / directory).rglob('*') if path.is_file()]
    files += [APPLICATION / 'crates/shenko-ui/src/index.html',
              APPLICATION / 'scripts/web_reading_journey.mjs']
    return {str(path.relative_to(APPLICATION)): sha(path) for path in sorted(files)}

report = {'kind': 'shenko-sprint2-normal-consumer-build-v1', 'startedAt': now(),
          'upstreamCandidate': EXPECTED, 'upstreamSource': str(UPSTREAM),
          'steps': [], 'passed': False, 'driverSha256': sha(Path(__file__)),
          'nodeOptions': ENV['NODE_OPTIONS'],
          'scope': 'Ordinary public-package and private build-time compiler source consumer; normal prototypes, strict TypeScript, existing Node suite and production App assets. Browser journeys and live backend/model are separate.'}

def save():
    (OUTPUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')

def step(name, argv, cwd=WEB, timeout=600):
    stdout = OUTPUT / (name + '.stdout.log')
    stderr = OUTPUT / (name + '.stderr.log')
    entry = {'name': name, 'argv': argv, 'cwd': str(cwd), 'startedAt': now(),
             'wrapperTimeoutSeconds': timeout, 'stdout': str(stdout), 'stderr': str(stderr)}
    report['steps'].append(entry)
    save()
    started = time.monotonic()
    with stdout.open('x') as out, stderr.open('x') as err:
        child = subprocess.Popen(argv, cwd=cwd, env=ENV, stdin=subprocess.DEVNULL,
                                 stdout=out, stderr=err, start_new_session=True)
        entry['pid'] = child.pid
        save()
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            entry['timedOut'] = True
            code = child.returncode
    entry.update(exitCode=code, finishedAt=now(), durationSeconds=time.monotonic() - started,
                 stdoutSha256=sha(stdout), stderrSha256=sha(stderr))
    save()
    print(json.dumps({'step': name, 'exit': code}), flush=True)
    if code or entry.get('timedOut'):
        raise RuntimeError('Step failed: ' + name)
    return stdout.read_text()

try:
    producer = json.loads((PUBLIC / 'receipt.json').read_text())
    assert producer['passed'] is True and producer['upstreamCandidate'] == EXPECTED
    public = json.loads((PUBLIC / 'public-build.json').read_text())
    assert sha(PUBLIC / 'public-build.json') == producer['publicReceiptSha256']
    assert [item['name'] for item in public['results']] == producer['plan']['packages']
    report['publicReceiptSha256'] = producer['publicReceiptSha256']
    report['publicProducer'] = {'path': str(PUBLIC / 'receipt.json'), 'sha256': sha(PUBLIC / 'receipt.json'),
                               'selectedCount': public['selectedCount']}
    assert step('upstream-head', ['git', 'rev-parse', 'HEAD'], UPSTREAM).strip() == EXPECTED
    assert step('upstream-clean-before', ['git', 'status', '--porcelain', '--untracked-files=no'], UPSTREAM).strip() == ''
    report['appBase'] = step('app-head', ['git', 'rev-parse', 'HEAD'], APPLICATION).strip()
    step('app-diff-before', ['git', 'diff', '--binary'], APPLICATION)
    pin = json.loads((WEB / 'upstream-pin.json').read_text())
    assert pin['commit'] == EXPECTED and pin['lock_sha256'] == sha(UPSTREAM / 'pnpm-lock.yaml')
    report['sourceBefore'] = snapshot()
    report['extraInputsBefore'] = extra_inputs()
    report['node'] = step('node-version', ['node', '--version']).strip()
    report['webPackageManager'] = json.loads((WEB / 'package.json').read_text())['packageManager']
    step('inspector-observer-syntax', ['node', '--check', 'scripts/inspector-browser.mjs'])
    step('tree-observer-syntax', ['node', '--check', 'scripts/tree-browser.mjs'])
    step('app-prototypes', ['node', 'build.mjs', '--prototypes-only'])
    step('app-strict-types', ['node', 'node_modules/typescript/bin/tsc', '--noEmit'])
    tests = sorted(str(path.relative_to(WEB)) for path in (WEB / 'tests').glob('*.test.mjs'))
    step('app-node-tests', ['node', '--test', '--test-concurrency=1', *tests])
    step('app-build', ['node', 'build.mjs'])
    report['sourceAfter'] = snapshot()
    report['extraInputsAfter'] = extra_inputs()
    report['sourceStable'] = report['sourceAfter'] == report['sourceBefore']
    report['extraInputsStable'] = report['extraInputsAfter'] == report['extraInputsBefore']
    assert report['sourceStable'] and report['extraInputsStable']
    assert step('upstream-clean-after', ['git', 'status', '--porcelain', '--untracked-files=no'], UPSTREAM).strip() == ''
    assert step('upstream-head-after', ['git', 'rev-parse', 'HEAD'], UPSTREAM).strip() == EXPECTED
    manifest_path = STATIC / 'build-manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert manifest['upstream']['commit'] == EXPECTED
    assert manifest['upstream']['build_receipt']['receipt_sha256'] == report['publicReceiptSha256']
    assert manifest['compiler']['runtime_imported'] is False
    assert manifest['compiler']['public_package_selection']['includes_compiler'] is False
    assert manifest['realisation']['compiled'] == ['transport-badge', 'message-bubble']
    assert {'resizable', 'tree'}.issubset(item['family'] for item in manifest['realisation']['adapter'])
    actual = {str(path.relative_to(STATIC)): {'bytes': path.stat().st_size, 'sha256': sha(path)}
              for path in sorted(STATIC.rglob('*')) if path.is_file() and path != manifest_path}
    assert actual == manifest['artifacts']
    generation_path = WEB / 'generated/prototypes/manifest.json'
    generation = json.loads(generation_path.read_text())
    assert generation['source_tree_sha256'] == manifest['compiler']['source_tree_sha256']
    report['appBuildManifest'] = {'path': str(manifest_path), 'sha256': sha(manifest_path)}
    report['prototypeManifest'] = {'path': str(generation_path), 'sha256': sha(generation_path)}
    report['artifacts'] = actual
    report['passed'] = True
except BaseException:
    report['failure'] = traceback.format_exc()
    print(report['failure'], flush=True)
finally:
    report['finishedAt'] = now()
    save()
    print(json.dumps({'passed': report['passed'], 'receipt': str(OUTPUT / 'receipt.json')}), flush=True)
sys.exit(0 if report['passed'] else 1)
