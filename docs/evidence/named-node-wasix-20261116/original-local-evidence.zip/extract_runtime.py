import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import tarfile
import urllib.request

ROOT = Path(__file__).parent
URL = "https://github.com/wasmerio/wasmer/releases/download/v7.5.0/wasmer-linux-amd64.tar.gz"
EXPECTED_BYTES = 302721336
EXPECTED_SHA256 = "23f99818deaad93859f8bb8292af81f0c39f25aea19eaccfb72fc7c9e8a3fae9"
SELECTED = {"bin/wasmer": 219153104, "LICENSE": 1097, "ATTRIBUTIONS": 35351}
RESERVE_BYTES = 400 * 1024 * 1024
DESTINATION = ROOT / "wasmer-7.5.0"


class HashingReader:
    def __init__(self, source):
        self.source = source
        self.hash = hashlib.sha256()
        self.bytes = 0

    def read(self, size=-1):
        data = self.source.read(size)
        self.bytes += len(data)
        if self.bytes > EXPECTED_BYTES:
            raise ValueError("archive exceeded published size")
        self.hash.update(data)
        return data


assert shutil.disk_usage(ROOT).free > sum(SELECTED.values()) + RESERVE_BYTES
DESTINATION.mkdir(mode=0o700)
extracted = []
with urllib.request.urlopen(URL, timeout=30) as response:
    source = HashingReader(response)
    with tarfile.open(fileobj=source, mode="r|gz") as archive:
        for member in archive:
            if member.name not in SELECTED:
                continue
            assert member.isreg() and member.size == SELECTED[member.name]
            output = DESTINATION / member.name
            output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            content = archive.extractfile(member)
            assert content is not None
            digest = hashlib.sha256()
            count = 0
            with output.open("xb") as file:
                while chunk := content.read(1024 * 1024):
                    count += len(chunk)
                    assert count <= member.size
                    digest.update(chunk)
                    file.write(chunk)
                file.flush()
                os.fsync(file.fileno())
            assert count == member.size
            output.chmod(0o600)
            extracted.append({"name": member.name, "bytes": count, "sha256": digest.hexdigest()})
            print(json.dumps(extracted[-1]), flush=True)
    while source.read(1024 * 1024):
        pass
assert source.bytes == EXPECTED_BYTES and source.hash.hexdigest() == EXPECTED_SHA256
assert sorted(item["name"] for item in extracted) == sorted(SELECTED)
(DESTINATION / "bin/wasmer").chmod(0o700)
report = {
    "observed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "archive_url": URL,
    "archive_bytes": source.bytes,
    "archive_sha256": source.hash.hexdigest(),
    "extracted": extracted,
    "free_disk_bytes_after": shutil.disk_usage(ROOT).free,
    "executed": False,
}
(ROOT / "wasmer-extraction.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"verified": True, "free_disk_bytes_after": report["free_disk_bytes_after"]}), flush=True)
