import ctypes
import datetime
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import struct
import subprocess
import time

ARTIFACT_ROOT = Path(__file__).parent
ROOT = ARTIFACT_ROOT / 'address-space-retry'
ROOT.mkdir(mode=0o700)
for directory in ('guest', 'runtime-home', 'cache', 'tmp'):
    (ROOT / directory).mkdir(mode=0o700)
REPOSITORY = Path('/workspace/scratch/faaa3ccca531/shenko')
GUEST = ROOT / 'guest'
EXECUTABLE = ARTIFACT_ROOT / 'wasmer-7.5.0/bin/wasmer'
MODULE = ARTIFACT_ROOT / 'node-release-wasix32.wasm'
DRIVER_SOURCE = REPOSITORY / 'crates/shenko-repl/src/drivers/js_cell_driver.mjs'
RSS_LIMIT_BYTES = 1536 * 1024 * 1024
DISK_RESERVE_BYTES = 256 * 1024 * 1024
AVAILABLE_MEMORY_RESERVE_BYTES = 768 * 1024 * 1024
WALL_LIMIT_SECONDS = 180
CPU_LIMIT_SECONDS = 150
ADDRESS_SPACE_LIMIT_BYTES = 12 * 1024 * 1024 * 1024
SECCOMP_DENIED_SYSCALLS = ['socket', 'connect', 'bind', 'listen', 'accept', 'accept4', 'sendto', 'sendmsg', 'sendmmsg']


def available_memory():
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):
            return int(line.split()[1]) * 1024
    raise RuntimeError('MemAvailable observation unavailable')


def group_resources(pgid):
    members = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            stat = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(stat[2]) != pgid:
                continue
            fields = {}
            for line in (path / 'status').read_text().splitlines():
                name, _, value = line.partition(':')
                if name in ('VmRSS', 'VmSize', 'Threads'):
                    fields[name] = int(value.split()[0])
            members.append({'pid': int(path.name), **fields})
        except (FileNotFoundError, ProcessLookupError):
            continue
    return members


def install_limits():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_CPU, (CPU_LIMIT_SECONDS, CPU_LIMIT_SECONDS + 5))
    resource.setrlimit(resource.RLIMIT_AS, (ADDRESS_SPACE_LIMIT_BYTES, ADDRESS_SPACE_LIMIT_BYTES))
    resource.setrlimit(resource.RLIMIT_FSIZE, (16 * 1024 * 1024, 16 * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
    seccomp = ctypes.CDLL('libseccomp.so.2', use_errno=True)
    seccomp.seccomp_init.argtypes = [ctypes.c_uint32]
    seccomp.seccomp_init.restype = ctypes.c_void_p
    seccomp.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    seccomp.seccomp_syscall_resolve_name.restype = ctypes.c_int
    seccomp.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    seccomp.seccomp_rule_add.restype = ctypes.c_int
    seccomp.seccomp_load.argtypes = [ctypes.c_void_p]
    seccomp.seccomp_load.restype = ctypes.c_int
    seccomp.seccomp_release.argtypes = [ctypes.c_void_p]
    ctx = seccomp.seccomp_init(0x7fff0000)
    if not ctx:
        raise RuntimeError('seccomp_init failed')
    try:
        for name in SECCOMP_DENIED_SYSCALLS:
            syscall = seccomp.seccomp_syscall_resolve_name(name.encode())
            if syscall < 0 or seccomp.seccomp_rule_add(ctx, 0x00050000 | errno.EPERM, syscall, 0) != 0:
                raise RuntimeError('failed to deny network syscall ' + name)
        if seccomp.seccomp_load(ctx) != 0:
            raise RuntimeError('seccomp_load failed')
    finally:
        seccomp.seccomp_release(ctx)


def frames(cells):
    data = bytearray()
    for seq, source in cells:
        header = json.dumps({'seq': seq, 'cell_dir': '/workspace/cells', 'state_path': '/workspace/state.json', 'env_dir': '/workspace/env'}).encode()
        body = source.encode()
        data.extend(struct.pack('>Q', len(header)) + header + struct.pack('>Q', len(body)) + body)
    return bytes(data)


def stop_owned(process, reason):
    actions = []
    try:
        os.killpg(process.pid, signal.SIGTERM)
        actions.append('SIGTERM')
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        pass
    if group_resources(process.pid):
        try:
            os.killpg(process.pid, signal.SIGKILL)
            actions.append('SIGKILL')
        except ProcessLookupError:
            pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        actions.append('leader_join_timeout')
    deadline = time.monotonic() + 5
    while group_resources(process.pid) and time.monotonic() < deadline:
        time.sleep(0.05)
    return {'reason': reason, 'actions': actions, 'remaining_group': group_resources(process.pid)}


def run_owned(label, input_bytes):
    environment = {
        'PATH': '/usr/bin:/bin',
        'LANG': 'C',
        'WASMER_DIR': str(ROOT / 'runtime-home'),
        'WASMER_CACHE_DIR': str(ROOT / 'cache'),
        'TMPDIR': str(ROOT / 'tmp'),
        'RAYON_NUM_THREADS': '1',
        'TOKIO_WORKER_THREADS': '1',
    }
    command = [str(EXECUTABLE), 'run', '--wasmer-dir', str(ROOT / 'runtime-home'), '--cache-dir', str(ROOT / 'cache'), '--cranelift', '--compiler-threads', '1', '--disable-cache', '--offline', '--no-tty', '--volume', str(GUEST) + ':/workspace', '--cwd', '/workspace', str(MODULE), '--', '/workspace/js_cell_driver.mjs']
    input_path = ROOT / (label + '.stdin')
    input_path.write_bytes(input_bytes)
    report = {
        'label': label, 'command': command, 'environment': environment,
        'denied_network_syscalls': SECCOMP_DENIED_SYSCALLS,
        'limits': {'rss_monitor_bytes': RSS_LIMIT_BYTES, 'available_memory_reserve_bytes': AVAILABLE_MEMORY_RESERVE_BYTES, 'address_space_hard_bytes': ADDRESS_SPACE_LIMIT_BYTES, 'wall_seconds': WALL_LIMIT_SECONDS, 'cpu_soft_seconds': CPU_LIMIT_SECONDS, 'file_hard_bytes': 16 * 1024 * 1024, 'free_disk_reserve_bytes': DISK_RESERVE_BYTES, 'monitor_interval_seconds': 0.05},
        'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'free_disk_before': shutil.disk_usage(ROOT).free,
        'available_memory_before': available_memory(),
        'rss_peak_bytes_observed': 0,
        'memory_enforcement_note': 'RLIMIT_AS is a virtual address-space ceiling. RSS and system available-memory limits are sampled guards, not cgroup hard resident-memory limits.',
    }
    assert report['free_disk_before'] > DISK_RESERVE_BYTES
    assert report['available_memory_before'] > RSS_LIMIT_BYTES + AVAILABLE_MEMORY_RESERVE_BYTES
    started = time.monotonic()
    stop = None
    samples = []
    with input_path.open('rb') as source, (ROOT / (label + '.stdout')).open('xb') as out, (ROOT / (label + '.stderr')).open('xb') as err:
        process = subprocess.Popen(command, cwd=GUEST, env=environment, stdin=source, stdout=out, stderr=err, close_fds=True, start_new_session=True, preexec_fn=install_limits)
        report['owned_pid'] = process.pid
        try:
            last_sample = -1
            while process.poll() is None:
                elapsed = time.monotonic() - started
                members = group_resources(process.pid)
                rss = sum(member.get('VmRSS', 0) * 1024 for member in members)
                free_disk = shutil.disk_usage(ROOT).free
                free_memory = available_memory()
                report['rss_peak_bytes_observed'] = max(report['rss_peak_bytes_observed'], rss)
                if int(elapsed) != last_sample:
                    samples.append({'seconds': round(elapsed, 3), 'rss_bytes': rss, 'free_disk_bytes': free_disk, 'available_memory_bytes': free_memory, 'members': members})
                    last_sample = int(elapsed)
                reason = None
                if elapsed > WALL_LIMIT_SECONDS:
                    reason = 'wall_deadline'
                elif rss > RSS_LIMIT_BYTES:
                    reason = 'rss_observation_limit'
                elif free_disk < DISK_RESERVE_BYTES:
                    reason = 'free_disk_reserve'
                elif free_memory < AVAILABLE_MEMORY_RESERVE_BYTES:
                    reason = 'system_available_memory_reserve'
                if reason:
                    stop = stop_owned(process, reason)
                    break
                time.sleep(0.05)
            if process.poll() is None or group_resources(process.pid):
                stop = stop_owned(process, 'owned_group_after_leader_exit')
        finally:
            if process.poll() is None or group_resources(process.pid):
                stop = stop_owned(process, 'finally_cleanup')
        report.update(exit_code=process.returncode, elapsed_seconds=time.monotonic() - started, stopped=stop, group_remaining=group_resources(process.pid), free_disk_after=shutil.disk_usage(ROOT).free, available_memory_after=available_memory())
    report['samples'] = samples
    (ROOT / (label + '.observation.json')).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['label', 'exit_code', 'elapsed_seconds', 'stopped', 'rss_peak_bytes_observed', 'free_disk_after']}), flush=True)
    return report


lock = open('/tmp/shenko-cargo.lock', 'a')
print('Waiting for the shared resource lock; no Wasmer guest has started.', flush=True)
fcntl.flock(lock, fcntl.LOCK_EX)
print('Acquired the shared resource lock.', flush=True)
assert hashlib.sha256(EXECUTABLE.read_bytes()).hexdigest() == '72c57ef6be45d500cb528c0a684b13159620ddfb4b50d3e429a3a352d0b3f116'
assert hashlib.sha256(MODULE.read_bytes()).hexdigest() == '3e0b4c9f9c258fef4ecf522bf86c42844d50368138abb86d5c2700775cf84a1d'
driver = DRIVER_SOURCE.read_bytes()
assert hashlib.sha256(driver).hexdigest() == json.loads((ARTIFACT_ROOT / 'journey-manifest.json').read_text())['driver_sha256']
(GUEST / 'js_cell_driver.mjs').write_bytes(driver)
(GUEST / 'env').mkdir(mode=0o700)
(GUEST / 'env/package.json').write_text('{"name":"node-wasix-probe","private":true}\n')
(GUEST / 'cells').mkdir(mode=0o700)
source_head = subprocess.run(['git', '-C', str(REPOSITORY), 'rev-parse', 'HEAD'], check=True, capture_output=True, text=True).stdout.strip()
manifest = {'driver_repository_head': source_head, 'driver_path': str(DRIVER_SOURCE.relative_to(REPOSITORY)), 'driver_sha256': hashlib.sha256(driver).hexdigest(), 'product_capability_installed': False, 'named_target_acceptance': False, 'purpose': 'One isolated Node WASIX artifact feasibility journey using the unchanged Shenko JS cell driver; not an installed Shenko backend or an S1/model acceptance.'}
(ROOT / 'journey-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
first_source = '''let probeValue = 37 * 41;
console.log(JSON.stringify({phase: "node-wasix-runtime", release: process.release.name, version: process.version, versions: process.versions, arch: process.arch, platform: process.platform}));
require("node:fs").writeFileSync("/workspace/witness.json", JSON.stringify({value: probeValue}), {flag: "wx"});
if (JSON.parse(require("node:fs").readFileSync("/workspace/witness.json", "utf8")).value !== 1517) throw new Error("real fs readback mismatch");
console.log(JSON.stringify({phase: "first-cell", value: probeValue, fs_readback: true}));
'''
second_source = '''probeValue += 1;
if (probeValue !== 1518) throw new Error("live lexical state was lost");
console.log(JSON.stringify({phase: "second-cell", value: probeValue}));
'''
first = run_owned('first', frames([(1, first_source), (2, second_source)]))
checks = {'first_exit_zero': first['exit_code'] == 0, 'owned_group_stopped': not first['group_remaining']}
if first['exit_code'] == 0:
    for seq in (1, 2):
        path = GUEST / 'cells' / (str(seq) + '.report.json')
        report = json.loads(path.read_text()) if path.exists() else {}
        checks['cell_' + str(seq) + '_report_ok'] = report.get('ok') is True and report.get('state_verified') is True
    state_path = GUEST / 'state.json'
    checks['checkpoint_1518'] = state_path.exists() and json.loads(state_path.read_text()).get('probeValue') == 1518
    output_path = GUEST / 'cells/1.out'
    values = []
    if output_path.exists():
        for line in output_path.read_text().splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                values.append(value)
    runtime = next((value for value in values if value.get('phase') == 'node-wasix-runtime'), {})
    versions = runtime.get('versions', {})
    checks['observed_real_node_versions'] = runtime.get('release') == 'node' and isinstance(versions.get('node'), str) and isinstance(versions.get('v8'), str) and bool(versions.get('v8')) and runtime.get('version') == 'v' + versions.get('node', '')
    checks['first_cell_output'] = any(value.get('phase') == 'first-cell' and value.get('value') == 1517 and value.get('fs_readback') is True for value in values)
if checks and all(checks.values()):
    third_source = '''probeValue += 1;
if (probeValue !== 1519) throw new Error("reopened JSON checkpoint was not restored");
if (JSON.parse(require("node:fs").readFileSync("/workspace/witness.json", "utf8")).value !== 1517) throw new Error("original fs witness changed");
console.log(JSON.stringify({phase: "reopened-cell", value: probeValue, original_fs_witness: 1517}));
'''
    reopened = run_owned('reopened', frames([(3, third_source)]))
    path = GUEST / 'cells/3.report.json'
    report = json.loads(path.read_text()) if path.exists() else {}
    checks['reopened_exit_zero'] = reopened['exit_code'] == 0
    checks['reopened_group_stopped'] = not reopened['group_remaining']
    checks['reopened_cell_ok'] = report.get('ok') is True and report.get('state_verified') is True
    checks['reopened_checkpoint_1519'] = (GUEST / 'state.json').exists() and json.loads((GUEST / 'state.json').read_text()).get('probeValue') == 1519
summary = {'checks': checks, 'feasibility_passed': bool(checks) and all(checks.values()), 'product_capability_installed': False, 'named_target_acceptance': False, 'compiled_cache_files': [str(path.relative_to(ROOT)) for path in (ROOT / 'cache').rglob('*') if path.is_file()]}
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
