import datetime
import hashlib
import json
from pathlib import Path
import tarfile
import time
import urllib.request

ROOT = Path(__file__).parent
URL = "https://github.com/wasmerio/wasmer/releases/download/v7.5.0/wasmer-linux-amd64.tar.gz"
EXPECTED_BYTES = 302721336
EXPECTED_SHA256 = "23f99818deaad93859f8bb8292af81f0c39f25aea19eaccfb72fc7c9e8a3fae9"


class HashingReader:
    def __init__(self, source):
        self.source = source
        self.hash = hashlib.sha256()
        self.bytes = 0

    def read(self, size=-1):
        data = self.source.read(size)
        self.bytes += len(data)
        if self.bytes > EXPECTED_BYTES:
            raise ValueError("archive exceeded its published asset size")
        self.hash.update(data)
        return data


started = time.monotonic()
entries = []
with urllib.request.urlopen(URL, timeout=30) as response:
    source = HashingReader(response)
    with tarfile.open(fileobj=source, mode="r|gz") as archive:
        for member in archive:
            entry = {
                "name": member.name,
                "bytes": member.size,
                "type": member.type.decode("ascii", errors="backslashreplace"),
                "linkname": member.linkname,
                "mode": oct(member.mode),
            }
            entries.append(entry)
            if "/bin/" in member.name or member.name.startswith("bin/"):
                print(json.dumps(entry), flush=True)
    while source.read(1024 * 1024):
        pass
report = {
    "observed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "url": URL,
    "expected_bytes": EXPECTED_BYTES,
    "actual_bytes": source.bytes,
    "expected_sha256": EXPECTED_SHA256,
    "actual_sha256": source.hash.hexdigest(),
    "elapsed_seconds": time.monotonic() - started,
    "extracted": False,
    "executed": False,
    "entries": entries,
}
(ROOT / "wasmer-archive-inventory.json").write_text(json.dumps(report, indent=2) + "\n")
if source.bytes != EXPECTED_BYTES or source.hash.hexdigest() != EXPECTED_SHA256:
    raise ValueError("official archive size or digest did not match")
print(json.dumps({"verified": True, "entries": len(entries), "regular_file_bytes": sum(e["bytes"] for e in entries if e["type"] == "0"), "elapsed_seconds": report["elapsed_seconds"]}), flush=True)
