# Named Node/Bun WASM feasibility observation — 2026-11-16

This directory contains a bounded, isolated attempt to run a published Node-WASIX artifact with Shenko's unchanged JavaScript cell driver. It did not install a Shenko capability. No JavaScript cell, filesystem witness, checkpoint or reopen has succeeded. It does not satisfy issue #19, the 27B baseline, S1, or S2.

## Observed outcomes

| Attempt | Virtual address ceiling | Sampled RSS stop threshold | Actual observation |
| --- | --- | --- | --- |
| Initial | 8 GiB | 1.5 GiB | Exit 1 after 56.38 s: Wasmer could not allocate its requested memory. Observed peak RSS 1,280,180,224 bytes. No forced stop. |
| Address-space correction | 12 GiB | Same 1.5 GiB | Harness sent SIGTERM after 55.54 s when sampled RSS reached 1,613,180,928 bytes. Exit -15. This is an experiment guard, not observed physical OOM. |

Both owned process groups were observed empty after cleanup. Both compiled cache directories contain no files. The first attempt's original stdout, stderr, samples and harness are retained; the correction has a separate directory. No output from a Node JavaScript cell was observed in either attempt, and the conditional reopen phase did not run.

The initial virtual ceiling was incompatible with the pinned runtime's source: one static wasm32 reservation needs 4 GiB of address space plus a 4 GiB offset guard plus one 64 KiB page, or 8,590,000,128 bytes, already larger than an 8 GiB RLIMIT_AS before other process mappings. Increasing only that virtual limit was a source-supported diagnostic correction. It did not raise the resident-memory guard or alter the guest.

After the second attempt, a read-only reassessment observed approximately 3.35–3.36 GiB system MemAvailable and obtained the shared resource lock exclusively. However, this execution namespace exposes no cgroup filesystem, its visible cgroup paths are only `0::/`, and ancestor `memory.max`, `memory.current`, `memory.high` and memory pressure are unavailable. System MemAvailable therefore does not establish the process's actual ancestor headroom. Under the agreed requirement to verify remaining capacity before another resource increase, no third guest was started. The unknown limit is a property of this observation surface, not evidence that Node-WASIX cannot run or that the machine necessarily lacks physical memory.

## Exact artifacts

### Runtime

- Official Wasmer v7.5.0 source release commit: `82ff099e082da586b38af79986abbb8b677f8baf`.
- Archive: <https://github.com/wasmerio/wasmer/releases/download/v7.5.0/wasmer-linux-amd64.tar.gz>.
- Published archive size: 302,721,336 bytes; SHA256 `23f99818deaad93859f8bb8292af81f0c39f25aea19eaccfb72fc7c9e8a3fae9`.
- Both complete streaming passes matched that digest. One inventoried the archive; one extracted only the executable, LICENSE and ATTRIBUTIONS. No compressed archive was retained, and the 1,092,201,791-byte full SDK was not installed.
- Extracted `bin/wasmer`: 219,153,104 bytes; SHA256 `72c57ef6be45d500cb528c0a684b13159620ddfb4b50d3e429a3a352d0b3f116`.
- Actual `--version` and `run --help` both exited 0. The CLI needs existing system C/C++ libraries, not the SDK's large libraries.

The memory reservation explanation is grounded in the pinned source:

- <https://github.com/wasmerio/wasmer/blob/82ff099e082da586b38af79986abbb8b677f8baf/lib/types/src/memory.rs>, lines 27–43.
- <https://github.com/wasmerio/wasmer/blob/82ff099e082da586b38af79986abbb8b677f8baf/lib/compiler/src/engine/tunables.rs>, lines 214–218.
- <https://github.com/wasmerio/wasmer/blob/82ff099e082da586b38af79986abbb8b677f8baf/lib/vm/src/memory.rs>, lines 333–352.

### Candidate Node module

- Source project: <https://github.com/Multi-V-VM/node-wasix32>, a third-party Node/V8 port, not an official nodejs.org binary.
- Executed candidate asset: <https://github.com/Multi-V-VM/node-wasix32/releases/download/wasix32/node.wasm>.
- Release tag `wasix32` points to `0d66fea37737024056983f35e84af3e8448ece08`; asset ID 548057668.
- Downloaded and verified size: 112,379,740 bytes; published and actual SHA256 `3e0b4c9f9c258fef4ecf522bf86c42844d50368138abb86d5c2700775cf84a1d`.
- The tag's tracked `node.wasm` is a different 100,589,868-byte object. No source-build attestation or reproduction was found. The checksum establishes release-asset identity; it does not prove which source produced that asset.
- The release binary's parsed import section contains 83 imports across `env`, `wasi_snapshot_preview1`, `wasix_32v1` and `wasi`. Shared imported memory starts at 1,719 pages and has a maximum of 65,536 pages. Thread spawning, futexes, process and socket interfaces are among its imports. `_start` and `wasi_thread_start` are exported.
- `node-wasm-abi.json` is an import/export prefix observation, not an independent whole-module validation. The attempted runtime reached memory creation, but no successful `process.versions` observation was obtained.

The separately inspected current main commit `20871d1fb49e1af91b1fc729b0cf4e119c0bfd6f` contains a different 81,079,064-byte tracked module and a Node 25.0.0-pre source declaration. Those observations must not be presented as the executed release asset's measured runtime version.

### Original driver and planned journey

- Shenko driver source head: `ce18c5ec89163d19f07037e5e9489ef33c376fc9`.
- Path: `crates/shenko-repl/src/drivers/js_cell_driver.mjs`.
- Exact driver SHA256: `a9419c9aa0abbced7c69145806768153971d37121a8c20e63e0c623f0991f150`.
- First cell would expose Node's own runtime identity, compute 1,517, write and read an exclusive temporary file.
- Second cell would continue the same lexical binding to 1,518 and checkpoint it.
- A second invocation, conditional on complete success of the first, would restore the checkpoint to 1,519 while retaining the original 1,517 filesystem witness.

The full original framed input is retained in each `first.stdin`; the same guest code was used for both attempts. No host Node executable or alternate JavaScript engine was substituted.

## Isolation and resource accounting

The runtime had only its owned guest directory mapped at `/workspace`, an explicit argument vector and a replaced environment containing no ambient credentials. It ran offline with cache disabled, no TTY, one Cranelift compiler thread, and no mapped host commands. A seccomp filter denied network socket/connect/bind/listen/accept/send syscalls. Wasmer state, cache and temporary files were directed to owned directories.

Each invocation owned a new process group. Wall time was 180 s, CPU time 150 s with a 155 s hard ceiling, file size 16 MiB, and open-file count 256. The monitor sampled group RSS, system MemAvailable and disk space every 50 ms; retained samples are approximately one second apart. It reserved 768 MiB system memory and 256 MiB disk. RSS and MemAvailable checks are sampled guards, not hard resident-memory cgroup enforcement. TERM/KILL and group cleanup waits were bounded. The shared `/tmp/shenko-cargo.lock` covered runtime execution and cleanup.

The full command, environment, limits, every retained sample, actual exit code and cleanup state are in each `first.observation.json`. The historical `executed: false` fields in extraction/download records describe their creation stage; subsequent attempts are recorded separately. Likewise, `memory-reservation-diagnosis.json` was written before its authorized retry and intentionally retains `result: not_yet_run`.

## Product and upstream gaps

Shenko's current named `node-wasm` and `bun-wasm` entries remain unavailable. Its implemented WASM runtime and cell adapter are WASI Preview 1; `ToolAbi::Wasix` is descriptive and does not provide a WASIX linker. The `JsCellV1` driver currently binds to native-host execution, and npm/bun dependency installation is also native-host-only. The Node candidate's shared memory, thread, futex and process imports cannot be satisfied merely by declaring it a Preview 1 module. A future successful standalone probe would still require a genuine backend, frozen module/runtime identity, controlled cancellation/resources, dependency-generation semantics, and the required recovery evidence before installation availability changes.

Relevant repository locations are `shenko-repl/src/{kernel,adapters,contract,install}.rs` and `shenko-wasm/src/{tool,runtime}.rs`. Issue #19 explicitly distinguishes Node running *inside* WASM from native Node loading WASM and retains Bun as an independent requirement: <https://github.com/cyjin-yl/shenko/issues/19>.

Official Node's inspected source commit `428dd8648909a321fa2c558bf01abebb17a74647` does not list wasm32/WASI among configure targets. Its V8 configuration also lacks a wasm32 target. The third-party port is therefore a concrete separate candidate, not an ordinary official cross-build:

- <https://github.com/nodejs/node/blob/428dd8648909a321fa2c558bf01abebb17a74647/configure.py>.
- <https://github.com/nodejs/node/blob/428dd8648909a321fa2c558bf01abebb17a74647/BUILDING.md>.
- <https://github.com/nodejs/node/blob/428dd8648909a321fa2c558bf01abebb17a74647/deps/v8/include/v8config.h>.

Official Bun's inspected source commit `237bba51e98a8b3d5b62d2d6c33853c2e83820a7` lists native operating systems and x64/aarch64 build architectures. Its JavaScriptCore dependency is selected for those native targets. The historically named `bun-wasm` package exposes transformation/scanning APIs, not the full Bun runtime. No qualifying current full-runtime artifact was identified by this bounded primary-source review:

- <https://github.com/oven-sh/bun/blob/237bba51e98a8b3d5b62d2d6c33853c2e83820a7/scripts/build/config.ts>.
- <https://github.com/oven-sh/bun/blob/237bba51e98a8b3d5b62d2d6c33853c2e83820a7/scripts/build/deps/webkit.ts>.
- <https://github.com/oven-sh/bun/blob/237bba51e98a8b3d5b62d2d6c33853c2e83820a7/docs/project/contributing.mdx>.
- <https://github.com/oven-sh/bun/blob/a04817ce2b7f1a1e8b7cbf8af8f2c027ab072f1d/packages/bun-wasm/index.ts>.

The Wasmer Edge.js architecture is also a separate product: its JavaScript engine executes natively while system/native operations use a sandbox. It is not a substitute for the named target: <https://wasmer.io/posts/edgejs-safe-nodejs-using-wasm-sandbox>.

## Next executable slice, not yet run

Reuse exactly this pinned artifact, original driver and framed input on an authorized runner that exposes its actual memory/ancestor limits and has verified working headroom. Stream-verify and selectively extract the same Wasmer archive; verify the same Node asset digest. Set all writable runtime/cache/temp locations to owned storage and keep cache disabled. The virtual-address limit must accommodate Wasmer's proven static mapping; resident and system-reserve bounds must derive from that runner's actual limits. Retain the same no-network, filesystem, wall-time, CPU-time and owned-process boundaries, and retain every failure.

The first useful outcome is a real Node `process.versions` plus both finite-cell reports and filesystem witness. Only complete first-invocation success permits the already-planned checkpoint/reopen phase. A failed resource, ABI, startup or driver boundary should be classified from its actual output; it must not be converted into a passing capability. No workflow was created or dispatched for this plan, and no further local guest was launched after the resource reassessment.
