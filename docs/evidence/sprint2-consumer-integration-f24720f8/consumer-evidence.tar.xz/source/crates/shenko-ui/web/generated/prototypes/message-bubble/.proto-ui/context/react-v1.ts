import { createContext } from 'react';
import type { ContextScope } from './scope-v1';
export const ContextTransport = createContext<ContextScope | null>(null);
