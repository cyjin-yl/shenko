import { message as m, preferredLocale, type LocalizedText, type UiLocale } from './messages';

/**
 * Shenko's stable application-semantic UI boundary.
 *
 * This is deliberately not Proto-UI's private PrototypeIR and is not accepted
 * by upstream compilePrototype: the build-time compiler (web/compiler.mjs)
 * compiles Shenko's own Prototype *source* into React DOM source, while server
 * projections keep their own schema. Pages and service DTOs never expose IR.
 */
export const UI_PROJECTION_SCHEMA = 'shenko.ui-projection/v2' as const;
export const UI_INTENT_SCHEMA = 'shenko.ui-intent/v1' as const;

export type ViewName = 'timeline' | 'tasks' | 'memory' | 'config' | 'playground';

/// The Proto-UI playground surface. Every fact below comes
/// from the durable records; the view renders them, it does not invent a
/// second artifact index.
/// One work of the subject, as the timeline carries it.
///
/// The timeline shows the subject's works and lets the reader OPEN one. The
/// revision is the work's own durable revision: an action is bound to it, so
/// a work that moved on refuses the stale action.
export interface WorkView {
  artifact_id: string;
  title?: string;
  mime?: string;
  revision?: number;
  active_manifest_digest?: string;
  lifecycle?: string;
  updated_at?: string;
}

/// A work the reader opened.
///
/// It carries the work's own revision: an action is bound to the revision
/// the reader saw, so a work that moved on refuses the stale action.
/// The ownership facts of this installation.
///
/// `claimed` is a fact, not a hope: an unclaimed installation says so, and
/// the claim capability's own state is reported separately.
export interface OwnerState {
  available?: boolean;
  claimed?: boolean;
  claim_pending?: boolean;
  installation_id?: string;
  error?: string;
}

export interface OpenedWork {
  artifact_id: string;
  title?: string;
  mime?: string;
  revision?: number;
  lifecycle?: string;
  /** The content as the reader may read it. */
  content?: string;
  /** The staged candidates a publish may adopt. */
  candidates?: { digest: string }[];
  /** The revisions the work carries. */
  revisions?: number[];
}

export interface PlaygroundView {
  available?: boolean;
  roots?: Array<{ artifact_id: string; root: string; identity: string }>;
  artifacts?: Array<{
    artifact_id: string;
    title?: string;
    mime?: string;
    revision?: number;
    active_manifest_digest?: string;
    parent_revision?: number | null;
    updated_at?: string;
    backend?: boolean;
    lifecycle?: string;
    record?: unknown;
  }>;
  namespaces?: Array<{ namespace: string; description?: string; logical_keys?: string[] }>;
}
export type ReadingState = 'following_latest' | 'reading_history' | 'selecting_or_interacting';
export type ConnectionState = 'connecting' | 'online' | 'reconnecting' | 'offline';

/** Derived by the ledger from ownership and admission, never a plugin name. */
export type TaskRole = 'subject_root' | 'delegation' | 'tool' | 'unknown';

export type TaskSummary = {
  task_id: string;
  kind: string;
  role: TaskRole;
  state: string;
  parent_task_id?: string | null;
  created_by_step_id?: string | null;
  created_at: string;
  terminal_at?: string | null;
  /** The name the delegator gave a delegated task, from its frozen input. */
  name?: string | null;
  /** Its team: tasks one decision started with the same team are peers. */
  team?: string | null;
  /** The first line of a delegated task's goal, from its frozen input. */
  goal?: string | null;
};

// Durable admission stages: accepted/selected/committed are
// separate fact receipts, never a single progress bar.
export type ReceiptState =
  | 'sending'
  | 'sent'
  | 'accepted'
  | 'selected'
  | 'committed'
  | 'conflict'
  | 'rejected'
  | 'unknown';

export interface TimelinePart {
  role: 'subject';
  content: string;
  message_id: string;
  part_id: string;
  part_revision: string;
  next_chunk_seq: number;
  /** The terminal chunk of the part has been durably observed. */
  terminal?: boolean;
  /** A committed message bound this part to an S1 step (either it carried the
   *  full committed text, or a streamed prefix was absorbed by it). A part
   *  without this binding is durable ledger content but not a committed step:
   *  the view never prints a step number or m('timeline.committed') for it. */
  committed: boolean;
  step: number;
  step_id: string;
  commit_ref: string;
  /** Position in this receiving ledger; the source commit may be foreign. */
  commit_seq?: number;
  observed_at: string;
  stream_id?: string;
  request_id?: string;
  attempt_id?: string;
  gap: boolean;
}

/**
 * A reading place keyed by a stable rendered entry identity, never by
 * scroll offset alone. `offset` is the anchor entry's top relative to the
 * viewport top, so history backfilled above it does not move the reader.
 */
export interface ReadingAnchor {
  entry_key: string;
  entry_index: number;
  prev_entry_key?: string;
  offset: number;
  scroll_top: number;
}

/**
 * A text selection recorded against one rendered entry. It is a display fact,
 * not a place: it is replayed only when the same characters still start the
 * entry, so a rewritten entry never receives a stale highlight.
 */
export interface ReadingSelection {
  entry_key: string;
  start: number;
  end: number;
  /** Fingerprint of the entry text up to `end`. */
  prefix_hash: string;
}

/**
 * The visible outcome of one semantic-document action attempt. Acceptance is
 * durable admission of an input, not execution; execution is the subject's
 * disposition of that input.
 */
export interface ActionReceiptView {
  submission_id: string;
  document_id: string;
  action_id: string;
  revision: string;
  stage:
    | 'sending'
    | 'accepted'
    | 'selected'
    | 'committed'
    | 'rejected'
    | 'unavailable'
    | 'conflict';
  detail?: LocalizedText;
  /** Durable admission facts once the Store has reported them. */
  event_id?: string;
  accepted_commit?: string;
}

export interface SubmissionPayload {
  schema_version: 2;
  type: 'submit';
  submission_id: string;
  message_id: string;
  subject_id: string;
  mode: 'append' | 'steer';
  content: string;
  attachment_refs: WebAttachmentRef[];
  observed_step_id?: string;
}

/** A file the server sealed for the owner; a submission may name it. */
export interface WebAttachmentRef {
  digest: string;
  name: string;
  media_type: string;
  bytes: number;
}

/** A file in the composer: uploading, sealed and ready, or failed. */
export interface PendingAttachment {
  local_id: string;
  name: string;
  media_type: string;
  bytes: number;
  status: 'uploading' | 'ready' | 'failed';
  ref?: WebAttachmentRef;
  /** A local object URL for an image preview; never sent anywhere. */
  preview?: string;
  error?: string;
}

/** Where an admitted input is actually handled (placement). */
export interface SubmissionPlacement {
  requested: 'append' | 'steer';
  actual: 'pending' | 'next_boundary' | 'live_steer' | 'cancel_reseal';
  target_request_id?: string;
}

/** Durable withdrawal record; never deletes the admitted fact. */
export interface WithdrawalView {
  cancel_id: string;
  commit_ref: string;
  result: 'withdrawn_before_presentation' | 'withdrawal_queued';
}

export interface Submission {
  payload: SubmissionPayload;
  created_at: string;
  accepted_seq?: number;
  receipt: ReceiptState;
  detail?: LocalizedText;
  event_id?: string;
  accepted_commit?: string;
  selected_step_id?: string;
  committed_at?: string;
  placement?: SubmissionPlacement;
  withdrawal?: WithdrawalView;
  /** Browser recovery only; never included in the submit/withdraw wire. */
  edit?: {
    cancel_id: string;
    /** closed: queued cancellation or cleared draft; retired: replacement disposed. */
    state: 'pending' | 'ready' | 'editing' | 'finished' | 'closed' | 'retired';
    submission_id: string;
    message_id: string;
    draft: { content: string; attachment_refs: WebAttachmentRef[] };
  };
  // Correlation between this client's send attempts and the query_replies:
  // a view for an older attempt must not undo a newer send's restored ACK.
  send_epoch: number;
}

export interface SubmissionCursor {
  seq: number;
  submission_id: string;
}

// SQLite's binary UTF-8 order follows Unicode scalar values. JavaScript's
// default UTF-16 comparison differs for supplementary characters in IDs.
export function compareSubmissionOrder(leftSeq: number, leftId: string, rightSeq: number, rightId: string): number {
  if (leftSeq !== rightSeq) return leftSeq - rightSeq;
  let left = 0;
  let right = 0;
  while (left < leftId.length && right < rightId.length) {
    const a = leftId.codePointAt(left)!;
    const b = rightId.codePointAt(right)!;
    if (a !== b) return a - b;
    left += a > 0xffff ? 2 : 1;
    right += b > 0xffff ? 2 : 1;
  }
  return leftId.length - rightId.length;
}

export interface SubmissionHistoryState {
  loading: boolean;
  /** A rendered commit is newer than the applied newest-page snapshot. */
  stale?: boolean;
  total?: number;
  has_older: boolean;
  next_before?: SubmissionCursor;
  newest_cursor?: SubmissionCursor;
  error?: LocalizedText;
}

// numbered options preserve action identity across degradation.
export interface ActionOption {
  index: number;
  action_id: string;
  nonce: string;
  revision: string;
  label: string;
  required_capabilities: string[];
  /** Canonical payload from the committed binding; the server re-hashes it
   *  at admission and never trusts a client-supplied digest. */
  payload: Record<string, unknown>;
}

export type DegradedMode = 'rich' | 'card' | 'text';

/** A validated semantic document degraded to this surface's facts. */
export interface DegradedDocument {
  mode: DegradedMode;
  document_id: string;
  revision: string;
  options: ActionOption[];
  summary: string;
  nodes?: unknown[];
  /** The committed step whose public text contained this document; the
   *  timeline renders the surface next to that step, not at list end. */
  source_step_id?: string;
  source_commit?: string;
}

export interface DocumentErrorView {
  source_step_id: string;
  source_commit: string;
  reason: string;
}

/** Server-advertised capability facts from the WS hello (schema v2). */
export interface ServerCapabilities {
  append: boolean;
  steer: boolean;
  withdraw: boolean;
  actions: boolean;
  documents: boolean;
  attachments: boolean;
  durable_input_receipts: boolean;
  committed_replay: boolean;
  streaming: boolean;
}

export interface IdentityView {
  agent_id?: string;
  revision?: number;
  display_name?: string;
  naming?: string;
  soul?: string;
}

export interface ConfigView {
  model?: string;
  data_dir?: string;
  generation?: string;
  api_key_configured?: boolean;
}

/// One configuration key as the service reports it: the saved desired
/// revision and value, what each consumer adopted, and the value a consumer
/// actually runs. The panel edits through the same service the subject's
/// `config.manage` tool drives; there is no second configuration source.
export interface ConfigEntryView {
  namespace: string;
  logical_key: string;
  application?: string;
  entry?: { desired_revision?: number; desired_value_ref?: unknown } | null;
  desired_value?: unknown;
  current_value?: unknown;
  adoptions?: Array<{ consumer_id?: string; adopted_revision?: number; detail?: string }>;
  code?: string;
  error?: string;
}

export interface SelfView {
  status?: string;
  identity?: IdentityView;
  subject_id?: string;
  connected_clients?: number;
  step?: number;
  last_outbox_observed_at?: string;
  data_dir?: string;
  model?: string;
  devices?: Array<{ id: string; label?: string; name?: string; online?: boolean; kind?: string }>;
  activities?: unknown[];
  artifacts?: Array<{ id: string; title?: string; kind?: string }>;
}

export interface BuildManifest {
  schema_version: 1;
  upstream: { repository: string; commit: string; lock_sha256: string };
  packages: string[];
  adopted_families: string[];
  compiler: BuildCompilerFacts;
}

/**
 * Compiler facts recorded by the build (`web/build.mjs` + `web/compiler.mjs`).
 * Every field is a measurement of that build; a missing field stays missing and
 * is never inferred. `runtime_imported` states whether the browser bundle
 * imports the compiler, not whether a compiler exists.
 */
export interface BuildCompilerFacts {
  status: string;
  runtime_imported: boolean;
  profile?: string;
  package?: string;
  entry?: string;
  entry_sha256?: string;
  source_tree_sha256?: string;
  typescript?: string;
  bundle?: { path: string; sha256: string; bytes?: number };
  public_package_selection?: {
    script?: string;
    selected_package_count?: number | null;
    includes_compiler: boolean;
    note?: string;
  };
  prototypes?: Array<{
    name: string;
    entry: string;
    entry_sha256: string;
    profile: string;
    component_name: string;
    generated_source: string;
    generated_sha256: string;
    generated_imports?: string[];
  }>;
}

export interface DisplayState {
  view: ViewName;
  panel_open: boolean;
  open_sections: Record<string, boolean>;
  theme: 'dark' | 'light';
  reading: ReadingState;
  new_count: number;
  scroll_request: number;
  /** Long code lines soft-wrap; a persisted reading preference, not content. */
  wrap: boolean;
  /** Restored (or recorded) reading place for this surface, if any. */
  anchor?: ReadingAnchor;
  /** Restored text selection, replayed only while the entry text matches. */
  selection?: ReadingSelection;
  notice?: LocalizedText;
}

export interface UiState {
  source: 'live' | 'demo';
  connection: ConnectionState;
  reconnect_seconds: number;
  server_version?: string;
  capabilities: ServerCapabilities;
  surface?: unknown;
  append_available: boolean;
  durable_receipts: boolean;
  committed_replay: boolean;
  /** True only when the server advertised a durable stream sink AND the
   *  provider capability fact says streaming. Never drives a typewriter. */
  streaming: boolean;
  documents: DegradedDocument[];
  document_errors: DocumentErrorView[];
  action_receipts: ActionReceiptView[];
  subject_id: string | null;
  identity?: IdentityView;
  wanted_identity_revision: number | null;
  step: number | null;
  timeline: TimelinePart[];
  submissions: Submission[];
  submission_history?: SubmissionHistoryState;
  draft: string;
  /** Files in the composer, in the order the owner added them. */
  attachments: PendingAttachment[];
  config?: ConfigView;
  config_error: boolean;
  /// Registered configuration keys with their saved/adopted/running facts.
  config_entries?: ConfigEntryView[];
  config_entries_error?: boolean;
  /// In-progress panel edits, keyed `namespace/logical_key`. A draft is never
  /// a saved revision; only an explicit apply submits it.
  config_drafts?: Record<string, string>;
  self?: SelfView;
  self_error: boolean;
  tasks?: { available?: boolean; items?: TaskSummary[]; note?: string };
  tasks_error: boolean;
  memory?: { items?: Array<Record<string, unknown>>; note?: string };
  memory_error: boolean;
  playground?: PlaygroundView;
  /** The work the reader opened, and the fact of opening it. */
  work?: OpenedWork;
  work_error?: boolean;
  /** The ownership facts: whether this installation is claimed. */
  owner_state?: OwnerState;
  /** The name the reader is trying to give the instance. */
  name_draft?: string;
  /** The claim capability the reader pasted, if any. */
  claim_draft?: string;
  playground_error: boolean;
  manifest?: BuildManifest;
  display: DisplayState;
}

export interface UiAction {
  action_id: string;
  kind: string;
  revision: string;
  enabled: boolean;
  payload?: Record<string, unknown>;
}

export interface UiNode {
  node_id: string;
  kind: string;
  props: Record<string, any>;
  a11y: Record<string, LocalizedText | number | boolean>;
  layout: Record<string, string | number | boolean>;
  action_refs: string[];
  fallback?: string;
  children: UiNode[];
}

export interface UiCapabilities {
  append: boolean;
  steer: boolean;
  withdraw: boolean;
  actions: boolean;
  documents: boolean;
  streaming: boolean;
  attachments: boolean;
  durable_input_receipts: boolean;
  committed_replay: boolean;
}

export interface UiProjection {
  locale: UiLocale;
  schema_version: typeof UI_PROJECTION_SCHEMA;
  surface_id: string;
  revision: number;
  source: 'live' | 'demo';
  subject_id: string | null;
  identity?: IdentityView;
  connection: ConnectionState;
  nodes: UiNode[];
  capabilities: UiCapabilities;
  actions: Record<string, UiAction>;
  assets: Record<string, { kind: string; ref: string; revision: string }>;
}

export interface UiIntent {
  schema_version: typeof UI_INTENT_SCHEMA;
  surface_id: string;
  node_id: string;
  action_id: string;
  action_revision: string;
  payload: Record<string, unknown>;
}

export interface UiDiagnostic {
  level: 'error' | 'warning' | 'info';
  message: string;
  node_id?: string;
}

/** Optional next-version compiler boundary. No private compiler types leak here. */
export interface UiCompilerAdapter<Artifacts = unknown> {
  compile(projection: UiProjection): Promise<{
    artifacts: Artifacts;
    diagnostics: UiDiagnostic[];
  }>;
}

export interface ProjectionController {
  projection(): UiProjection;
  subscribe(listener: () => void): () => void;
  dispatch(intent: UiIntent): void;
  dispose(): void;
}

export type Dispatch = (intent: UiIntent) => void;

export function node(
  node_id: string,
  kind: string,
  props: Record<string, any> = {},
  children: UiNode[] = [],
  options: Partial<Pick<UiNode, 'a11y' | 'layout' | 'action_refs' | 'fallback'>> = {},
): UiNode {
  return {
    node_id,
    kind,
    props,
    children,
    a11y: options.a11y ?? {},
    layout: options.layout ?? {},
    action_refs: options.action_refs ?? [],
    fallback: options.fallback,
  };
}

export function semanticHash(text: string): string {
  // Synchronous, non-secret action binding only; this is not a content digest.
  let hash = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

/**
 * What the view may claim about one entry: committed text carries an
 * S1 step, a durable streamed prefix does not, and a chunk gap means the text
 * on screen is provably incomplete.
 */
export function partState(part: TimelinePart): {
  committed: boolean;
  streaming: boolean;
  gap: boolean;
} {
  return {
    committed: part.committed,
    streaming: part.stream_id !== undefined && !part.committed,
    gap: part.gap,
  };
}

function addAction(
  actions: Record<string, UiAction>,
  action_id: string,
  kind: string,
  revision: string,
  enabled = true,
  payload?: Record<string, unknown>,
): string {
  actions[action_id] = { action_id, kind, revision, enabled, payload };
  return action_id;
}

function entryNodes(state: UiState, actions: Record<string, UiAction>): UiNode[] {
  const subjectRows = state.timeline.filter((part) => part.content.length > 0).map((part) => {
    const identity = JSON.stringify([part.message_id, part.part_id]);
    const copyAction = addAction(
      actions,
      `part.copy.${identity}`,
      'part.copy',
      `copy:${part.part_revision}`,
      true,
      { content: part.content },
    );
    return node(`part.${identity}`, 'subject_part', { part }, [], {
      action_refs: [copyAction],
      a11y: { label: part.committed ? m('timeline.committedAnnouncement', { step: part.step }) : m('timeline.streamAnnouncement') },
      fallback: 'raw_text',
    });
  });
  const submissionRows = state.submissions.map((submission) => {
    const refs: string[] = [];
    let retryAction: string | undefined;
    let withdrawAction: string | undefined;
    const hasReplacement = submission.edit && state.submissions.some(
      (row) => row.payload.submission_id === submission.edit?.submission_id);
    if ((!submission.edit || !hasReplacement && submission.edit.state === 'pending' && !submission.withdrawal)
      && (submission.receipt === 'rejected' || submission.receipt === 'unknown')) {
      retryAction = addAction(
        actions,
        `submission.retry.${submission.payload.submission_id}`,
        'submission.retry',
        `retry:${submission.payload.submission_id}:${semanticHash(submission.payload.content)}:append`,
        state.connection === 'online',
        { submission_id: submission.payload.submission_id },
      );
      refs.push(retryAction);
    }
    const withdrawable = ['sent', 'unknown', 'accepted', 'selected'].includes(submission.receipt)
      && !submission.withdrawal && !submission.edit;
    if (withdrawable && state.capabilities.withdraw) {
      withdrawAction = addAction(
        actions,
        `submission.withdraw.${submission.payload.submission_id}`,
        'submission.withdraw',
        `withdraw:${submission.payload.submission_id}:${semanticHash(submission.payload.content)}`,
        state.connection === 'online',
        { submission_id: submission.payload.submission_id },
      );
      refs.push(withdrawAction);
    }
    // Pending edits retry the same cancel, never the original submit. Ready
    // edits remain recoverable when another draft occupies the composer.
    let editAction: string | undefined;
    const recoverableEdit = submission.edit && !hasReplacement && ['pending', 'ready'].includes(submission.edit.state)
      && (!submission.withdrawal || submission.withdrawal.cancel_id === submission.edit.cancel_id
        && submission.withdrawal.result === 'withdrawn_before_presentation');
    if (recoverableEdit || !submission.edit && ['sent', 'accepted'].includes(submission.receipt)
      && !submission.withdrawal && state.capabilities.withdraw) {
      editAction = addAction(
        actions,
        `submission.edit.${submission.payload.submission_id}`,
        'submission.edit',
        `edit:${submission.payload.submission_id}:${submission.edit?.state ?? 'new'}:${semanticHash(submission.payload.content)}`,
        submission.edit?.state === 'ready' || state.connection === 'online' && state.capabilities.withdraw,
        { submission_id: submission.payload.submission_id },
      );
      refs.push(editAction);
    }
    return node(
      `submission.${submission.payload.submission_id}`,
      'user_submission',
      { submission, retry_action: retryAction, withdraw_action: withdrawAction, edit_action: editAction },
      [],
      { action_refs: refs, a11y: { label: '你的追加输入' }, fallback: 'raw_text' },
    );
  });
  const sequenceOf = (entry: UiNode): number | undefined => entry.kind === 'subject_part'
    ? (entry.props.part as TimelinePart).commit_seq
    : (entry.props.submission as Submission).accepted_seq;
  const chronological = [...subjectRows, ...submissionRows].sort((left, right) => {
    const leftSeq = sequenceOf(left);
    const rightSeq = sequenceOf(right);
    if (leftSeq !== undefined && rightSeq !== undefined) {
      if (leftSeq !== rightSeq) return leftSeq - rightSeq;
      // An import can admit the selected input and its step in one local
      // transaction. The input still precedes that step.
      if (left.kind !== right.kind) return left.kind === 'user_submission' ? -1 : 1;
      if (left.kind === 'user_submission') return compareSubmissionOrder(leftSeq,
        (left.props.submission as Submission).payload.submission_id, rightSeq,
        (right.props.submission as Submission).payload.submission_id);
      return 0;
    }
    // An unadmitted browser attempt has no ledger position. Keep it after
    // durable history until a real admission tells us where it belongs.
    if (leftSeq !== undefined) return -1;
    if (rightSeq !== undefined) return 1;
    const timeOf = (entry: UiNode): string => entry.kind === 'subject_part'
      ? entry.props.part.observed_at
      : entry.kind === 'user_submission'
        ? entry.props.submission.created_at
        : '';
    const leftTime = timeOf(left);
    const rightTime = timeOf(right);
    return Date.parse(leftTime) - Date.parse(rightTime);
  });
  // If a source has no order cursor, its actual selected step still gives a
  // causal placement. Known ledger positions retain their admission order.
  const replies = new Map(subjectRows.map((entry) => [(entry.props.part as TimelinePart).step_id,
    entry.props.part as TimelinePart]));
  const selected = new Map<string, UiNode[]>();
  const paired = new Set<string>();
  for (const entry of submissionRows) {
    const submission = entry.props.submission as Submission;
    if (!submission.selected_step_id || !replies.has(submission.selected_step_id)) continue;
    if (submission.accepted_seq !== undefined
      && replies.get(submission.selected_step_id)!.commit_seq !== undefined) continue;
    const rows = selected.get(submission.selected_step_id) ?? [];
    rows.push(entry);
    selected.set(submission.selected_step_id, rows);
    paired.add(entry.node_id);
  }
  for (const rows of selected.values()) rows.sort((a, b) => {
    const left = a.props.submission as Submission;
    const right = b.props.submission as Submission;
    return left.accepted_seq !== undefined && right.accepted_seq !== undefined
      ? left.accepted_seq - right.accepted_seq
      : Date.parse(left.created_at) - Date.parse(right.created_at);
  });
  const ordered: UiNode[] = [];
  for (const entry of chronological) {
    if (paired.has(entry.node_id)) continue;
    if (entry.kind === 'subject_part') {
      const step = (entry.props.part as TimelinePart).step_id;
      const before = selected.get(step);
      if (before) { ordered.push(...before); selected.delete(step); }
    }
    ordered.push(entry);
  }
  return ordered;
}

export function buildProjection(state: UiState, revision: number): UiProjection {
  const actions: Record<string, UiAction> = {};
  const navNodes: UiNode[] = (['timeline', 'tasks', 'memory', 'config', 'playground'] as ViewName[]).map((view) => {
    const action = addAction(actions, `view.${view}`, 'view.select', 'view-v1', true, { view });
    return node(`nav.${view}`, 'navigation_item', { view, current: state.display.view === view }, [], {
      action_refs: [action],
      a11y: { current: state.display.view === view ? 'page' : false },
    });
  });
  // Degraded semantic documents ride the timeline as their own nodes; the
  // numbered options keep actions completable at every rung.
  // A surface belongs to the committed step that carried it, so it renders
  // next to that step instead of drifting to the end of history.
  const documentRows = state.documents.map((document) => {
    const refs = document.options.map((option) => addAction(
      actions,
      `document.${document.document_id}.${option.action_id}`,
      'document.action',
      document.revision,
      state.capabilities.actions,
      { document_id: document.document_id, action_id: option.action_id },
    ));
    const receipts = state.action_receipts.filter(
      (row) => row.document_id === document.document_id,
    );
    return {
      placed: false,
      source_step_id: document.source_step_id,
      node: node(
        `document.${document.document_id}`,
        'semantic_document',
        { document, mode: document.mode, receipts },
        [],
        { action_refs: refs, fallback: document.summary },
      ),
    };
  });
  const timelineChildren: UiNode[] = [];
  // A rejected document keeps its raw text visible and its reason readable
  // (docs/research/product-positioning.md#spec-3): the failure rides the same step as the surface it could not become.
  const errorRows = state.document_errors.map((error) => ({
    placed: false,
    source_step_id: error.source_step_id,
    node: node(
      `document_error.${error.source_step_id}.${semanticHash(error.reason)}`,
      'document_error',
      { error },
      [],
      { fallback: 'raw_text', a11y: { role: 'note' } },
    ),
  }));
  const surfaceRows = [...documentRows, ...errorRows];
  const attachDocuments = (stepId: string | undefined) => {
    if (!stepId) return;
    for (const row of surfaceRows) {
      if (!row.placed && row.source_step_id === stepId) {
        row.placed = true;
        timelineChildren.push(row.node);
      }
    }
  };
  for (const entry of entryNodes(state, actions)) {
    timelineChildren.push(entry);
    if (entry.kind !== 'subject_part') continue;
    const part = entry.props.part as TimelinePart;
    // Only a committed step can own a committed document. A streamed part
    // that has not been bound to S1 shares the arm-time step identity, and
    // attaching the surface there would render a committed fact next to
    // uncommitted text.
    if (part.committed) attachDocuments(part.step_id);
  }
  // Surfaces whose source step is no longer rendered keep their own place at
  // the end rather than being dropped: the information stays readable.
  for (const row of surfaceRows) {
    if (!row.placed) timelineChildren.push(row.node);
  }
  // The subject's works ride the timeline: a reader meets the
  // work where the subject made it and can open it there. Only the most
  // recent works are carried — the timeline is the subject's story, not a
  // work management screen.
  const works = (state.playground?.artifacts ?? []) as WorkView[];
  for (const work of works.slice(-6)) {
    const openRef = addAction(
      actions,
      `work.open.${work.artifact_id}`,
      'work.open',
      `work:${work.artifact_id}`,
      state.source === 'live' && state.connection === 'online',
      { artifact_id: work.artifact_id },
    );
    timelineChildren.push(node(
      `work.${work.artifact_id}`,
      'work',
      { work },
      [],
      { action_refs: [openRef], fallback: 'read_only_list' },
    ));
  }
  const historyAction = addAction(
    actions, 'submissions.load_older', 'submissions.load_older',
    `submissions:${state.subject_id}:${JSON.stringify(state.submission_history?.next_before ?? null)}`,
    state.source === 'live' && !state.submission_history?.loading
      && (state.submission_history?.has_older === true || Boolean(state.submission_history?.error)),
  );
  const timeline = node(
    'timeline',
    'timeline',
    {
      entries: timelineChildren,
      reading: state.display.reading,
      new_count: state.display.new_count,
      scroll_request: state.display.scroll_request,
      anchor: state.display.anchor,
      selection: state.display.selection,
      wrap: state.display.wrap,
      // The stream is the one fixed surface; other views open beside it.
      hidden: false,
      empty: timelineChildren.length === 0,
      connection: state.connection,
      step: state.step,
      subject_status: state.self?.status ?? 'unknown',
      submission_history: state.submission_history,
    },
    timelineChildren,
    {
      action_refs: [
        historyAction,
        addAction(actions, 'timeline.reading', 'timeline.reading', 'display-v1'),
        addAction(actions, 'timeline.latest', 'timeline.latest', 'display-v1'),
        addAction(actions, 'timeline.code_wrap', 'timeline.code_wrap', 'display-v1'),
        addAction(actions, 'timeline.selection', 'timeline.selection', 'display-v1'),
      ],
      a11y: { label: m('timeline.label') },
      layout: { hidden: false },
      fallback: 'committed_text',
    },
  );
  const draft = state.draft;
  const canAppend =
    state.source === 'live' &&
    state.connection === 'online' &&
    state.append_available &&
    state.durable_receipts &&
    Boolean(state.subject_id) &&
    // Every file must be sealed before the message can name it; a failed
    // upload stays until the owner removes or retries it.
    state.attachments.every((item) => item.status === 'ready') &&
    (draft.trim().length > 0 || state.attachments.length > 0);
  const attachmentKey = state.attachments.map((item) => item.ref?.digest ?? item.local_id).join(',');
  const appendAction = addAction(
    actions,
    'composer.append',
    'composer.append',
    `append:${state.subject_id ?? 'unbound'}:${semanticHash(draft.trim())}:${semanticHash(attachmentKey)}`,
    canAppend,
  );
  const canAttach = state.source === 'live' && state.connection === 'online' && state.capabilities.attachments;
  const attachAction = addAction(actions, 'composer.attach', 'composer.attach', 'display-v1', canAttach);
  const detachAction = addAction(actions, 'composer.detach', 'composer.detach', 'display-v1', true);
  const canSteer = canAppend && state.capabilities.steer;
  const steerAction = addAction(
    actions,
    'composer.steer',
    'composer.steer',
    `steer:${state.subject_id ?? 'unbound'}:${semanticHash(draft.trim())}`,
    canSteer,
  );
  const draftAction = addAction(actions, 'composer.draft', 'composer.draft', 'display-v1', state.source === 'live');
  const composer = node(
    'composer',
    'composer',
    {
      draft,
      connection: state.connection,
      hidden: false,
      demo: state.source === 'demo',
      subject_bound: Boolean(state.subject_id),
      append_action: appendAction,
      append_enabled: canAppend,
      steer_action: steerAction,
      steer_enabled: canSteer,
      steer_available: state.source === 'live' && state.capabilities.steer,
      attachments: state.attachments,
      attach_action: attachAction,
      attach_enabled: canAttach,
      detach_action: detachAction,
      append_offered: state.append_available && state.durable_receipts,
      streaming: state.streaming,
    },
    [],
    {
      action_refs: [draftAction, appendAction, steerAction, attachAction, detachAction],
      a11y: { label: m('composer.appendLabel') },
      layout: { hidden: false },
    },
  );
  const panelAction = addAction(actions, 'panel.toggle', 'panel.toggle', 'display-v1');
  const themeAction = addAction(actions, 'theme.toggle', 'theme.toggle', 'display-v1');
  const sectionNodes = ['status', 'activity', 'artifacts', 'devices'].map((section) => {
    const action = addAction(actions, `section.${section}`, 'section.toggle', 'display-v1', true, { section });
    return node(`section.${section}`, 'collapsible_section', {
      section,
      open: state.display.open_sections[section] === true,
    }, [], { action_refs: [action] });
  });
  // The opened work's actions. Each one is bound to the
  // revision the reader saw, and the request id behind them is stable for
  // that (work, action, revision) — so a repeated submit is the same request.
  const workActionRefs: string[] = [];
  if (state.work) {
    for (const op of ['stage', 'publish', 'rollback']) {
      workActionRefs.push(addAction(
        actions,
        `work.${op}.${state.work.artifact_id}`,
        `work.${op}`,
        `work:${state.work.artifact_id}:r${state.work.revision ?? 0}`,
        state.connection === 'online',
        { artifact_id: state.work.artifact_id },
      ));
    }
  }
  // The naming and the claim are the reader's own acts.
  const nameDraftRef = addAction(actions, 'identity.name.draft', 'identity.name.draft', 'identity-v1', true);
  const nameRef = addAction(actions, 'identity.name', 'identity.name', 'identity-v1', state.connection === 'online');
  const claimDraftRef = addAction(actions, 'owner.claim.draft', 'owner.claim.draft', 'owner-v1', true);
  const claimRef = addAction(actions, 'owner.claim', 'owner.claim', 'owner-v1', state.connection === 'online');
  const panel = node('context', 'context_panel', {
    open: state.display.panel_open,
    identity: state.identity,
    self: state.self,
    config: state.config,
    connection: state.connection,
    step: state.step,
    sections: sectionNodes,
    timeline: state.timeline,
    work: state.work,
    work_error: state.work_error === true,
    work_action_refs: workActionRefs,
    owner_state: state.owner_state,
    name_draft: state.name_draft,
    claim_draft: state.claim_draft,
    identity_name_ref: nameRef,
    identity_name_draft_ref: nameDraftRef,
    owner_claim_ref: claimRef,
    owner_claim_draft_ref: claimDraftRef,
  }, sectionNodes, {
    action_refs: [panelAction],
    a11y: { label: m('subject.details'), modal: state.display.panel_open },
    layout: { open: state.display.panel_open },
  });

  const configEntryRows = (state.config_entries ?? []).map((entry) => {
    const key = `${entry.namespace}/${entry.logical_key}`;
    const desired_revision = entry.entry?.desired_revision ?? 0;
    const draft = state.config_drafts?.[key]
      ?? (entry.desired_value === undefined ? '' : JSON.stringify(entry.desired_value));
    const apply_action = addAction(
      actions,
      `config.apply.${key}`,
      'config.apply',
      `config:${key}:${desired_revision}`,
      state.source === 'live' && state.connection === 'online' && !entry.error,
      { namespace: entry.namespace, logical_key: entry.logical_key },
    );
    return { ...entry, key, desired_revision, draft, apply_action };
  });
  const configDraftAction = addAction(actions, 'config.draft', 'config.draft', 'config-draft-v1', state.source === 'live');
  const projection: UiProjection = {
    schema_version: UI_PROJECTION_SCHEMA,
    locale: preferredLocale(),
    surface_id: state.source === 'demo' ? 'shenko.main.demo' : 'shenko.main.live',
    revision,
    source: state.source,
    subject_id: state.subject_id,
    identity: state.identity,
    connection: state.connection,
    nodes: [
      node('navigation', 'navigation', { items: navNodes, theme: state.display.theme }, navNodes, {
        action_refs: [panelAction, themeAction],
        a11y: { label: '主要导航' },
      }),
      timeline,
      node('tasks', 'tasks_surface', {
        hidden: state.display.view !== 'tasks',
        data: state.tasks,
        error: state.tasks_error,
      }, [], { layout: { hidden: state.display.view !== 'tasks' }, fallback: 'read_only_list' }),
      node('memory', 'memory_surface', {
        hidden: state.display.view !== 'memory',
        data: state.memory,
        error: state.memory_error,
      }, [], { layout: { hidden: state.display.view !== 'memory' }, fallback: 'read_only_list' }),
      node('config', 'config_surface', {
        hidden: state.display.view !== 'config',
        config: state.config,
        config_error: state.config_error,
        entries: configEntryRows,
        entries_error: state.config_entries_error ?? false,
        live: state.source === 'live',
        self: state.self,
        self_error: state.self_error,
        connection: state.connection,
        reconnect_seconds: state.reconnect_seconds,
        server_version: state.server_version,
        manifest: state.manifest,
        step: state.step,
        capabilities: {
          append: state.append_available,
          steer: state.capabilities.steer,
          withdraw: state.capabilities.withdraw,
          actions: state.capabilities.actions,
          documents: state.capabilities.documents,
          streaming: state.streaming,
          attachments: false,
          durable_input_receipts: state.durable_receipts,
          committed_replay: state.committed_replay,
        },
      }, [], {
        action_refs: [configDraftAction, ...configEntryRows.map((row) => row.apply_action)],
        layout: { hidden: state.display.view !== 'config' },
        fallback: 'read_only_values',
      }),
      node('playground', 'playground_surface', {
        hidden: state.display.view !== 'playground',
        playground: state.playground,
        error: state.playground_error,
      }, [], { layout: { hidden: state.display.view !== 'playground' }, fallback: 'read_only_list' }),
      composer,
      panel,
      node('notice', 'status_notice', { text: state.display.notice, source: state.source }, [], {
        a11y: { live: 'polite' },
      }),
    ],
    capabilities: {
      append: state.append_available,
      steer: state.capabilities.steer,
      withdraw: state.capabilities.withdraw,
      actions: state.capabilities.actions,
      documents: state.capabilities.documents,
      streaming: state.streaming,
      attachments: false,
      durable_input_receipts: state.durable_receipts,
      committed_replay: state.committed_replay,
    },
    actions,
    assets: {
      proto_ui: {
        kind: 'compiled_runtime_and_generated_styles',
        ref: '/assets/build-manifest.json',
        revision: state.manifest?.upstream.commit ?? 'unread',
      },
    },
  };
  return projection;
}

export function intentFor(
  projection: UiProjection,
  node_id: string,
  action_id: string,
  payload: Record<string, unknown> = {},
): UiIntent {
  const action = projection.actions[action_id];
  if (!action) throw new Error(`Unknown UI action: ${action_id}`);
  return {
    schema_version: UI_INTENT_SCHEMA,
    surface_id: projection.surface_id,
    node_id,
    action_id,
    action_revision: action.revision,
    payload,
  };
}
