from pathlib import Path
import os,json,subprocess,hashlib,datetime
r=Path("/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202");p=r/"Proto-UI-shenko-producer";o=r/"evidence/shenko-public-packages-f247-02";head="f24720f870cd76f86c81ee8343359486afd3f0de"
def run(a):return subprocess.check_output(a,cwd=p,text=True).strip()
assert json.loads((r/"evidence/shenko-producer-prepare-f247/result.json").read_text())["exitCode"]==0
assert run(["git","rev-parse","HEAD"])==head and run(["git","status","--porcelain"])==""
plan=subprocess.check_output([os.environ["S2_NODE"],"scripts/build/public-packages.mjs","--package","@proto.ui/adapter-react","--package","@proto.ui/prototypes-shadcn","--package","@proto.ui/cli","--plan","--json"],cwd=p,text=True);(o/"plan.json").write_text(plan);assert json.loads(plan)["selectedCount"]==42
cmd=[os.environ["S2_NODE"],"scripts/build/public-packages.mjs","--package","@proto.ui/adapter-react","--package","@proto.ui/prototypes-shadcn","--package","@proto.ui/cli","--json"]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (o/"public-packages.json").open("w") as stdout,(o/"build.stderr.log").open("w") as stderr:
 x=subprocess.run(cmd,cwd=p,stdout=stdout,stderr=stderr)
(o/"build-result.json").write_text(json.dumps({"exit":x.returncode,"started":started,"ended":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":cmd,"head":head},indent=2)+"\n")
assert x.returncode==0
v=json.loads((o/"public-packages.json").read_text());assert v["selectedCount"]==42 and len(v["results"])==42
assert run(["git","rev-parse","HEAD"])==head and run(["git","status","--porcelain"])==""
summary={"head":head,"selected":v["selectedCount"],"completed":len(v["results"]),"bytes":sum(x["bytes"] for x in v["results"]),"files":sum(x["files"] for x in v["results"]),"receiptSha256":hashlib.sha256((o/"public-packages.json").read_bytes()).hexdigest(),"lockSha256":hashlib.sha256((p/"pnpm-lock.yaml").read_bytes()).hexdigest(),"dirty":""}
(o/"summary.json").write_text(json.dumps(summary,indent=2)+"\n");print(json.dumps(summary))
