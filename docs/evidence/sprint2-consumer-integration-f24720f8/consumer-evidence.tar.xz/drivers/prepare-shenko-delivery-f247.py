from pathlib import Path
import os,json,hashlib,subprocess,tarfile,io,datetime,shutil
r=Path("/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202");repo=r/"Shenko-final";out=r/"evidence/shenko-delivery-f247-01"
dest=repo/"docs/evidence/sprint2-consumer-integration-f24720f8";dest.mkdir(parents=True,exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(["git",*args],cwd=repo,text=True).strip()
assert git("rev-parse","HEAD")=="c240169239bfb55a8ee47d3129c3fd820e1de747"
assert git("rev-parse","MERGE_HEAD")=="ab0d3dfb3474a9bd9e0f459b46c48d53857cdb4b"
raw={}
for rel in ["results/shenko-normal-consumer-f247-01","results/shenko-inspector-c240-ab0-f247-01","results/shenko-tree-c240-ab0-f247-01","evidence/shenko-producer-prepare-f247","evidence/shenko-public-packages-f247","evidence/shenko-public-packages-f247-02","evidence/shenko-normal-consumer-f247-01","evidence/shenko-native-final-f247-01"]:
 d=r/rel;assert d.is_dir(),rel
 for p in sorted(d.rglob("*")):
  if p.is_file():raw["raw/"+rel+"/"+str(p.relative_to(d))]=p.read_bytes()
for name in ["build-shenko-consumer-f247.py","build-shenko-public-packages-f247-02.py","shenko-native-final-f247-01.spec.json","remote_jobs.py"]:
 p=r/name;assert p.is_file(),name;raw["drivers/"+name]=p.read_bytes()
receipt=json.loads((r/"results/shenko-normal-consumer-f247-01/receipt.json").read_text())
assert receipt["passed"] and receipt["sourceStable"] and receipt["extraInputsStable"]
for key in ["sourceAfter","extraInputsAfter"]:
 for path,digest in receipt[key].items():
  b=(repo/path).read_bytes();assert sha(b)==digest,path;raw["source/"+path]=b
manifest=repo/"crates/shenko-ui/src/static/build-manifest.json"
assert sha(manifest.read_bytes())==receipt["appBuildManifest"]["sha256"]
raw["source/"+str(manifest.relative_to(repo))]=manifest.read_bytes()
for path,entry in receipt["artifacts"].items():
 p=repo/"crates/shenko-ui/src/static"/path;b=p.read_bytes()
 assert len(b)==entry["bytes"] and sha(b)==entry["sha256"],path
 raw["source/"+str(p.relative_to(repo))]=b
for p in sorted((repo/"crates/shenko-ui/web/generated").rglob("*")):
 if p.is_file():raw["source/"+str(p.relative_to(repo))]=p.read_bytes()
for rel in ["scripts/check_docs.py","scripts/requirements-ci.txt","crates/shenko-ui/web/upstream-pin.json"]:
 p=repo/rel;raw["source/"+rel]=p.read_bytes()
raw["source/pre-publication-status.txt"]=git("status","--short").encode()
raw["source/merge-parents.json"]=json.dumps({"head":git("rev-parse","HEAD"),"mergeHead":git("rev-parse","MERGE_HEAD"),"publishedSource":"2816a6adc8edf7e797d5d794d68625d0be204138","upstream":"f24720f870cd76f86c81ee8343359486afd3f0de"},indent=2).encode()
members=[{"path":k,"bytes":len(v),"sha256":sha(v)} for k,v in sorted(raw.items())]
m={"format":"sha256-file-manifest-v1","files":members}
mb=(json.dumps(m,indent=2)+"\n").encode();raw["manifest.json"]=mb
archive=dest/"consumer-evidence.tar.xz"
with tarfile.open(archive,"w:xz",preset=6) as tf:
 for name,b in sorted(raw.items()):
  ti=tarfile.TarInfo(name);ti.size=len(b);ti.mtime=0;ti.mode=0o644;tf.addfile(ti,io.BytesIO(b))
with tarfile.open(archive,"r:xz") as tf:
 assert len(tf.getmembers())==len(raw)
 for member in tf.getmembers():
  assert member.isfile() and tf.extractfile(member).read()==raw[member.name],member.name
(dest/"manifest.json").write_bytes(mb)
inspector=json.loads((r/"results/shenko-inspector-c240-ab0-f247-01/receipt.json").read_text())
tree=json.loads((r/"results/shenko-tree-c240-ab0-f247-01/report.json").read_text())
assert inspector["passed"] and inspector["sourceStable"] and len(inspector["cases"])==4
assert tree["passed"] and tree["sourceStable"] and tree["assetStable"] and sum(len(c["checks"]) for c in tree["cases"])==67
assert all(c["passed"] for c in inspector["cases"]+tree["cases"])
validation={"kind":"source-bound-consumer-integration","appBase":receipt["appBase"],"appMergedMain":receipt["appMergedMain"],"upstream":receipt["upstreamCandidate"],"publicPackages":42,"publicUniverse":47,"nodeTests":{"passed":59,"failed":0,"skipped":0,"cancelled":0,"todo":0},"inspectorJourneys":{"passed":4,"failed":0},"treeJourneys":{"passed":4,"failed":0,"checks":67},"sourceStable":True,"assetStable":True,"receipts":{"normalBuild":{"path":"raw/results/shenko-normal-consumer-f247-01/receipt.json","sha256":sha((r/"results/shenko-normal-consumer-f247-01/receipt.json").read_bytes())},"inspector":{"path":"raw/results/shenko-inspector-c240-ab0-f247-01/receipt.json","sha256":sha((r/"results/shenko-inspector-c240-ab0-f247-01/receipt.json").read_bytes())},"tree":{"path":"raw/results/shenko-tree-c240-ab0-f247-01/report.json","sha256":sha((r/"results/shenko-tree-c240-ab0-f247-01/report.json").read_bytes())}},"archive":{"name":archive.name,"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),"payloads":len(members)},"notClaimed":["full Resizable adjustment contract","full Tree controlled/dynamic/AT contract","physical touch or pen","real assistive technology","live backend/model","whole Rust application rebuild","independent GitHub approval","PR merge","release"]}
(dest/"validation.json").write_text(json.dumps(validation,indent=2)+"\n")
readme="""# Sprint 2: main integration and actual f247 Inspector/Tree consumer

This continues draft Shenko #402. The working candidate was the real merge of
c240169239bfb55a8ee47d3129c3fd820e1de747 and current main
ab0d3dfb3474a9bd9e0f459b46c48d53857cdb4b. The only conflicting generated build
manifest was resolved by the ordinary producer using the exact Proto-UI pin
f24720f870cd76f86c81ee8343359486afd3f0de. The rebuilt JavaScript, CSS and manifest
are committed as produced. The source and ownership of the existing Resizable
Inspector and Tasks/Playground Tree domains are preserved.

## Actual consumer results

| Lane | Result |
| --- | --- |
| Three declared public dependency seeds | 42/42 packages built; exact plan/result order |
| Shenko authored Prototype generation | Both transport-badge and message-bubble built |
| App strict TypeScript | Exit 0 |
| Existing Node tests | 59/59; no skip, cancellation or todo |
| Ordinary App production build | Exit 0; all 12 manifest assets verified |
| Resizable Inspector | Four original browser journeys passed |
| Tasks and Playground Trees | Four original journeys; 67/67 checks passed |
| Source and generated asset guards | Stable before and after actual execution |

The three producer seeds are @proto.ui/adapter-react, @proto.ui/prototypes-shadcn
and @proto.ui/cli. They select 42 of the 47 public packages. The first preparation
attempt incorrectly compared the unfiltered 47-package plan with this 42-package
closure and stopped before building. Its original result and log remain in the
archive. The subsequent ordinary selected-plan build is a separate successful
execution; neither its plan nor its receipt was synthesized.

The consumer pin moves from 5cb80eb937f20982dd7dc8cbc93a90e91d665c31 to f247.
Its three declared package versions remain 0.3.0-alpha.2. The lock SHA-256 remains
6e21c4b8444ca5e4a2e427287a76a346137b65d76403579942269bfea1fc7fe8.
The producer had its own frozen installation and remained clean at f247.
Resizable and both Trees still use their public Shadcn exports with the React
adapter. The Compiler is a build-time source-tree dependency for the two authored
Prototypes, not a browser runtime import or a claimed published Compiler package.

The Inspector observer exercises public pointer/keyboard input and pixel bounds,
collapse/restore focus and width preference, responsive contact cancellation, and
replacement-handle rejection of late input. The Tree observer exercises Tasks,
Playground artifacts, phone invalid-data recovery and subject retirement. Both
unchanged observers ran in Chromium 145.0.7632.6 with chromiumSandbox enabled.
The actual console, cleanup, source, HTTP/WebSocket fixture and asset observations
are retained. These fixtures exercise the real App/controller path; they do not
claim a live backend, physical hardware or a screen-reader session.

## Reproduction and source binding

The complete executed argument vectors, environment, timestamps, exit codes,
source hashes, production assets, original observers and screenshots are retained
in [consumer-evidence.tar.xz](consumer-evidence.tar.xz).
[manifest.json](manifest.json) lists every original payload and SHA-256;
[validation.json](validation.json) records the measured lanes and exact receipt
locations. Every archive member was decoded and compared byte for byte after
creation.

Run the ordinary Proto-UI public package producer at the pinned commit with
--package @proto.ui/adapter-react --package @proto.ui/prototypes-shadcn
--package @proto.ui/cli. Point PROTO_UI_SOURCE and PROTO_UI_BUILD_RECEIPT at that
clean checkout and its actual producer JSON. In crates/shenko-ui/web, execute the
existing Prototype build, TypeScript check, Node tests and normal App build.
The unchanged inspector-browser.mjs and tree-browser.mjs accept the retained
normal-build receipt through PUI_INSPECTOR_BUILD_RECEIPT and
PUI_TREE_BUILD_RECEIPT. Their complete launcher environment is in the archive.

Earlier evidence keeps its original source pin and outcome. This new success does
not rewrite the previous preparation failure or older browser receipts. The
complete Resizable adjustment table, portable Tree controlled-state and AT
contract, independent CI asset rebuild, Rust application, live service, original
Harness scope, independent review and actual PR integration remain separately
owned acceptance conditions. Draft status is preserved.

The documentation check is recorded separately as documentation integrity only;
it does not mark product requirements accepted.
"""
(dest/"README.md").write_text(readme)
venv=r/"tools/shenko-docs-f247-venv";python=venv/"bin/python"
steps=[]
def run(name,argv):
 with (dest/(name+".stdout.log")).open("wb") as stdout,(dest/(name+".stderr.log")).open("wb") as stderr:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=repo,stdout=stdout,stderr=stderr)
 step={"name":name,"argv":argv,"exitCode":p.returncode,"started":start,"ended":datetime.datetime.now(datetime.timezone.utc).isoformat()};steps.append(step);(out/"steps.json").write_text(json.dumps(steps,indent=2)+"\n");assert p.returncode==0,step
run("docs-venv",["python3","-m","venv",str(venv)])
run("docs-dependencies",[str(python),"-m","pip","install","-r","scripts/requirements-ci.txt"])
run("docs-check",[str(python),"scripts/check_docs.py"])
docs=json.loads((dest/"docs-check.stdout.log").read_text());assert docs["errors"]==[] and docs["product_tested"] is False
(dest/"docs-check-receipt.json").write_text(json.dumps({"kind":"documentation_integrity_only","product_tested":False,"steps":steps,"reportSha256":sha((dest/"docs-check.stdout.log").read_bytes())},indent=2)+"\n")
delivery={"files":[{"path":str(p.relative_to(repo)),"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())} for p in sorted(dest.rglob("*")) if p.is_file()]}
(dest/"delivery-manifest.json").write_text(json.dumps(delivery,indent=2)+"\n")
print(json.dumps({"archive":validation["archive"],"docsErrors":len(docs["errors"]),"sourceStillBound":True,"files":len(delivery["files"])}))
