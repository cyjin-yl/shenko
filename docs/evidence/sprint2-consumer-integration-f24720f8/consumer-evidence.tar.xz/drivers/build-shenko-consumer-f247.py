from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import traceback

APPLICATION = Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/Shenko-final')
UPSTREAM = Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/Proto-UI-shenko-producer')
WEB = APPLICATION / 'crates/shenko-ui/web'
STATIC = APPLICATION / 'crates/shenko-ui/src/static'
EXPECTED = 'f24720f870cd76f86c81ee8343359486afd3f0de'
PUBLIC = Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/evidence/shenko-public-packages-f247-02')
OUTPUT = Path(sys.argv[1])
OUTPUT.mkdir(exist_ok=False)
ENV = dict(os.environ, NODE_OPTIONS='--max-old-space-size=1024',
           PROTO_UI_SOURCE=str(UPSTREAM), PROTO_UI_BUILD_RECEIPT=str(PUBLIC / 'public-packages.json'))

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    files = [path for directory in ['src', 'tests'] for path in (WEB / directory).rglob('*') if path.is_file()]
    files += [WEB / name for name in ['build.mjs', 'compiler.mjs', 'upstream-pin.json',
                                      'package.json', 'pnpm-lock.yaml', 'tsconfig.json']]
    return {str(path.relative_to(APPLICATION)): sha(path) for path in sorted(files)}

def extra_inputs():
    files = [path for directory in ['prototypes', 'scripts'] for path in (WEB / directory).rglob('*') if path.is_file()]
    files += [APPLICATION / 'crates/shenko-ui/src/index.html',
              APPLICATION / 'scripts/web_reading_journey.mjs']
    return {str(path.relative_to(APPLICATION)): sha(path) for path in sorted(files)}

report = {'kind': 'shenko-sprint2-normal-consumer-build-v1', 'startedAt': now(),
          'upstreamCandidate': EXPECTED, 'upstreamSource': str(UPSTREAM),
          'steps': [], 'passed': False, 'driverSha256': sha(Path(__file__)),
          'nodeOptions': ENV['NODE_OPTIONS'],
          'scope': 'Ordinary public-package and private build-time compiler source consumer; normal prototypes, strict TypeScript, existing Node suite and production App assets. Browser journeys and live backend/model are separate.'}

def save():
    (OUTPUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')

def step(name, argv, cwd=WEB, timeout=600):
    stdout = OUTPUT / (name + '.stdout.log')
    stderr = OUTPUT / (name + '.stderr.log')
    entry = {'name': name, 'argv': argv, 'cwd': str(cwd), 'startedAt': now(),
             'wrapperTimeoutSeconds': timeout, 'stdout': str(stdout), 'stderr': str(stderr)}
    report['steps'].append(entry)
    save()
    started = time.monotonic()
    with stdout.open('x') as out, stderr.open('x') as err:
        child = subprocess.Popen(argv, cwd=cwd, env=ENV, stdin=subprocess.DEVNULL,
                                 stdout=out, stderr=err, start_new_session=True)
        entry['pid'] = child.pid
        save()
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            entry['timedOut'] = True
            code = child.returncode
    entry.update(exitCode=code, finishedAt=now(), durationSeconds=time.monotonic() - started,
                 stdoutSha256=sha(stdout), stderrSha256=sha(stderr))
    save()
    print(json.dumps({'step': name, 'exit': code}), flush=True)
    if code or entry.get('timedOut'):
        raise RuntimeError('Step failed: ' + name)
    return stdout.read_text()

try:
    producer = json.loads((PUBLIC / 'result.json').read_text())
    assert producer['exitCode'] == 0 and producer['head'] == EXPECTED and producer['finalHead'] == EXPECTED
    public = json.loads((PUBLIC / 'public-packages.json').read_text())
    public_plan = json.loads((PUBLIC / 'plan.json').read_text())
    public_summary = json.loads((PUBLIC / 'summary.json').read_text())
    assert public['selectedCount'] == 42 and len(public['results']) == 42
    assert [item['name'] for item in public['results']] == public_plan['packages']
    assert sha(PUBLIC / 'public-packages.json') == public_summary['receiptSha256']
    report['publicReceiptSha256'] = public_summary['receiptSha256']
    report['publicProducer'] = {'path': str(PUBLIC / 'result.json'), 'sha256': sha(PUBLIC / 'result.json'),
                               'selectedCount': public['selectedCount'], 'packageCount': public_plan['packageCount'],
                               'seeds': ['@proto.ui/adapter-react', '@proto.ui/prototypes-shadcn', '@proto.ui/cli']}
    assert step('app-merge-base', ['git', 'rev-parse', 'HEAD'], APPLICATION).strip() == 'c240169239bfb55a8ee47d3129c3fd820e1de747'
    assert step('app-merge-head', ['git', 'rev-parse', 'MERGE_HEAD'], APPLICATION).strip() == 'ab0d3dfb3474a9bd9e0f459b46c48d53857cdb4b'
    report['appMergedMain'] = 'ab0d3dfb3474a9bd9e0f459b46c48d53857cdb4b'
    pin_path = WEB / 'upstream-pin.json'
    original_pin = pin_path.read_bytes()
    old_pin = json.loads(original_pin)
    assert old_pin['commit'] == '5cb80eb937f20982dd7dc8cbc93a90e91d665c31'
    (OUTPUT / 'upstream-pin.original.json').write_bytes(original_pin)
    old_pin['migrated_from'] = old_pin['commit']
    old_pin['commit'] = EXPECTED
    pin_path.write_text(json.dumps(old_pin, indent=2) + '\n')
    (OUTPUT / 'upstream-pin.candidate.json').write_bytes(pin_path.read_bytes())
    assert step('upstream-head', ['git', 'rev-parse', 'HEAD'], UPSTREAM).strip() == EXPECTED
    assert step('upstream-clean-before', ['git', 'status', '--porcelain', '--untracked-files=no'], UPSTREAM).strip() == ''
    report['appBase'] = step('app-head', ['git', 'rev-parse', 'HEAD'], APPLICATION).strip()
    step('app-diff-before', ['git', 'diff', '--binary'], APPLICATION)
    pin = json.loads((WEB / 'upstream-pin.json').read_text())
    assert pin['commit'] == EXPECTED and pin['lock_sha256'] == sha(UPSTREAM / 'pnpm-lock.yaml')
    report['sourceBefore'] = snapshot()
    report['extraInputsBefore'] = extra_inputs()
    report['node'] = step('node-version', ['node', '--version']).strip()
    report['webPackageManager'] = json.loads((WEB / 'package.json').read_text())['packageManager']
    step('inspector-observer-syntax', ['node', '--check', 'scripts/inspector-browser.mjs'])
    step('tree-observer-syntax', ['node', '--check', 'scripts/tree-browser.mjs'])
    step('app-prototypes', ['node', 'build.mjs', '--prototypes-only'])
    step('app-strict-types', ['node', 'node_modules/typescript/bin/tsc', '--noEmit'])
    tests = sorted(str(path.relative_to(WEB)) for path in (WEB / 'tests').glob('*.test.mjs'))
    step('app-node-tests', ['node', '--test', '--test-concurrency=1', *tests])
    step('app-build', ['node', 'build.mjs'])
    report['sourceAfter'] = snapshot()
    report['extraInputsAfter'] = extra_inputs()
    report['sourceStable'] = report['sourceAfter'] == report['sourceBefore']
    report['extraInputsStable'] = report['extraInputsAfter'] == report['extraInputsBefore']
    assert report['sourceStable'] and report['extraInputsStable']
    assert step('upstream-clean-after', ['git', 'status', '--porcelain', '--untracked-files=no'], UPSTREAM).strip() == ''
    assert step('upstream-head-after', ['git', 'rev-parse', 'HEAD'], UPSTREAM).strip() == EXPECTED
    manifest_path = STATIC / 'build-manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert manifest['upstream']['commit'] == EXPECTED
    assert manifest['upstream']['build_receipt']['receipt_sha256'] == report['publicReceiptSha256']
    assert manifest['compiler']['runtime_imported'] is False
    assert manifest['compiler']['public_package_selection']['includes_compiler'] is False
    assert manifest['realisation']['compiled'] == ['transport-badge', 'message-bubble']
    assert {'resizable', 'tree'}.issubset(item['family'] for item in manifest['realisation']['adapter'])
    actual = {str(path.relative_to(STATIC)): {'bytes': path.stat().st_size, 'sha256': sha(path)}
              for path in sorted(STATIC.rglob('*')) if path.is_file() and path != manifest_path}
    assert actual == manifest['artifacts']
    generation_path = WEB / 'generated/prototypes/manifest.json'
    generation = json.loads(generation_path.read_text())
    assert generation['source_tree_sha256'] == manifest['compiler']['source_tree_sha256']
    report['appBuildManifest'] = {'path': str(manifest_path), 'sha256': sha(manifest_path)}
    report['prototypeManifest'] = {'path': str(generation_path), 'sha256': sha(generation_path)}
    report['artifacts'] = actual
    report['passed'] = True
except BaseException:
    report['failure'] = traceback.format_exc()
    print(report['failure'], flush=True)
finally:
    report['finishedAt'] = now()
    save()
    print(json.dumps({'passed': report['passed'], 'receipt': str(OUTPUT / 'receipt.json')}), flush=True)
sys.exit(0 if report['passed'] else 1)
