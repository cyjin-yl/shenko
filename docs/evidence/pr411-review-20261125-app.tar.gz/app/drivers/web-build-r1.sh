#!/usr/bin/env bash
set -euo pipefail
task_output=/var/idw-target/pr411-review-20261125-55114
task_source=$task_output/source
task_tools=/var/idw-target/daily-readiness-node-v24.22.1
export PATH="$task_tools/bin:$PATH" COREPACK_HOME="$task_tools/corepack"
export npm_config_store_dir="$task_tools/pnpm-store" HUSKY=0 NODE_OPTIONS=--max-old-space-size=4096
export TMPDIR="$task_output/tmp" PROTO_UI_SOURCE="$task_output/proto-ui" PROTO_UI_BUILD_RECEIPT="$task_output/upstream-build.json"
export TASK_OUTPUT="$task_output" TASK_SOURCE="$task_source"
mkdir -p "$task_output/web-r1" "$TMPDIR"
exec 8>/tmp/shenko-cargo.lock
flock -x 8
test "$(node --version)" = v24.22.1
test "$(pnpm --version)" = 10.32.1
cd "$task_source"
python3 - <<'PY'
from pathlib import Path
import json,hashlib,os,subprocess
root=Path(os.environ['TASK_SOURCE']); web=root/'crates/shenko-ui/web'; out=Path(os.environ['TASK_OUTPUT'])/'web-r1'
files=sorted([p for folder in ['src','tests'] for p in (web/folder).rglob('*') if p.is_file()]+[web/n for n in ['build.mjs','compiler.mjs','upstream-pin.json','package.json','pnpm-lock.yaml','tsconfig.json']])
source={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(out/'source-before.json').write_text(json.dumps(source,indent=2)+'\n')
(out/'source-head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
PY
cd "$task_source/crates/shenko-ui/web"
printf 'START web-install %s\n' "$(date -u +%FT%TZ)"
pnpm install --frozen-lockfile > "$task_output/web-r1/install.log" 2>&1
printf 'START web-check %s\n' "$(date -u +%FT%TZ)"
pnpm run check > "$task_output/web-r1/check.log" 2>&1
printf 'START web-tests %s\n' "$(date -u +%FT%TZ)"
pnpm run test > "$task_output/web-r1/test.log" 2>&1
printf 'START web-build %s\n' "$(date -u +%FT%TZ)"
pnpm run build > "$task_output/web-r1/build.log" 2>&1
cd "$task_source"
python3 - <<'PY'
from pathlib import Path
import json,hashlib,os,subprocess,datetime,importlib.util
root=Path(os.environ['TASK_SOURCE']); web=root/'crates/shenko-ui/web'; out=Path(os.environ['TASK_OUTPUT'])/'web-r1'
before=json.loads((out/'source-before.json').read_text())
after={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in before}
assert before==after,'Source changed during build'
spec=importlib.util.spec_from_file_location('web_assets',root/'scripts/ci/web_assets.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
manifest=m.read_json(root/'crates/shenko-ui/src/static/build-manifest.json')
m.validate_static(root/'crates/shenko-ui/src/static',manifest)
verified=m.compiler_files(web,Path(os.environ['PROTO_UI_SOURCE']),manifest)
result={'passed':True,'sourceStable':True,'appBase':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstreamCandidate':manifest['upstream']['commit'],'sourceBefore':before,'sourceAfter':after,'node':subprocess.check_output(['node','--version'],text=True).strip(),'pnpm':subprocess.check_output(['pnpm','--version'],text=True).strip(),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilerFilesVerified':len(verified),'staticManifestSha256':m.sha256(root/'crates/shenko-ui/src/static/build-manifest.json')}
(out/'normal-build.json').write_text(json.dumps(result,indent=2)+'\n')
print('NORMAL BUILD PASSED',result['appBase'],result['upstreamCandidate'],len(manifest['artifacts']))
PY
printf 'DONE web-build %s\n' "$(date -u +%FT%TZ)"
