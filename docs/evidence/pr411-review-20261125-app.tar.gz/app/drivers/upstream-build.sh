#!/usr/bin/env bash
set -euo pipefail
task_output=/var/idw-target/pr411-review-20261125-55114
task_tools=/var/idw-target/daily-readiness-node-v24.22.1
export PATH="$task_tools/bin:$PATH" COREPACK_HOME="$task_tools/corepack"
export npm_config_store_dir="$task_tools/pnpm-store" HUSKY=0 NODE_OPTIONS=--max-old-space-size=4096
export TMPDIR="$task_output/tmp"
mkdir -p "$TMPDIR"
exec 8>/tmp/shenko-cargo.lock
flock -x 8
test "$(node --version)" = v24.22.1
test "$(pnpm --version)" = 10.32.1
cd "$task_output/proto-ui"
git status --porcelain > "$task_output/upstream-status-before.txt"
test ! -s "$task_output/upstream-status-before.txt"
printf 'START upstream-install %s\n' "$(date -u +%FT%TZ)"
pnpm install --frozen-lockfile > "$task_output/upstream-install.log" 2>&1
printf 'START public-plan %s\n' "$(date -u +%FT%TZ)"
node scripts/build/public-packages.mjs --package @proto.ui/adapter-react --package @proto.ui/prototypes-shadcn --package @proto.ui/cli --plan --json > "$task_output/upstream-plan.json" 2> "$task_output/upstream-plan.log"
printf 'START public-build %s\n' "$(date -u +%FT%TZ)"
node scripts/build/public-packages.mjs --package @proto.ui/adapter-react --package @proto.ui/prototypes-shadcn --package @proto.ui/cli --json > "$task_output/upstream-build.json" 2> "$task_output/upstream-build.log"
git status --porcelain > "$task_output/upstream-status-after.txt"
test ! -s "$task_output/upstream-status-after.txt"
node - <<'NODE'
const fs=require('fs');
const root='/var/idw-target/pr411-review-20261125-55114/';
const p=JSON.parse(fs.readFileSync(root+'upstream-plan.json'));
const r=JSON.parse(fs.readFileSync(root+'upstream-build.json'));
if(r.selectedCount!==p.selectedCount || JSON.stringify(r.results.map(x=>x.name))!==JSON.stringify(p.packages)) throw Error('Public closure did not match its real plan');
console.log('Public closure completed:',r.selectedCount);
NODE
printf 'DONE public-build %s\n' "$(date -u +%FT%TZ)"
