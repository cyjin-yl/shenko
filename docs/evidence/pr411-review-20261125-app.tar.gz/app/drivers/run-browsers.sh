#!/usr/bin/env bash
set -uo pipefail
browser_review=/home/ezra/shenko-pr411-browser-20261125-55114
compiler_review=/home/ezra/shenko-pr411-compiler-20261125-55114
export PATH="$compiler_review/tooling/bin:$PATH"
export PROTO_UI_SOURCE="$compiler_review/proto-ui"
export PUI_CHROME_EXECUTABLE=/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome
export PUI_PLAYWRIGHT_MODULE=/home/ezra/proto-ui-sprint5-20261122/repo/apps/www/node_modules/playwright-core/index.mjs
export PUI_INSPECTOR_BUILD_RECEIPT="$browser_review/evidence/normal-build.json"
export PUI_TREE_BUILD_RECEIPT="$browser_review/evidence/normal-build.json"
export PUI_IM_BUILD_RECEIPT="$browser_review/evidence/normal-build.json"
export PLAYWRIGHT_MODULE="$PUI_PLAYWRIGHT_MODULE"
export CHROMIUM_EXECUTABLE="$PUI_CHROME_EXECUTABLE"
export NODE_OPTIONS=--max-old-space-size=4096
cd "$browser_review/source"
test "$(node --version)" = "v24.22.1" || exit 99
overall=0
for suite in files im inspector tree reading; do
  export PUI_EVIDENCE_DIR="$browser_review/evidence/$suite"
  export READING_EVIDENCE_DIR="$PUI_EVIDENCE_DIR"
  mkdir -p "$PUI_EVIDENCE_DIR"
  printf 'START %s %s\n' "$suite" "$(date -u +%FT%TZ)"
  if test "$suite" = reading; then
    node scripts/web_reading_journey.mjs > "$browser_review/evidence/$suite.log" 2>&1
  else
    node "crates/shenko-ui/web/scripts/$suite-browser.mjs" > "$browser_review/evidence/$suite.log" 2>&1
  fi
  code=$?
  printf '%s\n' "$code" > "$browser_review/evidence/$suite.exit"
  printf 'DONE %s exit=%s %s\n' "$suite" "$code" "$(date -u +%FT%TZ)"
  if test "$code" != 0; then overall=1; fi
done
printf '%s\n' "$overall" > "$browser_review/evidence/driver.exit"
exit "$overall"
