from pathlib import Path
import base64,datetime,gzip,hashlib,json,tarfile
E=Path('/tank/shared/projects/shenko/build/daily-readiness-20261122')
B=E/'release-c931526c'
S='c931526c8ae8cd16f3e0cf56d733f1e4275d5bb0'
M=json.loads((B/'manifest.json').read_text())
assert M['source_revision']==S and M['sha256']=='1ad2899f2c7dff3c0cd5123a16d3dfbb893a9cc8ba85996d5f16a8023c0eeba1' and M['bytes']==90370560
assert (B/'finished.txt').is_file() and int((B/'exit.txt').read_text())==0
assert int((E/'build-frozen-c931526c.host.exit').read_text())==0 and (E/'build-frozen-c931526c.host.finished.txt').is_file()
assert json.loads((E/'release-c931526c-preflight.json').read_text())['source_revision']==S
O=E/'release-c931526c-retained'
O.mkdir(exist_ok=False)
files=[]
sources=[(p,p.name) for p in sorted(B.iterdir()) if p.is_file()]
sources.append((E/'release-c931526c-preflight.json','preflight.json'))
for suffix in ['started.txt','finished.txt','exit']:
 sources.append((E/('build-frozen-c931526c.host.'+suffix),'host/build-frozen-c931526c.host.'+suffix))
sources.append((E.parent/'daily-readiness-20261122-host-build-frozen-candidate.sh','host/runner.sh'))
assert len(sources)==14
for p,rel in sources:
 before=p.stat()
 assert before.st_size<2_000_000
 raw=p.read_bytes()
 after=p.stat()
 assert (before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino)
 compressed=p.suffix=='.log'
 data=gzip.compress(raw,mtime=0) if compressed else raw
 stored_rel=rel+'.gz' if compressed else rel
 q=O/stored_rel
 q.parent.mkdir(parents=True,exist_ok=True)
 q.write_bytes(data)
 files.append({'path':stored_rel,'source':str(p),'source_bytes':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'encoding':'gzip-mtime0' if compressed else 'original','source_mtime_ns':before.st_mtime_ns,'source_inode':before.st_ino,'stable_during_copy':True})
index={'schema_version':1,'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only copy of the completed c931 release evidence; no live model installation or binary contents read.','source_revision':S,'files':files,'excluded':['90,370,560-byte release binary','live final-c931 model batch','Cargo target and dependency binaries']}
(O/'retention-index.json').write_text(json.dumps(index,indent=2)+'\n')
T=E/'release-c931526c-retained.tar.gz'
with T.open('wb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   for p in sorted(O.rglob('*')):
    if p.is_file():tar.add(p,arcname=str(p.relative_to(O)),recursive=False)
raw=T.read_bytes()
C=E/'release-c931526c-retained-transfer'
C.mkdir(exist_ok=False)
chunks=[raw[i:i+12288] for i in range(0,len(raw),12288)]
for i,chunk in enumerate(chunks):(C/f'{i:03d}.txt').write_text(base64.b64encode(chunk).decode()+'\n')
print(json.dumps({'archive':str(T),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'original_files':len(files),'chunks':len(chunks),'chunk_root':str(C)},indent=2))
