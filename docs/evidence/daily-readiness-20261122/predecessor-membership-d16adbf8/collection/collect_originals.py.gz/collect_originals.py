from pathlib import Path
import base64,datetime,gzip,hashlib,io,json,tarfile
r=Path('/tank/shared/projects/shenko/build/daily-readiness-20261122')
out=r/'predecessor-membership-retained-20261122';out.mkdir(exist_ok=False)
index={'schema_version':1,'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Original closed baseline/fixed scoped receipts and selected closed-d16 diagnostic files only. No test, model, Store API, database or new CAS inspection is executed by this collector.','files':[],'excluded':['closed diagnostic inspect executable','native-artifacts directories (retained on authorized device)','release/dependency rlibs','complete original CAS and installation databases']}
def retain(p,name):
 a=p.stat();before={'bytes':a.st_size,'mtime_ns':a.st_mtime_ns,'inode':a.st_ino}
 assert a.st_size<2*1024*1024
 raw=p.read_bytes();z=p.stat();after={'bytes':z.st_size,'mtime_ns':z.st_mtime_ns,'inode':z.st_ino}
 assert before==after
 compress=p.suffix=='.log' or p.suffix=='.json' and len(raw)>16384
 b=gzip.compress(raw,mtime=0) if compress else raw
 if compress:name+='.gz'
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 index['files'].append({'path':name,'source':str(p),'source_bytes':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'encoding':'gzip-mtime0' if compress else 'original','source_stat_before':before,'source_stat_after':after,'stable_during_copy':True})
for folder,dest,revision,hostprefix,status in [
 ('scoped-predecessor-6d087562','baseline-6d087562','6d087562cc33928fa3a6a3fecd012cc5081dc7c3','predecessor-6d087562','1'),
 ('scoped-frozen-closure-95cdc272','fixed-95cdc272','95cdc272866a5f31cedb790d263761523e9b0e2c','frozen-closure-95cdc272','0')]:
 source=r/folder
 s=json.loads((source/'summary.json').read_text());assert s['source_revision']==revision and s['completed_targets']==s['planned_targets']
 assert (source/'finished.txt').is_file() and (source/'exit.txt').read_text().strip()==status
 assert (r/(hostprefix+'.host.exit')).read_text().strip()==status
 for p in sorted(source.iterdir()):
  if p.is_file():retain(p,dest+'/'+p.name)
 for ext in ['started.txt','finished.txt','exit']:
  p=r/(hostprefix+'.host.'+ext);retain(p,dest+'/host/'+p.name)
for dest,name,expected in [
 ('baseline-6d087562','daily-readiness-20261122-host-verify-predecessor-fixture.sh','41b8bbd235ed3679b1b1fb037a02c0244cf67b7361dabc26a4f61ebf7818ac8b'),
 ('fixed-95cdc272','daily-readiness-20261122-host-verify-frozen-closure.sh','7d8d03c3ae0ed6ceebd9950d636fff4afe1fdb2ffe35e56faf47340af6a77f9b')]:
 p=r.parent/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected;retain(p,dest+'/host/runner.sh')
source=r/'closed-predecessor-d16adbf8-attempt003'
m=json.loads((source/'manifest.json').read_text());assert m['source_revision']=='d16adbf89c9f79dfce8ef90d77843412bcda85bf' and m['finished_at'] and m['compile_exit']==m['run_exit']==0
for p in sorted(source.rglob('*')):
 if p.is_file() and p.name!='inspect':retain(p,'closed-d16-attempt003/'+str(p.relative_to(source)))
(out/'retention-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as archive:
 for p in sorted(out.rglob('*')):
  if p.is_file():archive.add(p,arcname=str(p.relative_to(out)))
packed=gzip.compress(stream.getvalue(),mtime=0)
archive=r/'predecessor-membership-retained-20261122.tar.gz';archive.write_bytes(packed)
chunks=r/'predecessor-membership-retained-20261122-transfer';chunks.mkdir(exist_ok=False)
for i,start in enumerate(range(0,len(packed),12288)):
 (chunks/f'{i:03d}.txt').write_text(base64.b64encode(packed[start:start+12288]).decode()+'\n')
print(json.dumps({'archive':str(archive),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'original_files':len(index['files']),'gzip_originals':sum(x['encoding']=='gzip-mtime0' for x in index['files']),'chunks':(len(packed)+12287)//12288,'chunk_root':str(chunks)},indent=2))
