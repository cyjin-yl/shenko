from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,signal,traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E=B/'evidence/continuation-s7-tree-4deb'
WEB=B/'continuation-s7-tree-4deb/crates/shenko-ui/web'
OBSERVER=WEB/'scripts/tree-browser.mjs'
OUT=E/'native-01'
NODE=B/'tools/node-v24.22.3-linux-x64/bin/node'
CHROME=B/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'
EXPECTED='8253d035d3688fc795123e294af4c06809fb52649b8452f1276a054406b83a1f'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sys.argv[1:]==['--start']:
    marker=E/'native-start-01.json'
    if marker.exists():print(marker.read_text());raise SystemExit(0)
    assert json.loads((E/'build-receipt-01.json').read_text())['passed'] is True
    assert sha(OBSERVER)==EXPECTED
    with marker.open('x') as receipt,(E/'native-launch-01.log').open('x') as log:
        child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--run'],
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        start={'startedAt':now(),'pid':child.pid,'wrapperSha256':sha(Path(__file__)),
            'observerSha256':EXPECTED,'output':str(OUT)}
        receipt.write(json.dumps(start,indent=2)+'\n');receipt.flush();print(json.dumps(start))
    raise SystemExit(0)
if sys.argv[1:]!=['--run']:raise SystemExit('Expected --start or --run')
record={'startedAt':now(),'observerSha256Before':sha(OBSERVER),'wrapperTimeoutSeconds':180,
    'launchPolicy':'The existing Shenko observer requires chromiumSandbox=true; no added fallback flags.',
    'passed':False}
try:
    assert record['observerSha256Before']==EXPECTED
    env=dict(os.environ)
    env.pop('PUI_CHROME_NO_SANDBOX',None)
    temp=B.parent/'s67i-tmp';temp.mkdir(exist_ok=True)
    env.update(PATH=str(NODE.parent)+':'+env.get('PATH',''),NODE_OPTIONS='',NODE_PATH='',
        COREPACK_HOME=str(B/'corepack-cache'),TMPDIR=str(temp),
        PROTO_UI_SOURCE=str(B/'continuation-s7-inspector-proto-4deb'),
        PUI_TREE_BUILD_RECEIPT=str(E/'build-receipt-01.json'),
        PUI_EVIDENCE_DIR=str(OUT),PUI_CHROME_EXECUTABLE=str(CHROME),
        PUI_PLAYWRIGHT_MODULE=str(B/'s67-734-calibration-4deb-04/candidate-consumer/node_modules/playwright-core/index.mjs'))
    record['argv']=[str(NODE),str(OBSERVER)]
    record['browserExecutableSha256']=sha(CHROME)
    with (E/'native-01.stdout.log').open('x') as out,(E/'native-01.stderr.log').open('x') as err:
        child=subprocess.Popen(record['argv'],cwd=WEB,env=env,stdin=subprocess.DEVNULL,
            stdout=out,stderr=err,start_new_session=True)
        record['childPid']=child.pid
        try:record['exitCode']=child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['timedOut']=True
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            record['exitCode']=child.returncode
    record['observerSha256After']=sha(OBSERVER)
    record['sourceStable']=record['observerSha256Before']==record['observerSha256After']
    if (OUT/'report.json').exists():
        native=json.loads((OUT/'report.json').read_text())
        record['nativeReceiptSha256']=sha(OUT/'report.json')
        record['cases']=[{'name':c['name'],'passed':c['passed']} for c in native['cases']]
        record['passed']=record['exitCode']==0 and native['passed'] is True and record['sourceStable']
except Exception:record['failure']=traceback.format_exc()
finally:
    record['finishedAt']=now()
    (E/'native-execution-01.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
