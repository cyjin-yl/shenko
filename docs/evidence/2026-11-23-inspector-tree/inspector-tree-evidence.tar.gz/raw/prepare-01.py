from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
S=B/'continuation-s7-inspector-4deb';T=B/'continuation-s7-tree-4deb';E=B/'evidence/continuation-s7-tree-4deb'
BASE='d5894753586ae557e62193ac5a94fb96285601aa';BRANCH='work/sprint7-tree-20261123'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sys.argv[1:]==['--start']:
 m=E/'prepare-start-01.json'
 try:r=m.open('x')
 except FileExistsError:print(m.read_text());raise SystemExit(0)
 with r,(E/'prepare-launch-01.log').open('x') as log:
  c=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--run'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  j={'startedAt':now(),'pid':c.pid,'scriptSha256':sha(Path(__file__))};r.write(json.dumps(j,indent=2)+'\n');r.flush();print(json.dumps(j))
 raise SystemExit(0)
assert sys.argv[1:]==['--run']
record={'startedAt':now(),'base':BASE,'branch':BRANCH,'worktree':str(T),'steps':[],'passed':False}
env=dict(os.environ);env.update(GIT_TERMINAL_PROMPT='0',TMPDIR=str(B.parent/'s67i-tmp'))
def save():(E/'prepare-progress-01.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,args,cwd=S,accept=(0,)):
 out=E/(name+'-01.stdout.log');err=E/(name+'-01.stderr.log')
 item={'name':name,'argv':args,'cwd':str(cwd),'startedAt':now()};record['steps'].append(item);save()
 with out.open('x') as o,err.open('x') as e:
  c=subprocess.Popen(args,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e);item['pid']=c.pid;save();code=c.wait()
 item.update(exitCode=code,finishedAt=now(),stdoutSha256=sha(out),stderrSha256=sha(err));save()
 if code not in accept:raise RuntimeError(name+' failed '+str(code))
 return out.read_text(),code
try:
 assert run('source-head',['git','rev-parse','HEAD'])[0].strip()==BASE
 assert not T.exists(),'Target worktree already exists; reconcile instead of replay'
 _,code=run('branch-absent',['git','show-ref','--verify','--quiet','refs/heads/'+BRANCH],accept=(1,))
 assert code==1
 run('worktree-add',['git','worktree','add','-b',BRANCH,str(T),BASE])
 assert run('tree-head',['git','rev-parse','HEAD'],T)[0].strip()==BASE
 run('author-name',['git','config','user.name','Codex'],T)
 run('author-email',['git','config','user.email','codex@openai.com'],T)
 source_web=S/'crates/shenko-ui/web';target_web=T/'crates/shenko-ui/web'
 assert (source_web/'pnpm-lock.yaml').read_bytes()==(target_web/'pnpm-lock.yaml').read_bytes()
 record['lockSha256']=sha(target_web/'pnpm-lock.yaml');record['externalDependencies']=[]
 nm=target_web/'node_modules';nm.mkdir()
 for name in ['react','react-dom','@types/react','@types/react-dom','esbuild','typescript']:
  target=(source_web/'node_modules'/name).resolve(strict=True)
  link=nm/name;link.parent.mkdir(parents=True,exist_ok=True)
  assert not link.exists() and not link.is_symlink()
  link.symlink_to(target,target_is_directory=True)
  record['externalDependencies'].append({'package':name,'link':str(link),'target':str(target)})
 record['sourceHeadAfter']=run('source-head-after',['git','rev-parse','HEAD'])[0].strip()
 assert record['sourceHeadAfter']==BASE
 record['passed']=True
except Exception:record['failure']=traceback.format_exc();print(record['failure'],flush=True)
finally:
 record['finishedAt']=now();save();(E/'prepare-receipt-01.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'passed':record['passed'],'finishedAt':record['finishedAt']}),flush=True)
