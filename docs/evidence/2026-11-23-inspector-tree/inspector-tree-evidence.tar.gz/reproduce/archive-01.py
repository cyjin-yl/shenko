from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,traceback,tarfile,gzip,io,re,shutil
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E=B/'evidence/continuation-s7-tree-4deb'
S=B/'continuation-s7-tree-4deb'
D=S/'docs/evidence/2026-11-23-inspector-tree'
P=B/'evidence/continuation-s7-inspector-4deb'
BASE='d5894753586ae557e62193ac5a94fb96285601aa'
UPSTREAM='6a9b575fbe744ccb2f54d1e45336ccc195f401f1'
README="# Inspector: two independent public Tree domains\n\nThis increment implements Proto-UI #523 in the existing Shenko application. Tasks use explicit `parent_task_id` facts. Playground artifacts use authored MIME categories; an artifact's `parent_revision` remains revision provenance and never becomes a Tree parent ID.\n\nThe increment is based on Shenko `d5894753586ae557e62193ac5a94fb96285601aa`, the Inspector Resizable change published as draft [#402](https://github.com/cyjin-yl/shenko/pull/402). It consumes the explicitly pinned Proto-UI candidate `6a9b575fbe744ccb2f54d1e45336ccc195f401f1`. It does not rebind these results to a later main or candidate.\n\n## What changed\n\n- The actual Tasks and Playground Inspector lenses compose separate public Shadcn Tree Root/Item/Group domains through the existing React adapter. The compiler still generates only Shenko's existing transport badge and message bubble; the browser does not import the compiler.\n- Public Tree owns hierarchy validation, disclosure, roving focus, keyboard navigation, typeahead and accessibility relationships. The App supplies records and responds to public activation proposals. It keeps a controlled-empty selected value rather than asserting a new portable single-selection contract.\n- A task activation displays the actual task record. An HTML artifact activation enters the existing WorkFrame/adopted-page route. A missing adopted page remains missing; no replacement preview or editor is introduced.\n- Subject/source/surface identity replaces each Tree owner. Retired callbacks and a pointer contact begun on a previous subject cannot inspect a record in the new owner. The main stream and editor host retain their identities.\n- Duplicate keys, cycles, orphans and empty keys remain authored for public Tree validation. React reconciliation keys for invalid records do not repair their public keys. Invalid domains expose the public invalid state and leave the other domain usable.\n- The standalone demo now authors explicit task parent facts. Live task names, roles, team labels and creation order are never used to invent ancestry.\n\n## Exact validation\n\nThe machine-readable `validation.json` and `manifest.json` bind every source, asset, observer and raw receipt below. All archived payloads were decoded and verified against their individual SHA-256 values.\n\n| Lane | Actual result | Scope |\n| --- | --- | --- |\n| Existing public package producer | 42/42, unchanged exact 6a9 source | Reuses the prior source-bound producer, with fresh clean-head/lock verification in both App builds |\n| App build 01 | strict TypeScript exit 0; 59/59 Node tests; normal producer exit 0 | Original product candidate |\n| App build 02 | strict TypeScript exit 0; 59/59 Node tests; normal producer exit 0 | Current product bytes; source stable |\n| Native 01 | 0/4 | Preserved new observer failure: record attributes were read from an adapter host that does not forward arbitrary data attributes |\n| Native 02 | 4/4; 63 checks | Preserved success for the Tree flows; subsequent visual inspection found an unimplemented background conversation read fixture, visible as HTTP 404 in the desktop screenshot |\n| Native 03 | __NATIVE_RESULT__ | Same product and original Tree assertions/budgets; explicit `/api/conversations` empty DTO plus a background-read health check in each of the four journeys |\n\nNative 01's original component and observer bytes are retained. The fix places the record marker on the App's existing native label span, and the observer reads the real parent treeitem. The later fixture correction supplies the same `{available: true, messages: []}` read protocol already used by the repository's original reading journey. No product error message is hidden and no tested Tree condition is relaxed.\n\nThe four journeys exercise:\n\n1. Desktop Tasks: exact server ancestry, sibling ordinals, Item/Group relationships, pointer disclosure, Arrow/Home/End/typeahead/Enter navigation, task details and domain isolation.\n2. Desktop Playground: exact MIME grouping, independent task state, keyboard activation of an actual HTML artifact, the existing missing-adoption path, and stable main/editor identities.\n3. A 390px dark forced-colors viewport: visible 2px keyboard outline, actual HTTP/WebSocket invalid-to-valid refresh, all invalid records retained, exact recovered hierarchy, independent-domain recovery and no horizontal page overflow.\n4. Subject retirement: a trusted pointer contact begins on the old subject, an actual identity read replaces both domains before release, the late release cannot act on the new owner, and fresh activation still works.\n\nThe observer requests `chromiumSandbox: true`, adds no fallback launch flags, and uses the pinned Chrome 145.0.7632.6 executable. Playwright keyboard and pointer events are recorded with `isTrusted=true`; this is browser automation evidence, not physical-device input. The process wrapper stays at 180 seconds and the original interaction polls stay at 1000ms.\n\nThe 63 checks in Native 02 and the __FINAL_CHECKS__ checks in Native 03 belong to these four Tree journeys. They are **not** the historical 63-row Agent Harness denominator. This increment adds four unit tests and four native journeys, within Shenko's fewer-than-ten-test rule for a coherent increment.\n\n## Reproduction\n\nUse a clean checkout of the recorded Shenko increment and the exact Proto-UI pin in `crates/shenko-ui/web/upstream-pin.json`. Build the ordinary public adapter-react/prototypes-shadcn/CLI closure with Proto-UI's `scripts/build/public-packages.mjs`; keep its actual JSON receipt. From `crates/shenko-ui/web`, run:\n\n```sh\nnode build.mjs --prototypes-only\nnode node_modules/typescript/bin/tsc --noEmit\nnode --test tests/*.test.mjs\nnode build.mjs\nnode scripts/tree-browser.mjs\n```\n\nThe ordinary producer and observer require the source-bound environment recorded in the archived wrappers: `PROTO_UI_SOURCE`, `PROTO_UI_BUILD_RECEIPT`, `PUI_TREE_BUILD_RECEIPT`, `PUI_CHROME_EXECUTABLE`, `PUI_PLAYWRIGHT_MODULE` and an owned `PUI_EVIDENCE_DIR`. The observer independently compares the current source snapshot, normal build receipt, compiler generation manifest, upstream pin/lock and every generated asset before launching.\n\n`inspector-tree-evidence.tar.gz` contains original preparation/build/native scripts and stdout/stderr, failures, current and prior source snapshots, normal generated assets, public producer receipts and all four native screenshots. Native 01's source and receipts are fully reconstructible; its overwritten build-01 static assets are not claimed to be archived. Native 02/03 share the archived normal build-02 product assets.\n\nThe relevant React review checked public subpath imports, memoized derived record/presentation data, lazy expansion initialization, event-scoped side effects, current callback references, subject-bound ownership and cleanup. It introduced no raw input/focus state machine or unrelated optimization.\n\n## Boundaries that remain open\n\nThis run combines the production App renderer/controller with deterministic HTTP and WebSocket **read fixtures**. It does not validate a live backend/model, physical hardware, platform assistive technology, lazy-loading or virtualization. It does not approve the complete portable Tree contract or resolve its remaining draft alignment.\n\nThe preceding Inspector Resizable evidence remains pinned separately. The existing narrow overlay is not promoted here to mobile-modal acceptance. Original reading/follow-tail journeys, the full Agent Harness 63-row ledger, editor fallback boundaries, Apple/120Hz/AT and other Sprint conditions retain their own gates and evidence.\n"
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def shab(b):return hashlib.sha256(b).hexdigest()
def sha(p):return shab(p.read_bytes())
def write_json(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
if sys.argv[1:]==['--start']:
    marker=E/'archive-start-01.json'
    if marker.exists():print(marker.read_text());raise SystemExit(0)
    assert json.loads((E/'native-execution-03.json').read_text())['passed'] is True
    with marker.open('x') as receipt,(E/'archive-launch-01.log').open('x') as log:
        child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--run'],
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        value={'startedAt':now(),'pid':child.pid,'scriptSha256':sha(Path(__file__))}
        receipt.write(json.dumps(value,indent=2)+'\n');receipt.flush();print(json.dumps(value))
    raise SystemExit(0)
if sys.argv[1:]!=['--run']:raise SystemExit('Expected --start or --run')
record={'startedAt':now(),'passed':False,'base':BASE,'upstream':UPSTREAM}
try:
    env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,env=env,timeout=120,text=True).strip()
    assert head==BASE,head
    native=json.loads((E/'native-03/report.json').read_text())
    previous=json.loads((E/'native-02/report.json').read_text())
    first=json.loads((E/'native-01/report.json').read_text())
    build=json.loads((E/'build-receipt-02.json').read_text())
    assert native['passed'] and native['sourceStable'] and native['assetStable']
    assert len(native['cases'])==4 and all(c['passed'] for c in native['cases'])
    assert native['pageErrors']==[] and native['cleanupErrors']==[] and native['writes']==[]
    assert build['passed'] and build['sourceStable']
    assert native['sourceBefore']==build['sourceAfter']==previous['sourceBefore']
    assert native['sourceAfter']==native['sourceBefore']
    assert native['upstreamCandidate']==UPSTREAM
    assert sha(S/'crates/shenko-ui/web/scripts/tree-browser.mjs')==native['observerSha256']
    assert native['observerSha256']=='0541ba1dc6e6532f7877aa984f8e6dcfc3fee8a58fffc6f4233e07823c96e294'
    assert native['launchOptions']['chromiumSandbox'] is True
    assert not native['launchOptions'].get('args')
    counts=[len(c['checks']) for c in native['cases']]
    assert sum(counts)==67,counts
    for c in native['cases']:
        assert all(v['passed'] for v in c['checks'])
        assert all(v['trusted'] for v in c['inputs'])
    payloads={}
    def add(name,data):
        assert name not in payloads,name
        assert not name.startswith('/') and '..' not in Path(name).parts,name
        payloads[name]=data
    for path in sorted(E.rglob('*')):
        if not path.is_file():continue
        relative=str(path.relative_to(E))
        if relative.startswith(('archive-','commit-','git-')) or relative.endswith('.bundle'):continue
        add('raw/'+relative,path.read_bytes())
    add('reproduce/archive-01.py',Path(__file__).read_bytes())
    sources=dict(native['sourceBefore'])
    extra=['crates/shenko-ui/web/scripts/tree-browser.mjs','crates/shenko-ui/src/index.html',
        'docs/specs/web-interface.md','docs/IMPLEMENTATION_DOCS_MAP.md','AGENTS.md',
        '.agents/skills/shenko-dev/SKILL.md','docs/governance/COMPLETION.md','docs/governance/GITHUB.md',
        'scripts/web_reading_journey.mjs']
    for relative in extra:sources[relative]=sha(S/relative)
    for relative,expected in sources.items():
        data=(S/relative).read_bytes();assert shab(data)==expected,relative
        add('source/'+relative,data)
    first_differences=[]
    for relative,expected in first['sourceBefore'].items():
        data=(S/relative).read_bytes()
        if shab(data)!=expected:
            assert relative=='crates/shenko-ui/web/src/inspector-trees.tsx',relative
            data=(E/'component-01.tsx').read_bytes()
            first_differences.append(relative)
        assert shab(data)==expected,relative
        add('prior-source/native-01/'+relative,data)
    assets=S/'crates/shenko-ui/src/static'
    asset_manifest=json.loads((assets/'build-manifest.json').read_text())
    assert sha(assets/'build-manifest.json')==native['buildManifestSha256']
    for name,fact in asset_manifest['artifacts'].items():
        data=(assets/name).read_bytes()
        assert shab(data)==fact['sha256'] and len(data)==fact['bytes'],name
    for path in sorted(assets.rglob('*')):
        if path.is_file():add('assets/'+str(path.relative_to(assets)),path.read_bytes())
    for path in sorted((S/'crates/shenko-ui/web/generated/prototypes').rglob('*')):
        if path.is_file():add('generated/prototypes/'+str(path.relative_to(S/'crates/shenko-ui/web/generated/prototypes')),path.read_bytes())
    for name in ['public-packages-01.json','build-receipt-01.json']:
        add('upstream/'+name,(P/name).read_bytes())
    public=json.loads((P/'public-packages-01.json').read_text())
    assert public['selectedCount']==42 and len(public['results'])==42
    assert sha(P/'public-packages-01.json')==build['publicReceiptSha256']
    review=json.loads((E/'tree-review-source-02.json').read_text())
    validation={'schemaVersion':1,'base':BASE,'upstreamCandidate':UPSTREAM,
        'scope':'Production App/controller with deterministic HTTP/WS read fixtures; not live backend/model or physical/AT acceptance.',
        'builds':{'01':{'passed':True,'receiptSha256':sha(E/'build-receipt-01.json')},
                  '02':{'passed':True,'receiptSha256':sha(E/'build-receipt-02.json'),'nodeTests':59,'strictExitCode':0}},
        'native':{attempt:{'passed':report['passed'],'cases':len(report['cases']),
            'passedCases':sum(bool(c['passed']) for c in report['cases']),
            'checks':sum(len(c['checks']) for c in report['cases']),
            'reportSha256':sha(E/('native-'+attempt)/'report.json'),
            'observerSha256':report['observerSha256'],
            'sourceHash':report['sourceHash'],'sourceStable':report['sourceStable'],
            'assetStable':report['assetStable'],'startedAt':report['startedAt'],'finishedAt':report['finishedAt']}
            for attempt,report in [('01',first),('02',previous),('03',native)]},
        'sourceHash':native['sourceHash'],'sourceFiles':sources,
        'assetManifestSha256':native['buildManifestSha256'],'assets':asset_manifest['artifacts'],
        'htmlSha256':native['htmlSha256'],'launchOptions':native['launchOptions'],
        'browserVersion':native['browserVersion'],'newUnitTests':4,'newNativeJourneys':4,
        'native01SourceDifferences':first_differences,
        'originalFailureNotes':[
            'Native01 used non-forwarded adapter host data attributes; original failed report/source/observer are preserved.',
            'Native02 passed Tree flows; visual inspection exposed the missing /api/conversations read fixture. Original screenshot/report are preserved.',
            'Native03 supplies the actual empty conversation DTO and adds a read-health check to each original journey. Product bytes, original assertions and budgets are unchanged.'],
        'remaining':['Original Harness 63 rows remain independently scoped.','Live backend/model, physical devices, AT, lazy/virtualized and portable Tree admission are not claimed.','Mobile-modal Inspector and original reading/follow-tail gates remain separate.'],
        'review':['shenko-dev rules: 4 unit + 4 native tests < 10','React checklist: public imports, derived memoization, event effects, subject ownership and cleanup','Desktop and forced-colors phone screenshots read visually; native02 fixture issue is retained.']}
    validation_bytes=(json.dumps(validation,ensure_ascii=False,indent=2)+'\n').encode()
    add('validation.json',validation_bytes)
    # Do not publish credentials or machine-private files. Only the explicitly selected task payloads enter this archive.
    secret_patterns=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{40,}',rb'xox[baprs]-[A-Za-z0-9-]{20,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
    for name,data in payloads.items():
        if name.endswith('.png'):continue
        for pattern in secret_patterns:assert not re.search(pattern,data),('credential-pattern',name)
    D.mkdir(parents=True,exist_ok=False)
    archive=D/'inspector-tree-evidence.tar.gz'
    with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for name,data in sorted(payloads.items()):
            member=tarfile.TarInfo(name);member.size=len(data);member.mtime=0;member.mode=0o644
            tar.addfile(member,io.BytesIO(data))
    manifest={'schemaVersion':1,'base':BASE,'upstreamCandidate':UPSTREAM,
        'payloadCount':len(payloads),'decodedBytes':sum(map(len,payloads.values())),
        'payloads':[{'path':name,'bytes':len(data),'sha256':shab(data)} for name,data in sorted(payloads.items())],
        'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}}
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers()
        assert len(members)==len(payloads)
        for member in members:
            data=tar.extractfile(member).read()
            assert data==payloads[member.name],member.name
    write_json(D/'manifest.json',manifest)
    (D/'validation.json').write_bytes(validation_bytes)
    readme=README.replace('__NATIVE_RESULT__','4/4; '+str(sum(counts))+' checks; zero page/cleanup errors and business writes; source and assets stable').replace('__FINAL_CHECKS__',str(sum(counts)))
    (D/'README.md').write_text(readme)
    for name,target in [('tasks-desktop.png','desktop.png'),('phone-invalid-and-recovery.png','phone.png')]:
        shutil.copyfile(E/'native-03'/name,D/target)
    record.update(passed=True,directory=str(D),manifestSha256=sha(D/'manifest.json'),
        validationSha256=sha(D/'validation.json'),archive=manifest['archive'],
        payloadCount=manifest['payloadCount'],decodedBytes=manifest['decodedBytes'],
        sourceCount=len(sources),artifactCount=len(asset_manifest['artifacts']),
        cases=4,checks=sum(counts),sourceHash=native['sourceHash'])
except Exception:
    record['failure']=traceback.format_exc();print(record['failure'],flush=True)
finally:
    record['finishedAt']=now()
    write_json(E/'archive-receipt-01.json',record)
    print(json.dumps(record,ensure_ascii=False),flush=True)
