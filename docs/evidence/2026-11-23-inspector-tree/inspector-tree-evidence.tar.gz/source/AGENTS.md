# Working on Shenko

Build the complete Shenko personal agent, including **all S1–S5**. A first release or PR is progress; completion follows the [completion contract](docs/governance/COMPLETION.md).

## Current reading policy (T6)

Every developer and writing agent reads this entry and [shenko-dev](.agents/skills/shenko-dev/SKILL.md) at their current versions. Then read the current domain contract and expanded sections needed for the task. Keep context focused on intent and facts.

[DEVELOPMENT.md](DEVELOPMENT.md) and the Skill's [REFERENCE.md](.agents/skills/shenko-dev/REFERENCE.md) are **current expanded guidance**, preserved byte-for-byte with every obligation and user word. Their blanket full-read sentences record the prior reading policy; this entry replaces that loading requirement only. All substantive requirements remain effective. `CLAUDE.md` stays a symlink to this file.

## Active rules

- Latest explicit user decisions control intent. Follow [docs/INDEX.md](docs/INDEX.md) to the relevant domain contract, Why, assumptions and observable effects. Root `SPEC.md` and `WHY.md` are navigation. Preserve requirement identities and sources; use the [migration map](docs/contract-migration.json) for old chapters.
- Resume existing source, checkpoints and evidence. Preserve raw data, experiences, immutable facts, public paths and authorship. Migrate internal callers to the real native contract and remove obsolete aliases, fallback paths and compatibility scaffolding. Rust uses **2024 edition**; the minimal core uses **cordis-rs**.
- Distinguish goals, implementation, installed/enabled capability and observed results. Retain failed receipts and source/environment bindings. Keep **Unknown** outcomes explicit; reconcile external effects before replay. Never fabricate evidence, approval or credentials.
- Use isolated persistent worktrees, self-contained assignments and a named integration owner. Build in the project devcontainer against the same persistent source. Coordinate shared seats, models, ports and databases; heavy work uses shared admission and real capacity. No fixed worker-count ceiling replaces those constraints.
- Act autonomously within existing authorization; exhaust reachable resources when blocked. Add no human gates for plans, stages, tests, PRs or continuation. Actual access controls remain facts. Preserve recoverability and keep advancing independent work.
- Resolve concrete questions with meaningful scoped checks and reusable evidence. Simple reversible changes may need none. Never add ten or more tests for one coherent increment or evade that limit by splitting cases/workers/PRs. Stop when evidence is sufficient; model behavior requires the real-model comparison described in the Skill.
- Monitor claimed issues/PRs. Within **3 hours** of a triggering comment's UTC timestamp, respond or report handling, blocker and next checkpoint. Takeover requires no response, no handling notice and no verifiable checkpoint. Continue from pushed source on a new branch; preserve author, commits and source PR, record trigger/base/owner, and never force-push another contributor's branch.

## Navigate for the task

- Product invariants: [shenko-dev](.agents/skills/shenko-dev/SKILL.md); expanded [identity](DEVELOPMENT.md#preserve-the-products-identity).
- Locate current implementation: [source of truth](DEVELOPMENT.md#find-the-source-of-truth), [implementation map](docs/IMPLEMENTATION_DOCS_MAP.md), [coverage](docs/state/coverage.json).
- Design and integration: [engineering judgment](DEVELOPMENT.md#exercise-engineering-judgment), [parallel work](DEVELOPMENT.md#parallelize-and-integrate).
- Evidence: [prove behavior](DEVELOPMENT.md#prove-behavior); delivery/checkpoints: [continuation](DEVELOPMENT.md#continue-through-prs-and-session-changes).
- Contributor handoff: [three-hour rule](DEVELOPMENT.md#issuepr-monitoring-and-three-hour-continuation). Optional task methods are linked from the Skill.
