#!/bin/bash
set -euo pipefail
compiler_review=/home/ezra/shenko-pr411-compiler-20261125-55114
compiler_volume=/tank/docker/doescontainer/docker/volumes/shenko-target-r71/_data
expected_upstream=bdc564c0da040a9b8438b1a94b3eaea74cb94b67
mkdir -p "$compiler_review/tooling/bin" "$compiler_review/evidence" "$compiler_review/observer/scripts/ci" "$compiler_review/observer/.ci/web"
trap 'result=$?; printf "%s\n" "$result" > "$compiler_review/evidence/runner-exit-code.txt"; date -u +%FT%TZ > "$compiler_review/evidence/runner-finished-at.txt"' EXIT
printf 'exporting-toolchain\n' > "$compiler_review/evidence/phase.txt"
date -u +%FT%TZ > "$compiler_review/evidence/runner-started-at.txt"
sudo -n cat "$compiler_volume/daily-readiness-node-v24.22.1/node_modules/node/bin/node" > "$compiler_review/tooling/bin/node"
chmod +x "$compiler_review/tooling/bin/node"
sudo -n tar -C "$compiler_volume/daily-readiness-node-v24.22.1/corepack/v1/pnpm" -cf - 10.32.1 | tar -C "$compiler_review/tooling" -xf -
ln -s ../10.32.1/bin/pnpm.cjs "$compiler_review/tooling/bin/pnpm"
printf 'exporting-upstream\n' > "$compiler_review/evidence/phase.txt"
sudo -n tar -C "$compiler_volume/pr411-review-20261125-55114" -cf - proto-ui | tar -C "$compiler_review" -xf -
sudo -n cat "$compiler_volume/pr411-review-20261125-55114/source/scripts/ci/compiler_browser.mjs" > "$compiler_review/observer/scripts/ci/compiler_browser.mjs"
sudo -n cat "$compiler_volume/pr411-review-20261125-55114/source/crates/shenko-ui/web/upstream-pin.json" > "$compiler_review/evidence/consumer-upstream-pin.json"
python3 - "$compiler_review" <<'PY'
import json,pathlib,sys
root=pathlib.Path(sys.argv[1]); pin=json.loads((root/'evidence/consumer-upstream-pin.json').read_text())
assert pin['commit']=='bdc564c0da040a9b8438b1a94b3eaea74cb94b67',pin['commit']
(root/'observer/.ci/web/inputs.json').write_text(json.dumps({'pin':pin},indent=2)+'\n')
PY
ln -s "$compiler_review/proto-ui" "$compiler_review/observer/.ci/web/proto-ui"
export PATH="$compiler_review/tooling/bin:$PATH"
export CHROME_PATH=/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome
export CANDIDATE_SHA="$expected_upstream"
export COMPILER_EVIDENCE_DIR="$compiler_review/evidence/browser"
export PROTO_UI_RUNTIME_EVIDENCE_DIR="$compiler_review/evidence/native"
unset GITHUB_SHA GITHUB_RUN_ID GITHUB_RUN_ATTEMPT
cd "$compiler_review/proto-ui"
test "$(id -u)" -ne 0
test "$(git rev-parse HEAD)" = "$expected_upstream"
test "$(node --version)" = v24.22.1
test "$(pnpm --version)" = 10.32.1
{
  id
  node --version
  pnpm --version
  "$CHROME_PATH" --version
  git rev-parse HEAD
  git rev-parse 'HEAD^{tree}'
  sha256sum pnpm-lock.yaml
} > "$compiler_review/evidence/environment.txt"
git status --porcelain=v1 > "$compiler_review/evidence/source-before.txt"
python3 - "$compiler_review/evidence/tracked-before.json" <<'PY'
import hashlib,json,os,pathlib,subprocess,sys
result={}
for raw in subprocess.check_output(['git','ls-files','-z']).split(b'\0'):
 if not raw: continue
 path=pathlib.Path(os.fsdecode(raw)); data=os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
 result[str(path)]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'symlink':path.is_symlink()}
pathlib.Path(sys.argv[1]).write_text(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n')
PY
printf 'ready-awaiting-shared-lock\n' > "$compiler_review/evidence/phase.txt"
exec 9>/tank/shared/projects/shenko/build/cargo.lock
flock 9
printf 'sandbox-preflight\n' > "$compiler_review/evidence/phase.txt"
node "$compiler_review/observer/scripts/ci/compiler_browser.mjs" 2>&1 | tee "$compiler_review/evidence/compiler-browser.log"
cp "$compiler_review/observer/.ci/evidence/compiler-browser.json" "$compiler_review/evidence/compiler-browser.json"
printf 'full-vitest\n' > "$compiler_review/evidence/phase.txt"
date -u +%FT%TZ > "$compiler_review/evidence/vitest-started-at.txt"
set +e
pnpm exec vitest run packages/compiler --maxWorkers=1 --minWorkers=1 2>&1 | tee "$compiler_review/evidence/compiler-vitest.log"
vitest_result=${PIPESTATUS[0]}
set -e
printf '%s\n' "$vitest_result" > "$compiler_review/evidence/vitest-exit-code.txt"
date -u +%FT%TZ > "$compiler_review/evidence/vitest-finished-at.txt"
git status --porcelain=v1 > "$compiler_review/evidence/source-after.txt"
python3 - "$compiler_review" "$vitest_result" <<'PY'
import hashlib,json,os,pathlib,re,subprocess,sys
root=pathlib.Path(sys.argv[1]); result={}
for raw in subprocess.check_output(['git','ls-files','-z']).split(b'\0'):
 if not raw: continue
 path=pathlib.Path(os.fsdecode(raw)); data=os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
 result[str(path)]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'symlink':path.is_symlink()}
(root/'evidence/tracked-after.json').write_text(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n')
prior=json.loads((root/'evidence/tracked-before.json').read_text())
clean_log=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',(root/'evidence/compiler-vitest.log').read_text())
receipt={'upstream':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'pnpm':subprocess.check_output(['pnpm','--version'],text=True).strip(),'command':['pnpm','exec','vitest','run','packages/compiler','--maxWorkers=1','--minWorkers=1'],'exitCode':int(sys.argv[2]),'trackedSourceStable':prior==result,'changedTrackedFiles':[key for key in set(prior)|set(result) if prior.get(key)!=result.get(key)],'sourceStatusStable':(root/'evidence/source-before.txt').read_bytes()==(root/'evidence/source-after.txt').read_bytes(),'summaryLines':[line.strip() for line in clean_log.splitlines() if re.match(r'^\s*(Test Files|Tests|Duration|Start at)\s',line)],'startedAt':(root/'evidence/vitest-started-at.txt').read_text().strip(),'finishedAt':(root/'evidence/vitest-finished-at.txt').read_text().strip(),'logSha256':hashlib.sha256((root/'evidence/compiler-vitest.log').read_bytes()).hexdigest()}
(root/'evidence/compiler-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
PY
printf 'completed\n' > "$compiler_review/evidence/phase.txt"
exit "$vitest_result"
