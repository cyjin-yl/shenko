# PR 411 frozen compiler validation evidence

This archive records the completed, unmodified full compiler run at upstream bdc564c0da040a9b8438b1a94b3eaea74cb94b67. It is not a full-suite run at the later 6ca8f262 pin.

The command was pnpm exec vitest run packages/compiler --maxWorkers=1 --minWorkers=1, with Node v24.22.1, pnpm 10.32.1, and non-root sandboxed Chromium. Start: 2026-11-24T19:42:31Z. Finish: 2026-11-24T20:19:44Z. Duration: 2231.19 seconds. Exit: 1.

Files: 5 failed, 307 passed, 2 skipped, 314 total.
Tests: 4 failed, 4939 passed, 98 skipped, 5041 total.
The six prior regression files all passed, 141 tests in total.
Before/after tracked source bytes and Git status are identical.

Read archive-summary.json and evidence/compiler-receipt.json for the exact result. The complete raw combined Vitest stdout/stderr is evidence/compiler-vitest.log. Actual browser/native JSON receipts are retained under evidence/browser and evidence/native. The unchanged sandbox observer, its exact inputs, and raw preflight result are under observer and evidence.

Attempt 1 was interrupted during export by an observed host reboot, before tests started. No cause of the reboot is attributed. Attempt 2 was deliberately retired during the slow export in favor of the fresh exact-commit/frozen-lock checkout, before tests started. Their existing drivers, logs, phases, and receipts are included without alteration. Neither is represented as a passing run.

archive-manifest.json lists every included evidence file, original path, byte count, and SHA256. The manifest itself is included and verified separately by the external archive receipt. The archive excludes node_modules, generated fixture trees, Vite caches, screenshots, trace ZIPs, and generated JS/CSS/TS/HTML. Complete source, tooling, partial export, and large artifacts remain on the host at the absolute boundaries recorded in archive-summary.json.
