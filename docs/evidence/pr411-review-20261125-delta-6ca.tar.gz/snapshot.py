import hashlib,json,os,pathlib,subprocess,sys
result={}
for raw in subprocess.check_output(['git','ls-files','-z']).split(b'\0'):
 if not raw: continue
 p=pathlib.Path(os.fsdecode(raw)); data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
 result[str(p)]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'symlink':p.is_symlink()}
pathlib.Path(sys.argv[1]).write_text(json.dumps(result,sort_keys=True,separators=(',',':'))+'\n')
