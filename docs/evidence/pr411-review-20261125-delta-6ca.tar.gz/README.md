# Proto-UI 6ca selected delta checks for Shenko PR 411

## Result

The two authorized existing targeted groups completed with exit code 1. No source, test, fixture, configuration, timeout, or dependency-lock changes were made. There was no retry. This is not a passing compiler-suite receipt.

| Existing group | Executed | Passed | Failed | Filtered existing cases | Exit |
|---|---:|---:|---:|---:|---:|
| CLI real family preset inherited physical closure | 4 | 0 | 4 | 4 | 1 |
| Compiler release family consumers, Shadcn and Brutalist | 8 | 4 | 4 | 6 | 1 |

The CLI group failed all four original 120000ms per-test time budgets (Shadcn, Brutalist, bootstrap-2-3-2, liquid-glass). Actual group duration was 519.06 seconds. This does not establish whether the later closure assertions would pass. No time budget was increased.

In the compiler group, all four Shadcn target profiles passed. All four Brutalist profiles failed PUI1008, `Static initializer has no declared binding Set.`, at `packages/prototypes/brutalist/src/button/button.proto.ts:77`. The 6ca source newly declares `ICON_SIZES = new Set<BrutalistButtonSize>(...)`; the bdc source did not. The unchanged original bdc full-run log records the entire release-family-consumer file as 14 tests passed. Its original log hash and result excerpt are retained here. Actual 6ca group duration was 13.01 seconds.

## Exact binding and execution

Upstream: 6ca8f262a074ed19cb24b35d5cc199b5b0e23e08

Root tree: 698b193bb742ac0a984bb7b08569194aea734e46

pnpm-lock.yaml SHA256: eae18430bd967c94def36809b6d3305fa156a96548b08215a18dfe8a43923c07

Node v24.22.1; pnpm 10.32.1; fresh `HUSKY=0 pnpm install --frozen-lockfile` succeeded. The shared canonical `/tank/shared/projects/shenko/build/cargo.lock` was held for installation, sandbox preflight, and both selected groups. The browser preflight ran as uid 1000 with Playwright 1.58.2 and Chrome for Testing 145.0.7632.6. Chromium sandbox was enabled, with namespace and Seccomp-BPF status confirmed.

Exact commands are preserved in the command text files and delta-receipt.json. Counts are parsed from the actual Vitest summaries; 4+8 executed and 4+6 filtered matched the expected existing-case selections. Before/after hashes cover every tracked upstream file and are identical. Both git porcelain snapshots are empty. The original bdc checkout and full-run results were read only.

## Scope and remaining limitations

The 60 Git tree/blob identities from the immutable GitHub audit were independently verified using the actual bdc and 6ca checkouts. Compiler source/test trees and core, modules, adapters, hooks, runtime, native, scripts, lock, and config trees are unchanged. The CLI proto-style-css.ts renderer is an actual changed external compiler dependency: it adds bounded --pui-radius-md 8px/12px aliases. Its compiler callers are GPUI native style, Web Component SSR, and browser preview CSS. This prevents treating the old complete run as a whole-graph exact-6ca run.

Among Shenko's 16 adopted Shadcn families, button, toggle-group, separator, and toggle changed; the remaining 12 were identical. The three selected public package versions remain 0.3.0. Shenko does not adopt the Brutalist family. Its two authored compileFile outputs are transport-badge and message-bubble using react-dom-source-v1; their current lowering route does not call the changed CSS renderer paths. Source-graph identity evidence and selected test results do not promote any broader compiler claim.

The genuine target-alignment native-support root-space-observer closure defect remains unchanged. The previous full bdc compiler run remains separately recorded with its original failures. This archive contains only the new selected 6ca checks and audit evidence; it does not replace or relabel the full-run receipt.

## Archive contents

Raw commands, installation and test stdout/stderr, exit codes and timestamps, sandbox preflight and its unchanged observer script, exact input pin, before/after tracked-file hashes, Git status snapshots, Git-object audit and local verification, Brutalist source diff, previous-run reference, runner/receipt scripts, and SHA256SUMS. No dependency cache or full source checkout is included; exact upstream commit/tree/lock identities bind the publicly retrievable source.
