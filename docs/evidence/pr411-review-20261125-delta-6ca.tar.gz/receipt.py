import hashlib,json,pathlib,re,subprocess,sys
r=pathlib.Path(sys.argv[1]); e=r/'evidence'
groups=[]
for stem,expected,filtered,command in [
 ('family-style',4,4,['pnpm','exec','vitest','run','packages/cli/test/family-style-closure.test.ts','-t','real family preset inherited physical closure']),
 ('release-family',8,6,['pnpm','exec','vitest','run','packages/compiler/test/release-family-consumer.test.ts','-t','^(shadcn|brutalist)/'])]:
 raw=(e/(stem+'-vitest.log')).read_bytes(); clean=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',raw.decode())
 summaries=[line.strip() for line in clean.splitlines() if re.match(r'^\s*(Test Files|Tests|Duration|Start at)\s',line)]
 testline=next((line for line in summaries if re.match(r'^Tests\s',line)), '')
 counts={key:int(value) for value,key in re.findall(r'(\d+)\s+(passed|failed|skipped|todo)',testline)}
 executed=counts.get('passed',0)+counts.get('failed',0)
 groups.append({'name':stem,'command':command,'exitCode':int((e/(stem+'-exit-code.txt')).read_text()),'counts':counts,'executed':executed,'expectedExecuted':expected,'filteredExistingCases':counts.get('skipped',0),'expectedFilteredCases':filtered,'selectionMatched':executed==expected and counts.get('skipped',0)==filtered,'summaryLines':summaries,'startedAt':(e/(stem+'-started-at.txt')).read_text().strip(),'finishedAt':(e/(stem+'-finished-at.txt')).read_text().strip(),'logSha256':hashlib.sha256(raw).hexdigest()})
before=json.loads((e/'tracked-before.json').read_text()); after=json.loads((e/'tracked-after.json').read_text())
result={'upstream':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'pnpm':subprocess.check_output(['pnpm','--version'],text=True).strip(),'lockSha256':hashlib.sha256(pathlib.Path('pnpm-lock.yaml').read_bytes()).hexdigest(),'groups':groups,'trackedSourceStable':before==after,'changedTrackedFiles':[k for k in set(before)|set(after) if before.get(k)!=after.get(k)],'sourceStatusStable':(e/'source-before.txt').read_bytes()==(e/'source-after.txt').read_bytes(),'sourceStatusBefore':(e/'source-before.txt').read_text(),'sourceStatusAfter':(e/'source-after.txt').read_text(),'sandboxPreflight':json.loads((e/'compiler-browser.json').read_text()),'audit':'audit-tree-identities.json','fullCompilerReceiptReused':False,'baselineNote':'The original complete bdc compiler receipt retains its original source, results and failures; these are only two selected existing delta groups at 6ca.'}
(e/'delta-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
if not all(g['selectionMatched'] for g in groups):raise SystemExit('Unexpected actual test selection')
if not result['trackedSourceStable'] or not result['sourceStatusStable']:raise SystemExit('Source drift detected')
