#!/bin/bash
set -euo pipefail
delta_root=/home/ezra/shenko-pr411-delta-6ca-20261125-55114
compiler_review=/home/ezra/shenko-pr411-compiler-20261125-55114
compiler_volume=/tank/docker/doescontainer/docker/volumes/shenko-target-r71/_data
expected_upstream=6ca8f262a074ed19cb24b35d5cc199b5b0e23e08
expected_lock=eae18430bd967c94def36809b6d3305fa156a96548b08215a18dfe8a43923c07
export PATH="$compiler_review/tooling/bin:$PATH"
export CHROME_PATH=/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome
export CANDIDATE_SHA="$expected_upstream"
export COMPILER_EVIDENCE_DIR="$delta_root/evidence/browser"
export PROTO_UI_RUNTIME_EVIDENCE_DIR="$delta_root/evidence/native"
unset GITHUB_SHA GITHUB_RUN_ID GITHUB_RUN_ATTEMPT
trap 'delta_result=$?; printf "%s\n" "$delta_result" > "$delta_root/evidence/runner-exit-code.txt"; date -u +%FT%TZ > "$delta_root/evidence/runner-finished-at.txt"' EXIT
date -u +%FT%TZ > "$delta_root/evidence/runner-started-at.txt"
test "$(id -u)" -ne 0
test "$(node --version)" = v24.22.1
test "$(pnpm --version)" = 10.32.1
printf 'fetching-exact-upstream\n' > "$delta_root/evidence/phase.txt"
git init "$delta_root/proto-ui" > "$delta_root/evidence/git-init.log" 2>&1
git -C "$delta_root/proto-ui" remote add origin https://github.com/Proto-UI/Proto-UI.git
git -C "$delta_root/proto-ui" fetch --depth=1 origin "$expected_upstream" > "$delta_root/evidence/git-fetch.log" 2>&1
git -C "$delta_root/proto-ui" checkout --detach FETCH_HEAD > "$delta_root/evidence/git-checkout.log" 2>&1
cd "$delta_root/proto-ui"
test "$(git rev-parse HEAD)" = "$expected_upstream"
printf '%s  pnpm-lock.yaml\n' "$expected_lock" | sha256sum -c - > "$delta_root/evidence/lock-before-install.txt"
git status --porcelain=v1 > "$delta_root/evidence/source-before.txt"
python3 "$delta_root/snapshot.py" "$delta_root/evidence/tracked-before.json"
{
 id
 node --version
 pnpm --version
 "$CHROME_PATH" --version
 git rev-parse HEAD
 git rev-parse 'HEAD^{tree}'
 sha256sum pnpm-lock.yaml
} > "$delta_root/evidence/environment.txt"
python3 - "$delta_root" <<'PY'
import json,pathlib,subprocess,sys
r=pathlib.Path(sys.argv[1])
(r/'evidence/checkout-ready.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'lockSha256':'eae18430bd967c94def36809b6d3305fa156a96548b08215a18dfe8a43923c07','source':str(r/'proto-ui')},indent=2)+'\n')
PY
printf 'awaiting-shared-lock\n' > "$delta_root/evidence/phase.txt"
date -u +%FT%TZ > "$delta_root/evidence/lock-wait-started-at.txt"
exec 9>/tank/shared/projects/shenko/build/cargo.lock
flock 9
date -u +%FT%TZ > "$delta_root/evidence/lock-acquired-at.txt"
printf 'installing-exact-frozen-lock\n' > "$delta_root/evidence/phase.txt"
printf '%s\n' 'HUSKY=0 pnpm install --frozen-lockfile' > "$delta_root/evidence/install-command.txt"
set +e
HUSKY=0 pnpm install --frozen-lockfile > "$delta_root/evidence/pnpm-install.log" 2>&1
install_result=$?
set -e
printf '%s\n' "$install_result" > "$delta_root/evidence/install-exit-code.txt"
test "$install_result" -eq 0
printf '%s  pnpm-lock.yaml\n' "$expected_lock" | sha256sum -c - > "$delta_root/evidence/lock-after-install.txt"
test -z "$(git status --porcelain=v1 --untracked-files=no)"
pnpm store path > "$delta_root/evidence/pnpm-store.txt"
mkdir -p "$delta_root/observer/scripts/ci" "$delta_root/observer/.ci/web"
sudo -n cat "$compiler_volume/pr411-review-20261125-55114/source/scripts/ci/compiler_browser.mjs" > "$delta_root/observer/scripts/ci/compiler_browser.mjs"
sudo -n cat "$compiler_volume/pr411-review-20261125-55114/source/crates/shenko-ui/web/upstream-pin.json" > "$delta_root/evidence/consumer-upstream-pin.json"
python3 - "$delta_root" <<'PY'
import json,pathlib,sys
r=pathlib.Path(sys.argv[1]); pin=json.loads((r/'evidence/consumer-upstream-pin.json').read_text())
assert pin['commit']=='6ca8f262a074ed19cb24b35d5cc199b5b0e23e08',pin['commit']
(r/'observer/.ci/web/inputs.json').write_text(json.dumps({'pin':pin},indent=2)+'\n')
PY
ln -s "$delta_root/proto-ui" "$delta_root/observer/.ci/web/proto-ui"
printf 'sandbox-preflight\n' > "$delta_root/evidence/phase.txt"
printf '%s\n' "node $delta_root/observer/scripts/ci/compiler_browser.mjs" > "$delta_root/evidence/preflight-command.txt"
set +e
node "$delta_root/observer/scripts/ci/compiler_browser.mjs" > "$delta_root/evidence/compiler-browser.log" 2>&1
browser_result=$?
set -e
printf '%s\n' "$browser_result" > "$delta_root/evidence/preflight-exit-code.txt"
test "$browser_result" -eq 0
cp "$delta_root/observer/.ci/evidence/compiler-browser.json" "$delta_root/evidence/compiler-browser.json"
printf 'family-style-closure\n' > "$delta_root/evidence/phase.txt"
date -u +%FT%TZ > "$delta_root/evidence/family-style-started-at.txt"
printf '%s\n' "pnpm exec vitest run packages/cli/test/family-style-closure.test.ts -t 'real family preset inherited physical closure'" > "$delta_root/evidence/family-style-command.txt"
set +e
pnpm exec vitest run packages/cli/test/family-style-closure.test.ts -t 'real family preset inherited physical closure' > "$delta_root/evidence/family-style-vitest.log" 2>&1
family_result=$?
set -e
printf '%s\n' "$family_result" > "$delta_root/evidence/family-style-exit-code.txt"
date -u +%FT%TZ > "$delta_root/evidence/family-style-finished-at.txt"
printf 'release-family-consumer\n' > "$delta_root/evidence/phase.txt"
date -u +%FT%TZ > "$delta_root/evidence/release-family-started-at.txt"
printf '%s\n' "pnpm exec vitest run packages/compiler/test/release-family-consumer.test.ts -t '^(shadcn|brutalist)/'" > "$delta_root/evidence/release-family-command.txt"
set +e
pnpm exec vitest run packages/compiler/test/release-family-consumer.test.ts -t '^(shadcn|brutalist)/' > "$delta_root/evidence/release-family-vitest.log" 2>&1
release_result=$?
set -e
printf '%s\n' "$release_result" > "$delta_root/evidence/release-family-exit-code.txt"
date -u +%FT%TZ > "$delta_root/evidence/release-family-finished-at.txt"
git status --porcelain=v1 > "$delta_root/evidence/source-after.txt"
python3 "$delta_root/snapshot.py" "$delta_root/evidence/tracked-after.json"
printf '%s  pnpm-lock.yaml\n' "$expected_lock" | sha256sum -c - > "$delta_root/evidence/lock-after-tests.txt"
python3 "$delta_root/receipt.py" "$delta_root"
printf 'completed\n' > "$delta_root/evidence/phase.txt"
test "$family_result" -eq 0
test "$release_result" -eq 0
