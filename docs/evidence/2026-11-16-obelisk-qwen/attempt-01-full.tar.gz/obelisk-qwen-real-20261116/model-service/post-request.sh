#!/usr/bin/env bash
set -euo pipefail
cd /workspace/shenko-obelisk-qwen-20261116
if [ "$#" -ne 2 ]; then printf 'usage: bash post-request.sh REQUEST_FILE OUTPUT_NAME\n' >&2; exit 2; fi
request_file=$(realpath -e -- "$1")
case "$request_file" in /workspace/shenko-obelisk-qwen-20261116/requests/*) ;; *) printf 'request must be in task requests directory\n' >&2; exit 2;; esac
case "$2" in ''|*[!A-Za-z0-9_.-]*) printf 'output name must be a simple safe filename\n' >&2; exit 2;; esac
output_prefix="/workspace/shenko-obelisk-qwen-20261116/requests/$2"
if [ -e "$output_prefix.response.body" ] || [ -e "$output_prefix.response.headers" ]; then printf 'output already exists\n' >&2; exit 2; fi
printf 'started_at=%s\n' "$(date -u +%FT%TZ)" > "$output_prefix.curl-metrics.txt"
set +e
env -i PATH=/usr/bin:/bin curl --noproxy '*' -sS --no-buffer --connect-timeout 5 --max-time 600 \
  -D "$output_prefix.response.headers" -o "$output_prefix.response.body" \
  -w 'http_status=%{http_code}\ntime_total=%{time_total}\nsize_download=%{size_download}\n' \
  -H 'Content-Type: application/json' --data-binary "@$request_file" \
  http://127.0.0.1:18831/v1/chat/completions >> "$output_prefix.curl-metrics.txt"
curl_status=$?
set -e
printf 'curl_exit=%s\nfinished_at=%s\n' "$curl_status" "$(date -u +%FT%TZ)" >> "$output_prefix.curl-metrics.txt"
sha256sum "$request_file" > "$output_prefix.sha256"
if [ -f "$output_prefix.response.body" ]; then sha256sum "$output_prefix.response.body" >> "$output_prefix.sha256"; fi
cat "$output_prefix.curl-metrics.txt"
exit "$curl_status"
