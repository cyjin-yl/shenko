from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,traceback,tarfile,gzip,io,shutil
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono');E=B/'evidence/continuation-s7-reading-current-4deb';S=B/'continuation-s7-tree-4deb'
D=S/'docs/evidence/2026-11-23-reading-current';BASE='7a8e5fc88404ac274e6b93a830e0744d010baebc'
README="# Original reading journeys on the Inspector candidate\n\nThe repository's existing `scripts/web_reading_journey.mjs` ran unchanged against Shenko commit `7a8e5fc88404ac274e6b93a830e0744d010baebc`, with the explicitly pinned Proto-UI candidate `6a9b575fbe744ccb2f54d1e45336ccc195f401f1`. Its SHA-256 is `520674696a94cafa95023b605b96b109d9dd41e654be36ea26d5b6d60cdd49d4`.\n\nThe original four journeys passed: Inspect at 1280 × 900 and 390 × 900 (21 checks each), and the actual conversation view at both widths (20 checks each). That is 82 checks within four existing journeys. It is not the 63-row Harness inventory.\n\nThe process ran from 2026-11-23T17:52:51.952279Z to 17:54:02.858398Z and exited 0. The application commit, clean tracked status, source snapshot, original observer and all normal generated assets stayed unchanged. The original raw receipt has SHA-256 `6d7f2f813e1fcd1f9422fa36555bf6d055a60c4576c68c553f7fffcbbcaca629`; the normal build manifest remains `876c52de5fa050bf6d71ebae5b57d607e5adddbed1972b5552be6767e423f9c4`.\n\n## What the original script observes\n\nThe production App renderer/controller consumes deterministic HTTP/WebSocket committed-text fixtures and ordinary Markdown links. The original assertions cover actual appended text, following the tail while preserving composer focus, sequential keyboard departure into history, user scroll priority, paused anchors, duplicate replay, keyboard resume, later appends, selection retention, natural end arrival, subject replacement, late ResizeObserver callbacks and actual App disposal. The original scroll/anchor tolerances, focus loops, 10000ms operation timeout, 50 × 100ms end-settle loop and timing waits are unchanged.\n\nWheel and keyboard input comes from browser automation. Selection uses the original DOM Range setup; pagehide and retained observer delivery are the script's explicit lifecycle controls. This does not claim physical selection/scroll hardware, live backend/model behavior, or assistive-technology acceptance.\n\nThe original launch expression remains `chromium.launch({headless: true, ...executablePath})`. The wrapper supplies the pinned executable and Playwright module but adds no launch flag, monkeypatch, sandbox environment override or fallback retry. Its 600-second process envelope contains all four journeys and does not replace or expand the original per-operation gates. The first transport request returned a queued timeout without creating a start marker or process; read-only reconciliation is archived. The successful start used the same creation-only marker, and one execution produced the recorded results.\n\n## Reproduction and archived evidence\n\nOn the recorded clean candidate, after its normal source-bound frontend build:\n\n```sh\nREADING_EVIDENCE_DIR=/owned/output \\\nPLAYWRIGHT_MODULE=/verified/playwright-core/index.mjs \\\nCHROMIUM_EXECUTABLE=/verified/chrome \\\nnode scripts/web_reading_journey.mjs\n```\n\n`original-reading-evidence.tar.gz` contains the unchanged observer, exact source and built assets, the launch wrapper and reconciliation, stdout/stderr, complete original receipt, all four screenshots and source/asset checks. `manifest.json` lists every archived payload's SHA-256 and byte size; all entries were decoded and verified. The preceding Tree increment and its failures remain in `../2026-11-23-inspector-tree/`.\n\n## Remaining #746 and Harness scope\n\nThis is current evidence for the existing committed-text reading composition. #746 additionally calls for deterministic public thought/activity, tool, receipt and explicit-wait updates through the actual application facts and their shared fixtures. Those additional semantic-update scenarios are not silently covered by this text-and-links run. The accepted-consumer/matrix review and the broader 63-row Harness inventory remain independently scoped. No legacy source-bound result is relabeled as a new candidate or a passing live-service run.\n"
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def shab(b):return hashlib.sha256(b).hexdigest()
def sha(p):return shab(p.read_bytes())
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
if sys.argv[1:]==['--start']:
 m=E/'archive-start-01.json'
 if m.exists():print(m.read_text());raise SystemExit(0)
 with m.open('x') as f,(E/'archive-launch-01.log').open('x') as log:
  c=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--run'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  j={'startedAt':now(),'pid':c.pid,'scriptSha256':sha(Path(__file__))};f.write(json.dumps(j,indent=2)+'\n');f.flush();print(json.dumps(j))
 raise SystemExit(0)
assert sys.argv[1:]==['--run']
record={'startedAt':now(),'passed':False,'base':BASE}
try:
 r=json.loads((E/'receipt-01.json').read_text())
 assert r['passed'] and r['sourceStable'] and r['assetStable']
 assert r['headBefore']==r['headAfter']==BASE and r['statusBefore']==r['statusAfter']==''
 assert r['observerSha256Before']==r['observerSha256After']=='520674696a94cafa95023b605b96b109d9dd41e654be36ea26d5b6d60cdd49d4'
 raw=E/'native-01/receipt.json';native=json.loads(raw.read_text())
 assert sha(raw)==r['receiptSha256']=='6d7f2f813e1fcd1f9422fa36555bf6d055a60c4576c68c553f7fffcbbcaca629'
 assert native['status']=='passed' and len(native['runs'])==4
 assert sum(len(x['checks']) for x in native['runs'])==82
 assert all(x['status']=='passed' and all(c['passed'] for c in x['checks']) and x['errors']==[] for x in native['runs'])
 payload={}
 def add(name,data):
  assert name not in payload and not name.startswith('/') and '..' not in Path(name).parts
  payload[name]=data
 for p in sorted(E.rglob('*')):
  if not p.is_file():continue
  name=str(p.relative_to(E))
  if name.startswith(('archive-','commit-','git-')) or name.endswith('.bundle'):continue
  add('raw/'+name,p.read_bytes())
 add('reproduce/archive-01.py',Path(__file__).read_bytes())
 for name,expected in r['sourceBefore'].items():
  data=(S/name).read_bytes();assert shab(data)==expected,name;add('source/'+name,data)
 for name in ['scripts/web_reading_journey.mjs','crates/shenko-ui/src/index.html']:
  add('source/'+name,(S/name).read_bytes())
 assert sha(S/'scripts/web_reading_journey.mjs')==r['observerSha256Before']
 assert sha(S/'crates/shenko-ui/src/index.html')==r['htmlSha256Before']
 static=S/'crates/shenko-ui/src/static'
 assert sha(static/'build-manifest.json')==r['buildManifestSha256']
 for name,expected in r['assetsBefore'].items():
  data=(static/name).read_bytes();assert shab(data)==expected,name;add('assets/'+name,data)
 add('assets/build-manifest.json',(static/'build-manifest.json').read_bytes())
 validation={'schemaVersion':1,'applicationCommit':BASE,'upstreamCandidate':r['upstreamCandidate'],
  'passed':True,'sourceStable':True,'assetStable':True,'originalObserverSha256':r['observerSha256Before'],
  'rawReceiptSha256':r['receiptSha256'],'buildManifestSha256':r['buildManifestSha256'],
  'startedAt':r['startedAt'],'finishedAt':r['finishedAt'],'runs':r['runs'],'checks':82,
  'browser':native.get('browser'),'browserExecutableSha256':r['browserExecutableSha256'],
  'launchPolicy':r['launchPolicy'],'scope':r['scope'],
  'physicalInput':False,'modelOrBackendAcceptance':False,
  'remaining':'#746 deterministic public activity/thought, tool, receipt and explicit-wait updates plus accepted-consumer/matrix review remain separate. This is not all 63 Harness rows.'}
 vb=(json.dumps(validation,ensure_ascii=False,indent=2)+'\n').encode();add('validation.json',vb)
 D.mkdir(parents=True,exist_ok=False);archive=D/'original-reading-evidence.tar.gz'
 with archive.open('xb') as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
  for name,data in sorted(payload.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert len(tar.getmembers())==len(payload)
  for entry in tar.getmembers():assert tar.extractfile(entry).read()==payload[entry.name],entry.name
 manifest={'schemaVersion':1,'base':BASE,'payloadCount':len(payload),'decodedBytes':sum(map(len,payload.values())),
  'payloads':[{'path':n,'bytes':len(b),'sha256':shab(b)} for n,b in sorted(payload.items())],
  'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}}
 dump(D/'manifest.json',manifest);(D/'validation.json').write_bytes(vb);(D/'README.md').write_text(README)
 shutil.copyfile(E/'native-01/inspect-1280.png',D/'desktop.png');shutil.copyfile(E/'native-01/im-390.png',D/'phone.png')
 record.update(passed=True,path=str(D),manifestSha256=sha(D/'manifest.json'),validationSha256=sha(D/'validation.json'),
  archive=manifest['archive'],payloadCount=len(payload),decodedBytes=manifest['decodedBytes'])
except Exception:record['failure']=traceback.format_exc();print(record['failure'],flush=True)
finally:record['finishedAt']=now();dump(E/'archive-receipt-01.json',record);print(json.dumps(record,ensure_ascii=False),flush=True)
