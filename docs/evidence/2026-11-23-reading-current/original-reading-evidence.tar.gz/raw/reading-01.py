from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,signal,traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E=B/'evidence/continuation-s7-reading-current-4deb'
T=B/'continuation-s7-tree-4deb'
TREE=B/'evidence/continuation-s7-tree-4deb'
WEB=T/'crates/shenko-ui/web'
OBS=T/'scripts/web_reading_journey.mjs'
NODE=B/'tools/node-v24.22.3-linux-x64/bin/node'
CHROME=B/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'
EXPECTED_OBSERVER='520674696a94cafa95023b605b96b109d9dd41e654be36ea26d5b6d60cdd49d4'
EXPECTED_HEAD='7a8e5fc88404ac274e6b93a830e0744d010baebc'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
    paths=sorted(set(list((WEB/'src').rglob('*'))+list((WEB/'tests').rglob('*'))+
        [WEB/name for name in ['build.mjs','compiler.mjs','upstream-pin.json','package.json','pnpm-lock.yaml','tsconfig.json']]))
    return {str(p.relative_to(T)):sha(p) for p in paths if p.is_file()}
def dump(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
if sys.argv[1:]==['--start']:
    E.mkdir(parents=True,exist_ok=True)
    marker=E/'start-01.json'
    if marker.exists():print(marker.read_text());raise SystemExit(0)
    assert sha(OBS)==EXPECTED_OBSERVER
    assert json.loads((TREE/'native-execution-03.json').read_text())['passed'] is True
    with marker.open('x') as receipt,(E/'launch-01.log').open('x') as log:
        child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--run'],
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        value={'startedAt':now(),'pid':child.pid,'wrapperSha256':sha(Path(__file__)),'expectedHead':EXPECTED_HEAD}
        receipt.write(json.dumps(value,indent=2)+'\n');receipt.flush();print(json.dumps(value))
    raise SystemExit(0)
if sys.argv[1:]!=['--run']:raise SystemExit('Expected --start or --run')
record={'startedAt':now(),'passed':False,'observerExpectedSha256':EXPECTED_OBSERVER,
 'scope':'Unmodified repository original four reading journeys; actual current production App assets with HTTP/WS fixtures.',
 'wrapperTimeoutSeconds':600,'wrapperTimeoutScope':'Total process safety envelope only; original per-operation timeouts and all four original assertions remain unmodified.',
 'launchPolicy':'Exact original script chromium.launch({headless:true, executablePath when supplied}); no monkeypatch, added flags, environment bypass or retry.'}
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
try:
    record['headBefore']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,env=env,timeout=120,text=True).strip()
    assert record['headBefore']==EXPECTED_HEAD
    record['statusBefore']=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=T,env=env,timeout=120,text=True)
    assert record['statusBefore']==''
    assert sha(OBS)==EXPECTED_OBSERVER
    record['observerSha256Before']=sha(OBS)
    record['sourceBefore']=snapshot()
    build=json.loads((TREE/'build-receipt-02.json').read_text())
    assert build['passed'] and build['sourceStable'] and record['sourceBefore']==build['sourceAfter']
    static=T/'crates/shenko-ui/src/static'
    manifest=json.loads((static/'build-manifest.json').read_text())
    record['buildManifestSha256']=sha(static/'build-manifest.json')
    assert record['buildManifestSha256']==build['appBuildManifest']['sha256']
    record['assetsBefore']={}
    for name,item in manifest['artifacts'].items():
        actual=sha(static/name);assert actual==item['sha256']
        record['assetsBefore'][name]=actual
    record['htmlSha256Before']=sha(T/'crates/shenko-ui/src/index.html')
    record['upstreamCandidate']=manifest['upstream']['commit']
    assert record['upstreamCandidate']=='6a9b575fbe744ccb2f54d1e45336ccc195f401f1'
    record['browserExecutableSha256']=sha(CHROME)
    env.pop('PUI_CHROME_NO_SANDBOX',None)
    tmp=B.parent/'s67i-tmp';tmp.mkdir(exist_ok=True)
    env.update(PATH=str(NODE.parent)+':'+env.get('PATH',''),NODE_OPTIONS='',NODE_PATH='',
        COREPACK_HOME=str(B/'corepack-cache'),TMPDIR=str(tmp),
        READING_EVIDENCE_DIR=str(E/'native-01'),
        PLAYWRIGHT_MODULE=str(B/'s67-734-calibration-4deb-04/candidate-consumer/node_modules/playwright-core/index.mjs'),
        CHROMIUM_EXECUTABLE=str(CHROME))
    record['argv']=[str(NODE),str(OBS)]
    dump(E/'progress-01.json',record)
    with (E/'stdout-01.log').open('x') as out,(E/'stderr-01.log').open('x') as err:
        child=subprocess.Popen(record['argv'],cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
        record['childPid']=child.pid;dump(E/'progress-01.json',record)
        try:record['exitCode']=child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            record['timedOut']=True;os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            record['exitCode']=child.returncode
    record['sourceAfter']=snapshot()
    record['observerSha256After']=sha(OBS)
    record['assetsAfter']={name:sha(static/name) for name in record['assetsBefore']}
    record['sourceStable']=record['sourceBefore']==record['sourceAfter'] and record['observerSha256Before']==record['observerSha256After']
    record['assetStable']=record['assetsBefore']==record['assetsAfter'] and record['buildManifestSha256']==sha(static/'build-manifest.json') and record['htmlSha256Before']==sha(T/'crates/shenko-ui/src/index.html')
    raw=E/'native-01/receipt.json'
    if raw.exists():
        native=json.loads(raw.read_text())
        record['receiptSha256']=sha(raw)
        record['runs']=[{'tab':r['tab'],'viewport':r['viewport'],'status':r.get('status'),'checks':len(r['checks']),'failure':r.get('failure')} for r in native['runs']]
        record['passed']=record['exitCode']==0 and native['status']=='passed' and len(native['runs'])==4 and all(r['status']=='passed' for r in native['runs']) and record['sourceStable'] and record['assetStable']
    record['headAfter']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,env=env,timeout=120,text=True).strip()
    record['statusAfter']=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=T,env=env,timeout=120,text=True)
    record['passed']=record['passed'] and record['headBefore']==record['headAfter'] and record['statusAfter']==''
except Exception:
    record['failure']=traceback.format_exc();print(record['failure'],flush=True)
finally:
    record['finishedAt']=now();dump(E/'receipt-01.json',record)
    print(json.dumps({k:v for k,v in record.items() if k not in ('sourceBefore','sourceAfter','assetsBefore','assetsAfter')},ensure_ascii=False),flush=True)
