import { pathToFileURL } from 'node:url';
const c = await import(pathToFileURL('/home/user/build-bump/proto-ui/packages/compiler/.probe/pc.mjs').href);
const base='';
const files = process.argv.slice(2);
for (const f of files) {
  try {
    const r = await c.compileFile(f, { root: '/home/user/build-bump/proto-ui', exportName: process.env.EXP, profile: 'react-dom-source-v1', componentName: 'X' });
    console.log(f, r.ok ? 'OK' : 'FAIL\n'+c.formatCompilerDiagnostics(r.diagnostics).split('\n').slice(0,8).join('\n'));
  } catch (e) { console.log(f, 'THROW', String(e.message).slice(0,300)); }
}
