from pathlib import Path
import os, sys, json, subprocess, datetime, hashlib, traceback, signal, time
B = Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E = B / 'evidence/continuation-s7-inspector-4deb'
S = B / 'continuation-s7-inspector-4deb'
U = B / 'continuation-s7-inspector-proto-4deb'
WEB = S / 'crates/shenko-ui/web'
NODE = B / 'tools/node-v24.22.3-linux-x64/bin/node'
HEAD = '6a9b575fbe744ccb2f54d1e45336ccc195f401f1'
APP_HEAD = '0e202f7aaecafc6ec761504dfb23cac437ee3e5e'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot():
    files = sorted(set(list((WEB / 'src').rglob('*')) + list((WEB / 'tests').rglob('*')) +
        [WEB / name for name in ['build.mjs', 'compiler.mjs', 'upstream-pin.json',
            'package.json', 'pnpm-lock.yaml', 'tsconfig.json']]))
    return {str(path.relative_to(S)): sha(path) for path in files if path.is_file()}
if sys.argv[1:] == ['--start']:
    marker = E / 'build-start-02.json'
    try: receipt = marker.open('x')
    except FileExistsError:
        print(marker.read_text()); raise SystemExit(0)
    with receipt, (E / 'build-launch-02.log').open('x') as log:
        child = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--run'],
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        start = {'startedAt': now(), 'pid': child.pid, 'scriptSha256': sha(Path(__file__)),
            'appBase': APP_HEAD, 'upstreamCandidate': HEAD}
        receipt.write(json.dumps(start, indent=2) + '\n'); receipt.flush()
        print(json.dumps(start))
    raise SystemExit(0)
if sys.argv[1:] != ['--run']: raise SystemExit('Expected --start or --run')
record = {'startedAt': now(), 'appBase': APP_HEAD, 'upstreamCandidate': HEAD, 'steps': [], 'passed': False}
env = dict(os.environ)
temp = B.parent / 's67i-tmp'
temp.mkdir(exist_ok=True)
env.update(PATH=str(NODE.parent) + ':' + env.get('PATH', ''), COREPACK_HOME=str(B / 'corepack-cache'),
    NODE_OPTIONS='', NODE_PATH='', TMPDIR=str(temp), PROTO_UI_SOURCE=str(U),
    PROTO_UI_BUILD_RECEIPT=str(E / 'public-packages-01.json'))
def save():
    (E / 'build-progress-02.json').write_text(json.dumps(record, indent=2) + '\n')
def step(name, argv, cwd, timeout):
    stdout = E / (name + '-02.stdout.log')
    stderr = E / (name + '-02.stderr.log')
    entry = {'name': name, 'argv': [str(x) for x in argv], 'cwd': str(cwd),
        'startedAt': now(), 'wrapperTimeoutSeconds': timeout,
        'stdout': str(stdout), 'stderr': str(stderr)}
    record['steps'].append(entry); save()
    started = time.monotonic()
    with stdout.open('x') as out, stderr.open('x') as err:
        child = subprocess.Popen([str(x) for x in argv], cwd=cwd, env=env,
            stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
        entry['pid'] = child.pid; save()
        try: code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try: child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL); child.wait()
            entry['timedOut'] = True
            code = child.returncode
    entry.update(exitCode=code, finishedAt=now(), durationSeconds=time.monotonic() - started,
        stdoutSha256=sha(stdout), stderrSha256=sha(stderr))
    save()
    if code or entry.get('timedOut'): raise RuntimeError('Step failed: ' + name)
    return stdout.read_text()
try:
    prepared = json.loads((E / 'upstream-prepare-receipt-02.json').read_text())
    assert prepared['passed'] is True
    assert step('upstream-head', ['git', 'rev-parse', 'HEAD'], U, 120).strip() == HEAD
    assert step('app-head', ['git', 'rev-parse', 'HEAD'], S, 120).strip() == APP_HEAD
    assert step('upstream-clean-before', ['git', 'status', '--porcelain', '--untracked-files=no'], U, 120).strip() == ''
    pin = json.loads((WEB / 'upstream-pin.json').read_text())
    assert pin['commit'] == HEAD and pin['lock_sha256'] == sha(U / 'pnpm-lock.yaml')
    record['sourceBefore'] = snapshot(); save()
    prior = json.loads((E / 'build-receipt-01.json').read_text())
    assert prior['passed'] is True and prior['sourceStable'] is True
    metadata = {'crates/shenko-ui/web/build.mjs', 'crates/shenko-ui/web/package.json'}
    assert {k: v for k, v in record['sourceBefore'].items() if k not in metadata} == {
        k: v for k, v in prior['sourceAfter'].items() if k not in metadata}
    record['priorValidation'] = {'path': str(E / 'build-receipt-01.json'),
        'sha256': sha(E / 'build-receipt-01.json'),
        'scope': '42 public packages, strict TypeScript and 55 Node tests; runtime/test source byte-identical',
        'changedMetadata': sorted(metadata)}
    receipt = json.loads((E / 'public-packages-01.json').read_text())
    assert receipt['selectedCount'] == 42 and len(receipt['results']) == 42
    record['publicReceiptSha256'] = sha(E / 'public-packages-01.json')
    assert record['publicReceiptSha256'] == prior['publicReceiptSha256']
    step('observer-syntax', [NODE, '--check', 'scripts/inspector-browser.mjs'], WEB, 120)
    step('app-build', [NODE, 'build.mjs'], WEB, 600)
    record['sourceAfter'] = snapshot()
    record['sourceStable'] = record['sourceAfter'] == record['sourceBefore']
    assert record['sourceStable']
    assert step('upstream-clean-after', ['git', 'status', '--porcelain', '--untracked-files=no'], U, 120).strip() == ''
    manifest = S / 'crates/shenko-ui/src/static/build-manifest.json'
    record['appBuildManifest'] = {'path': str(manifest), 'sha256': sha(manifest)}
    record['passed'] = True
except Exception:
    record['failure'] = traceback.format_exc()
    print(record['failure'], flush=True)
finally:
    record['finishedAt'] = now()
    save()
    (E / 'build-receipt-02.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'passed': record['passed'], 'finishedAt': record['finishedAt']}), flush=True)
