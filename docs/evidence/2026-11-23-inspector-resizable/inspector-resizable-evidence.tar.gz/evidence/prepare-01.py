from pathlib import Path
import os, sys, json, subprocess, datetime, hashlib, traceback
BASE = Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
EVIDENCE = BASE / 'evidence/continuation-s7-inspector-4deb'
SOURCE = BASE / 'continuation-s5-shenko-full-4deb'
TARGET = BASE / 'continuation-s7-inspector-4deb'
HEAD = '0e202f7aaecafc6ec761504dfb23cac437ee3e5e'
BRANCH = 'work/sprint7-inspector-20261123'
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
if sys.argv[1:] == ['--start']:
    marker = EVIDENCE / 'prepare-start-01.json'
    try:
        receipt = marker.open('x')
    except FileExistsError:
        print(marker.read_text())
        raise SystemExit(0)
    with receipt, (EVIDENCE / 'prepare-launch-01.log').open('x') as log:
        child = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--run'],
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        record = {'startedAt': now(), 'pid': child.pid, 'scriptSha256': digest(Path(__file__)),
            'target': str(TARGET), 'sourceHead': HEAD}
        receipt.write(json.dumps(record, indent=2) + '\n')
        receipt.flush()
        print(json.dumps(record))
    raise SystemExit(0)
if sys.argv[1:] != ['--run']:
    raise SystemExit('Expected --start or --run')
record = {'startedAt': now(), 'target': str(TARGET), 'sourceHead': HEAD, 'commands': [], 'passed': False}
def run(argv, timeout=600):
    step = {'argv': argv, 'startedAt': now()}
    record['commands'].append(step)
    result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, text=True, timeout=timeout)
    step.update(exitCode=result.returncode, finishedAt=now(), output=result.stdout)
    (EVIDENCE / 'prepare-progress-01.json').write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError('Command failed: ' + repr(argv))
    return result.stdout.strip()
try:
    if TARGET.exists():
        raise RuntimeError('Target already exists; preserve it and reconcile before another preparation')
    record['borrowedRepositoryHead'] = run(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], 30)
    run(['git', 'clone', '--shared', '--no-checkout', '--no-hardlinks', str(SOURCE), str(TARGET)])
    run(['git', '-C', str(TARGET), 'fetch', '--no-tags', '--no-recurse-submodules',
        'https://github.com/cyjin-yl/shenko.git', HEAD])
    run(['git', '-C', str(TARGET), 'switch', '--create', BRANCH, HEAD])
    actual = run(['git', '-C', str(TARGET), 'rev-parse', 'HEAD'], 30)
    if actual != HEAD:
        raise RuntimeError('Checkout does not match source head')
    record['branch'] = BRANCH
    web = TARGET / 'crates/shenko-ui/web'
    old_web = SOURCE / 'crates/shenko-ui/web'
    record['webLockSha256'] = digest(web / 'pnpm-lock.yaml')
    if record['webLockSha256'] != digest(old_web / 'pnpm-lock.yaml'):
        raise RuntimeError('Existing consumer lock differs; dependencies are not reused')
    package = json.loads((web / 'package.json').read_text())
    declared = {**package['dependencies'], **package['devDependencies']}
    modules = web / 'node_modules'
    modules.mkdir()
    reused = []
    for name, version in declared.items():
        source = (old_web / 'node_modules' / name).resolve(strict=True)
        source_package = source / 'package.json'
        actual_package = json.loads(source_package.read_text())
        if actual_package.get('name') != name or actual_package.get('version') != version:
            raise RuntimeError('Installed dependency differs: ' + name)
        link = modules / name
        link.parent.mkdir(parents=True, exist_ok=True)
        link.symlink_to(source, target_is_directory=True)
        reused.append({'name': name, 'version': version, 'realpath': str(source),
            'packageSha256': digest(source_package)})
    record['readOnlyThirdPartyDependencies'] = reused
    record['workspaceDependencyBoundary'] = 'Only exact locked third-party package links; no borrowed @proto.ui or compiler output'
    record['passed'] = True
except Exception:
    record['failure'] = traceback.format_exc()
    print(record['failure'], flush=True)
finally:
    record['finishedAt'] = now()
    (EVIDENCE / 'prepare-receipt-01.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'passed': record['passed'], 'finishedAt': record['finishedAt']}), flush=True)
