from pathlib import Path
import os, sys, json, subprocess, datetime, hashlib, traceback
B = Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E = B / 'evidence/continuation-s7-inspector-4deb'
BORROW = B / 'integration-20261123-0320'
DEPENDENCIES = B / 'continuation-s4-4deb'
TARGET = B / 'continuation-s7-inspector-proto-4deb'
HEAD = '6a9b575fbe744ccb2f54d1e45336ccc195f401f1'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
if sys.argv[1:] == ['--start']:
    marker = E / 'upstream-prepare-start-02.json'
    try: receipt = marker.open('x')
    except FileExistsError:
        print(marker.read_text()); raise SystemExit(0)
    with receipt, (E / 'upstream-prepare-launch-02.log').open('x') as log:
        child = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--run'],
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        start = {'startedAt': now(), 'pid': child.pid, 'scriptSha256': sha(Path(__file__)),
            'target': str(TARGET), 'sourceHead': HEAD}
        receipt.write(json.dumps(start, indent=2) + '\n'); receipt.flush()
        print(json.dumps(start))
    raise SystemExit(0)
if sys.argv[1:] != ['--run']: raise SystemExit('Expected --start or --run')
record = {'startedAt': now(), 'sourceHead': HEAD, 'target': str(TARGET), 'commands': [], 'passed': False}
env = dict(os.environ)
env.update(PATH=str(B / 'tools/node-v24.22.3-linux-x64/bin') + ':' + env.get('PATH', ''),
    COREPACK_HOME=str(B / 'corepack-cache'), NODE_OPTIONS='', NODE_PATH='')
def run(argv, timeout=600):
    step = {'argv': argv, 'startedAt': now()}
    record['commands'].append(step)
    result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, text=True, timeout=timeout, env=env)
    step.update(exitCode=result.returncode, finishedAt=now(), output=result.stdout)
    (E / 'upstream-prepare-progress-02.json').write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode: raise RuntimeError('Command failed: ' + repr(argv))
    return result.stdout.strip()
def packages(root):
    found = {}
    for pattern in ['packages/*/package.json', 'packages/*/*/package.json', 'apps/*/package.json']:
        for manifest in root.glob(pattern):
            data = json.loads(manifest.read_text())
            if isinstance(data.get('name'), str): found[data['name']] = manifest.parent
    return found
try:
    # Attempt 01 completed the exact immutable checkout, then failed the stale pin hash.
    # Reuse only that source; never reset another tree or repeat its completed clone.
    assert TARGET.is_dir(), 'Expected reconciled attempt-01 target'
    assert not (TARGET / 'node_modules').exists(), 'Reconcile unexpected dependency work first'
    assert run(['git', '-C', str(TARGET), 'status', '--porcelain', '--untracked-files=no'], 30) == ''
    assert run(['git', '-C', str(TARGET), 'rev-parse', 'HEAD'], 30) == HEAD
    own_lock = sha(TARGET / 'pnpm-lock.yaml')
    old_lock = sha(DEPENDENCIES / 'pnpm-lock.yaml')
    assert own_lock == old_lock == '6e21c4b8444ca5e4a2e427287a76a346137b65d76403579942269bfea1fc7fe8', (own_lock, old_lock)
    record['lockSha256'] = own_lock
    own_packages, old_packages = packages(TARGET), packages(DEPENDENCIES)
    old_to_own = {str(path.resolve()): own_packages[name] for name, path in old_packages.items() if name in own_packages}
    links = []
    def link(source, destination):
        resolved = source.resolve(strict=True)
        target = old_to_own.get(str(resolved), resolved)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.symlink_to(target, target_is_directory=target.is_dir())
        links.append({'path': str(destination.relative_to(TARGET)), 'target': str(target),
            'kind': 'own-workspace' if str(target).startswith(str(TARGET) + '/') else 'read-only-external'})
    roots = [(DEPENDENCIES, TARGET)]
    roots += [(old_packages[name], path) for name, path in own_packages.items() if name in old_packages]
    for old_root, new_root in roots:
        source = old_root / 'node_modules'
        if not source.is_dir(): continue
        destination = new_root / 'node_modules'
        destination.mkdir(parents=True, exist_ok=True)
        for child in source.iterdir():
            if child.name.startswith('.') and child.name != '.pnpm': continue
            if child.name.startswith('@') and child.is_dir():
                for dependency in child.iterdir(): link(dependency, destination / child.name / dependency.name)
            else: link(child, destination / child.name)
    scope = TARGET / 'node_modules/@proto.ui'
    scope.mkdir(parents=True, exist_ok=True)
    for name, path in own_packages.items():
        if not name.startswith('@proto.ui/'): continue
        destination = scope / name.split('/', 1)[1]
        if destination.is_symlink():
            assert destination.resolve() == path.resolve()
        elif destination.exists():
            raise RuntimeError('Unexpected dependency destination: ' + str(destination))
        else:
            destination.symlink_to(path, target_is_directory=True)
            links.append({'path': str(destination.relative_to(TARGET)), 'target': str(path), 'kind': 'own-workspace'})
    record['dependencyLinks'] = links
    record['borrowedDependencies'] = str(DEPENDENCIES)
    record['scope'] = 'Immutable source checkout and external dependency links only; no source/dist copied from borrowed worktrees'
    record['passed'] = True
except Exception:
    record['failure'] = traceback.format_exc()
    print(record['failure'], flush=True)
finally:
    record['finishedAt'] = now()
    (E / 'upstream-prepare-receipt-02.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'passed': record['passed'], 'finishedAt': record['finishedAt']}), flush=True)
